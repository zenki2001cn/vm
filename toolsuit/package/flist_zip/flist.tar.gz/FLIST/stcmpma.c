/* stcmpma.c: this contains two kinds of routines which perform pattern
 * matching: (stcmpma,stcmpm) and (stcmpma2,stcmpm2).  The stcmpma/stcmpma2
 * routines are anchored matching routines - ie. matches occur iff the
 * string s begins with the pattern.  The stcmpm/stcmpm2 routines are not
 * anchored - ie. a match occurs if the pattern is anywhere in the string s.
 * The stcmpma2/stcmpm2 routines require that setpat be used to analyze
 * a pattern string p to form a linked list of PATterns.  The stcmpma/stcmpm
 * routines always analyze their pattern strings; hence, stcmpma2/stcmpm2
 * are faster than their counterparts.
 *
 *   The user interface routines:
 *    stcmpma(s,p,len)       anchored pattern match
 *    stcmpm(s,p,q,len)      floating pattern match
 *    stcmpma2(s,pathd,len)  anchored PATtern match
 *    stcmpm2(s,pathd,q,len) floating PATtern match
 *    PAT *setpat(p)         analyzes pattern to form PATtern
 *    freepat(pathd)         frees up PATtern memory
 *    char *patprint(pat)    returns string describing PATtern
 *
 *   where
 *    char  *s;     string being examined for match
 *    char  *p;     pattern in the form of a string
 *    char **q;     *q points to beginning of pattern in string s
 *    int   *len;   length of match (output)
 *    PAT   *pathd; pattern in the form of a linked list of PATterns
 *
 *  Routines return: 0 -- no match
 *                   1 -- match found
 */
#include <stdio.h>
#include <ctype.h>
#include "xtdio.h"

/* -------------------------------------------------------------------------
 * Definitions Section:
 */
#define RANGE		128
#define CARAT		1
#define DOLLAR		1<<1
#define STARTWORD	1<<2	/* COMBAK */
#define ENDWORD		1<<3	/* COMBAK */
#define	NOT			1<<8
#define PATPRINT	256
#define PATOVER		5

/* ----------------------------------------------------------------------
 * Global and Local Parameters:
 */
static int ignorecase=0;

/* mtchlst : a structure with pointers to "{...}" enclosed patterns
 *	i      : in stcmpma_mtch[i], brace level index
 *
 * struct mtchlst {		// external sub-field match list
 * 	char *start;		// the i'th sub-field start pointer  (the ith "{")
 * 	char *last;			// the i'th sub-field last pointer   (the ith matching "}")
 * 	};
 */
struct mtchlst stcmpma_mtch[MTCHMAX];		/* {} patterns				*/
int            stcmpma_mcnt         = 0;	/* count of {}				*/
char           stcmpma_underscore   = 0;	/* \_ is magic for [ \t\n]	*/

/*	sfo: holds indices to appropriate stcmpma_mtch[].start by order of occurrence in pattern.
 *	sfc: holds indices to appropriate stcmpma_mtch[].last  by order of occurrence in pattern.
 *	sbeg: points to beginning of string.
 */
static int   sfo[MTCHMAX];
static int   sfc[MTCHMAX];
static char *sbeg        = NULL;

/* PAT: the pattern is to be converted into a list of PATterns.
 *
 * typedef struct PAT_str PAT;
 * struct PAT_str {
 * 	char   c;                         :  a single character pattern
 * 	char  *range;                     :  list of 128 chars specifying range match
 * 	char **sfo;                       :  subfield start ptr to stcmpma_mtch[].start entry
 * 	char **sfc;                       :  subfield close ptr to stcmpma_mtch[].last entry
 * 	char   mcnt;
 * 	int  (*f )(char *,PAT **,int *);  :  function used to determine match
 * 	int  (*ff)(char *,PAT **,int *);  :  used by bscan and fscan
 * 	int    eb;                        :  ending/beginning test needed in addition to
 * 						              :    a range test.  Four bits are used:
 * 						              :    |~$|$|~^|^| (bits |4|3|2|1| )
 * 	int    context;                   :  used during range matching.  Context matching required
 * #ifdef DEBUG
 * 	int    isfo;                      :  used by debugging to number subfields
 * 	int    isfc;                      :  used by debugging to number subfields
 * #endif
 * 	PAT *nxt;                         :  pointer to next PATtern
 * 	};
 */

/* type definition of the matching functions
 *
 *  One character tests
 *    equal   : tests if string character and PATtern are equal
 *    nequal  : tests if string character and PATtern are not equal
 *    range   : tests if string character lies in PATtern range
 *    nrange  : tests if string character doesn't satisfy range
 *    wildcard: matches to any character
 *
 *  Backwards Scan (multiple character) tests
 *    bscan   :    tests if (0+) string characters match PATtern using backward scan.
 *
 *  Forwards Scan (multiple character) tests
 *    fscan   :    tests if (0+) string characters match PATtern using forward scan.
 *
 *  Zero or One of subpattern tests
 *    zero_one:  tests if (0,1) string character(s) match PATtern
 *
 *  Conditions  (these tests may match, but with zero length)
 *    ending     : tests if string ends
 *    begin      : tests if string begins
 *    nending    : tests if string doesn't end
 *    nbegin     : tests if string doesn't begin
 *    startword  : tests if string begins a word
 *    nstartword : tests if string doesn't begin a word
 *    endword    : tests if string begins a word
 *    nendword   : tests if string doesn't begin a word
 *    always     : always matches (with zero length!)
 */

/* ----------------------------------------------------------------------
 * Local Prototypes:
 */
#ifdef __PROTOTYPE__
static int stcmpmaP( char *,  PAT **,  int *);   /* stcmpma.c */
static int stcmpmP(char *,PAT **,char **,int *); /* stcmpma.c */
static PAT *palloc(PAT **,PAT **);               /* stcmpma.c */
static int setbrace(char *);                     /* stcmpma.c */
static int setrange( char *,  PAT *,  char **);  /* stcmpma.c */
static int setcontxt(PAT *);                     /* stcmpma.c */
static int sfopen(char *,PAT **,int *);          /* stcmpma.c */
static int sfclose(char *,PAT **,int *);         /* stcmpma.c */
static int equal(char *,PAT **,int *);           /* stcmpma.c */
static int nequal(char *,PAT **,int *);          /* stcmpma.c */
static int nrange(char *,PAT **,int *);          /* stcmpma.c */
static int range(char *,PAT **,int *);           /* stcmpma.c */
static int wildcard(char *,PAT **,int *);        /* stcmpma.c */
static int bscan(char *,PAT **,int *);           /* stcmpma.c */
static int fscan(char *,PAT **,int *);           /* stcmpma.c */
static int zero_one(char *,PAT **,int *);        /* stcmpma.c */
static int ending(char *,PAT **,int *);          /* stcmpma.c */
static int begin(char *,PAT **,int *);           /* stcmpma.c */
static int nending(char *,PAT **,int *);         /* stcmpma.c */
static int nbegin(char *,PAT **,int *);          /* stcmpma.c */
static int startword(char *,PAT **,int *);       /* stcmpma.c */
static int nstartword(char *,PAT **,int *);      /* stcmpma.c */
static int endword(char *,PAT **,int *);         /* stcmpma.c */
static int nendword(char *,PAT **,int *);        /* stcmpma.c */
static int always(char *,PAT **,int *);          /* stcmpma.c */
static int ISMAGIC(char);                        /* stcmpma.c */

#else

static int stcmpmaP();                           /* stcmpma.c */
static int stcmpmP();                            /* stcmpma.c */
static PAT *palloc();                            /* stcmpma.c */
static int setbrace();                           /* stcmpma.c */
static int setrange();                           /* stcmpma.c */
static int setcontxt();                          /* stcmpma.c */
static int sfopen();                             /* stcmpma.c */
static int sfclose();                            /* stcmpma.c */
static int equal();                              /* stcmpma.c */
static int nequal();                             /* stcmpma.c */
static int nrange();                             /* stcmpma.c */
static int range();                              /* stcmpma.c */
static int wildcard();                           /* stcmpma.c */
static int bscan();                              /* stcmpma.c */
static int fscan();                              /* stcmpma.c */
static int zero_one();                           /* stcmpma.c */
static int ending();                             /* stcmpma.c */
static int begin();                              /* stcmpma.c */
static int nending();                            /* stcmpma.c */
static int nbegin();                             /* stcmpma.c */
static int startword();                          /* stcmpma.c */
static int nstartword();                         /* stcmpma.c */
static int endword();                            /* stcmpma.c */
static int nendword();                           /* stcmpma.c */
static int always();                             /* stcmpma.c */
static int ISMAGIC();                            /* stcmpma.c */

#endif

/* ---------------------------------------------------------------------- */

/* stcmpma: complete match, pattern matching, anchored
 *  Returns: 0: no match
 *           1: match
 */
int stcmpma(
  char *s,		/* string to be searched									*/
  char *p,		/* pattern (regular expression)								*/
  int  *len)	/* length of matched string									*/
{
PAT *pathd;
int ret;


/* set up a PATtern */
if( !(pathd= setpat(p)) ) { /* error during setpat */
	*len= 0;
	return 0;
	}

/* analyze string for matching to PATtern */
ret= stcmpma2(s,pathd,len);
freepat(pathd);

return ret;
}

/* ---------------------------------------------------------------------- */

/* stcmpm: complete match, pattern matching, not anchored
 *  Returns: 0: no match
 *           1: match found
 */
int stcmpm(
  char  *s,		/* string to be searched									*/
  char  *p,		/* pattern (regular expression)								*/
  char **q,		/* *q points to beginning of matched pattern in string s	*/
  int   *len)	/* length of matched string									*/
{
PAT *pathd;
int ret;


/* set up a PATtern */
if( !(pathd= setpat(p)) ) { /* error in setpat */
	*len= 0;
	return 0;
	}

/* analyze string for matching to PATtern */
ret= stcmpm2(s,pathd,q,len);
freepat(pathd);

return ret;
}

/* ---------------------------------------------------------------------- */

/* stcmpma2: complete match, pattern matching, anchored
 *  Returns: 0: no match
 *           1: match found
 */
int stcmpma2(
  char *s,		/* string to be searched									*/
  PAT  *pathd,	/* regular expression PATtern list (see setpat(char *p))	*/
  int  *len)	/* length of matched string									*/
{
int ret;


sbeg        = s;					/* set up "string begin" pointer	*/
stcmpma_mcnt= (int) pathd->mcnt;	/* set up subfield count			*/


ret= stcmpmaP(s,&pathd,len);
if(!ret) stcmpma_mcnt= 0;			/* no subfields if no match			*/

return ret;
}

/* ---------------------------------------------------------------------- */

/* stcmpm2: complete match, pattern matching, not anchored
 *  Returns: 0: no match
 *           1: match found
 */
int stcmpm2(
  char  *s,		/* string to be searched									*/
  PAT   *pathd,	/* regular expression PATtern list (see setpat(char *p))	*/
  char **q,		/* *q points to beginning of matched pattern in string s	*/
  int   *len)	/* length of matched string									*/
{
int ret;

sbeg        = s;					/* set up "string begin" pointer	*/
stcmpma_mcnt= (int) pathd->mcnt;	/* set up subfield count			*/

ret= stcmpmP(s,&pathd,q,len);
if(!ret) stcmpma_mcnt= 0; /* no subfields if no match */

return ret;
}

/* ---------------------------------------------------------------------- */

/* freepat: frees up pattern space */
void freepat(PAT *pathd)
{
PAT *pat,*npat;
for(pat= pathd; pat; pat= npat) {
	npat= pat->nxt;
	if(pat->range) free(pat->range);
	free((char *) pat);
	}
}

/* ---------------------------------------------------------------------- */

/* patprint: interprets a PATtern to stdout */
char *patprint(PAT *pat)
{
char        *b;
char        *s    = NULL;
int        (*f)() = NULL;
int          i;
int          rng;
static char  buf1[PATPRINT + PATOVER];
static char  buf2[PATPRINT + PATOVER];
static char  buf3[PATPRINT + PATOVER];
static char *buf= buf1;

/* round robin the buffer */
if     (buf == buf1) buf= buf2;
else if(buf == buf2) buf= buf3;
else                 buf= buf1;

if(!pat) {
	strcpy(buf,"-no-pattern-");
	return buf;
	}

/* interpret pattern */
for(b= buf; pat; pat= pat->nxt) {

	/* buffer overflow prevention */
	if(b > buf + PATPRINT) {
		strcpy(b,"...");
		break;
		}

	/* locate primitive function */
	f= pat->ff? pat->ff : pat->f;

	/* print out interpretation of function */
	if(f == nequal) {
		*(b++)= '~';
		if(ISMAGIC(pat->c)) *(b++)= '\\';
		strcpy(b,cprt(pat->c));
		b+= strlen(b);
		}
	else if(f == equal) {
		if(ISMAGIC(pat->c)) *(b++)= '\\';
		strcpy(b,cprt(pat->c));
		b+= strlen(b);
		}
	else if(f == range || f == nrange) {
		if(f == nrange) *(b++)= '~';
		*(b++)= '[';
		for(s= pat->range,i= rng= 0; i < RANGE; ++i,++s) if(*s) {
			if(!rng) {                              /* begin print of subrange (ie. a-z)                       */
				strcpy(b,cprt((char) i));
				b += strlen(b);
				rng= (i < RANGE-2) && s[1] && s[2];
				}
			else if(rng) {
				if(!s[1]) {                         /* next character not-in-range, so this is end-of-subrange */
					*(b++)= '-';
					strcpy(b,cprt((char) i));
					b += strlen(b);
					rng= 0;
					}
				else if(*s && i == RANGE - 1) {     /* no next-character, so this is end-of-subrange           */
					*(b++)= '-';
					strcpy(b,cprt((char) i));
					b += strlen(b);
					rng= 0;
					}
				}
			}
		if(pat->eb & NOT)       *(b++)= '~';
		if(pat->eb & CARAT)     *(b++)= '^';
		if(pat->eb & DOLLAR)    *(b++)= '$';
		if(pat->eb & STARTWORD) {*(b++)= '\\';*(b++)= '<';}
		if(pat->eb & ENDWORD)   {*(b++)= '\\';*(b++)= '>';}
		*(b++)= ']';
		}
	else if(f == wildcard)    *(b++)= '?';
	else if(f == begin)       *(b++)= '^';
	else if(f == nbegin)     {*(b++)= '~'; *(b++)= '^';}
	else if(f == ending)      *(b++)= '$';
	else if(f == nending)    {*(b++)= '~'; *(b++)= '$';}
	else if(f == always)     {*(b++)= '^'; *(b++)= '*';}
	else if(f == sfopen)      *(b++)= '{';
	else if(f == sfclose)     *(b++)= '}';
	else if(f == startword)  {*(b++)= '\\'; *(b++)= '<';}
	else if(f == nstartword) {*(b++)= '~'; *(b++)= '\\'; *(b++)= '<';}
	else if(f == endword)    {*(b++)= '\\'; *(b++)= '>';}
	else if(f == nendword)   {*(b++)= '~'; *(b++)= '\\'; *(b++)= '>';}
	else {
		sprintf(b,"<XTDIO_ERROR f=%px>",f);
		b+= strlen(b);
		}

	/* print out multiple matching if indicated */
	if     (pat->f == bscan)    *(b++)= '*';
	else if(pat->f == fscan)    *(b++)= '%';
	else if(pat->f == zero_one) *(b++)= '`';
	}

/* terminate the buffer properly and return */
*b= '\0';
return buf;
}

/* ======================================================================
 * Static Source:
 */

/* stcmpmaP: this routine is the core pattern matcher.  As is obvious,
 *	it is a very simple loop.
 *  Returns: 0: no match
 *           1: match found
 */
static int stcmpmaP(
  char *s,		/* string to be searched									*/
  PAT **pat,	/* regular expression PATtern								*/
  int  *len)	/* length of matched string									*/
{
int  length;
PAT *pathld;


/* sanity check */
if(!pat) {
	error(XTDIO_WARNING,"stcmpmaP: pat is null, programming error\n");
	*len= 0;
	return 0;
	}

/* initialize */
*len  = 0;
pathld= *pat;

/* check to see if entire pattern matches string */
for(; *pat; *pat= (*pat)->nxt) {

	/* test for match with pattern matching function */
	if(!(*(*pat)->f)(s,pat,&length)) {
		/* any pattern match failure returns a no match condition */
		*len= 0;
		*pat= pathld;
		return 0;
		}

	/* handle end-of-string conditions */
	if(!*s) {
		if(!*pat) break;
		else      continue;
		}

	/* update length matched and string pointer */
	s   += length;
	*len+= length;

	/* since (*pat)->f may have modified the pat pointer, test is needed */
	if(!*pat) break;
	}

return 1;
}

/* ---------------------------------------------------------------------- */

/* stcmpmP: this routine is an unanchored version of the core pattern
 *	matcher.  It basically surrounds stcmpmaP with an outer loop.
 */
static int stcmpmP(char *s,PAT **pat,char **q,int *len)
{

/* test to see if pattern matches */
for(*q= s; **q; ++*q) {

	if(stcmpmaP(*q,pat,len)) {
		/* the first pattern which matches returns a true */
		return 1;
		}
	}

/* test if end-of-string matches */
if(stcmpmaP(*q,pat,len)) {
	/* the first pattern which matches returns a true */
	return 1;
	}

/* no success */
*q  = NULL;
*len= 0;
return 0;
}

/* =========================================================================
 *	PATtern Analyzing/Set-Up Routines
 * =========================================================================
 */
static int dosetbrace= 1;

/* setpat_nosetbrace: this function supports stlpm; it doesn't setbrace
 *  but otherwise invokes setpat
 */
PAT *setpat_nosetbrace(char *p)
{
PAT *pat;


stcmpma_mcnt= 0;	/* set subfield count to zero	*/
dosetbrace  = 0;
pat         = setpat(p);
dosetbrace  = 1;

return pat;
}

/* --------------------------------------------------------------------- */

/* setpat: converts a user-supplied pattern string into a linked list of
 *  PAT structures.  This list formation is required for stcmpmaP() and
 *	stcmpmP().  The resulting list enables stcmpmaP and stcmpmP to
 *	perform their pattern-matching jobs faster than their stcmpma()
 *	and stcmpm() cousins. (Pattern Matching SET PATterns)
 *
 *  p: pointer to user-supplied pattern string
 */
PAT *setpat(char *p)
{
static char  alpha[]  = {"@]"};     /* alphameric string                         */
static char  digit[]  = {"#]"};     /* digit string                              */
static char  nocase[] = {" ]"};     /* blanks are changed to lower/upper case    */
static char  space[]  = {" \\t]"};  /* white space string                        */
static char  charclass[5]= "\\ ]";	/* used for \d \D \i\ \I etc                 */
char        *p1;                    /* holds pointer to first pattern character  */
char        *s;                     /* string pointer                            */
int          isfo;                  /* counters for open/close subfields         */
int          isfc;                  /* counters for open/close subfields         */
int          not      = 0;          /* not mode is initially false               */
PAT         *opat;                  /* preceding (old) PAT structure (see '+')   */
PAT         *pat;                   /* current PAT structure                     */
PAT         *pathd;                 /* pathd: pointer to head of linked PATterns */
PAT         *pattl;                 /* current tail of PAT linked list           */


/* handle subfield analysis */
if(dosetbrace) {
	if(setbrace(p)) {
		return((PAT *) NULL);
		}
	}

/* intialize head of linked list to NULL */
pathd = NULL;
pat   = opat  = NULL;
isfo  = isfc  = 0;
p1    = p;

/* look over user-supplied pattern to construct PAT list	*/

for(; *p; ++p) {

	switch(*p) {	/* handle magic characters, others by default */

	case '{':	/* open subfield */
		pat       = palloc(&pathd,&pattl);
		pat->f    = sfopen;
		pat->sfo  = &stcmpma_mtch[sfo[isfo++]].start;
		continue;

	case '}':	/* close subfield */
		pat       = palloc(&pathd,&pattl);
		pat->f    = sfclose;
		pat->sfc  = &stcmpma_mtch[sfc[isfc++]].last;
		break;

	case '*':	/* zero to any number, backwards scan */
		if(!pat) goto lblnomagic;
		pat->ff= pat->f;
		pat->f = bscan;
		opat   = pat;
		pat    = NULL;
		break;

	case '+':	/* one to any number, backwards scan */
		if(!pat) goto lblnomagic;
		opat        = pat;
		pat         = palloc(&pathd,&pattl);

		/* copy opat to pat */
		pat->c      = opat->c;
		pat->range  = opat->range;
		pat->sfo    = NULL;
		pat->sfc    = opat->sfc;
		opat->sfc   = NULL;
		pat->eb     = opat->eb;
		pat->context= opat->context;
		pat->ff     = opat->f; /* set up bscan */
		pat->f      = bscan;
		opat        = pat;
		pat         = NULL;
		break;

	case '%':	/* zero to any number, forward scan */
		if(!pat) goto lblnomagic;
		pat->ff= pat->f;
		pat->f = fscan;
		opat   = pat;
		pat    = NULL;
		break;

	case '`':	/* zero or one of the pattern */
		if(!pat) goto lblnomagic;
		pat->ff= pat->f;
		pat->f = zero_one;
		opat   = pat;
		pat    = NULL;
		break;

	case '[':	/* range */
		s= ++p;
		if(*p == '\0' || *p == ']') break;

	range:	/* allocate a new PATtern and a RANGE (128) character range */
		pat= palloc(&pathd,&pattl);
		if(s == p) setrange(p,pat,&p);
		else       setrange(s,pat,(char **) NULL);
		if(not) pat->f= nrange;
		break;

	case '~':	/* not */
		not= !not;
		continue;

	case '?':	/* wildcard */
		if(not) {
			not= 0;
			goto dollar; /* ~? is same as $ */
			}
		pat   = palloc(&pathd,&pattl);
		pat->f= wildcard;
		break;

	case '\\':	/* escape: usually removes magic; some substitutions */
		++p;
		pat   = palloc(&pathd,&pattl);
		pat->f= not? nequal : equal;

		switch(*p) {

		case '_': /* \_ isspace matching */
			if(!stcmpma_underscore) {
				s= space;
				if(s == p) setrange(p,pat,&p);
				else       setrange(s,pat,(char **) NULL);
				if(not) pat->f= nrange;
				}
			else goto lblnomagic;
			break;

		case 'd': case 'D':	/* builds a [\d] or [\D] range */
		case 'i': case 'I': /* builds a [\i] or [\I] range */
		case 'l': case 'L':	/* builds a [\l] or [\L] range */
		case 'o': case 'O':	/* builds a [\o] or [\O] range */
		case 's': case 'S':	/* builds a [\s] or [\S] range */
		case 'u': case 'U':	/* builds a [\u] or [\U] range */
		case 'x': case 'X':	/* builds a [\x] or [\X] range */
			charclass[1]= *p;
			setrange(charclass,pat,(char **) NULL);
			if(not) pat->f= nrange;
			break;

		case '<':
			pat->f = not? nstartword : startword;
			opat   = pat;
			pat    = NULL;
			not    = 0;
			break;

		case '>':
			pat->f = not? nendword : endword;
			opat   = pat;
			pat    = NULL;
			not    = 0;
			break;

		default:
			pat->c= stcmpma_escape(&p);
			break;
			}
		break;

	case '^':	/* match to beginning */
		if(p[1] == '%' || p[1] == '*') {
			if(p != p1+not) goto lblnomagic;
			pat   = palloc(&pathd,&pattl);
			++p;
			pat->f= always;
			opat  = pat;
			pat   = NULL;
			}
		else {
			if(p != p1+not) goto lblnomagic;
			pat= palloc(&pathd,&pattl);
			pat->f= not? nbegin : begin;
			if(*(p+1) == '+') {
				++p;
				opat= pat;
				pat = NULL;
				}
			}
		break;

	case '$':	/* match to ending */
	dollar:
		pat= palloc(&pathd,&pattl);
		if(*(p+1) == '%' || *(p+1) == '*') {
			++p;
			pat->f= always;
			opat  = pat;
			pat   = NULL;
			}
		else {
			pat->f= not? nending : ending;
			if(*(p+1) == '+') {
				++p;
				opat= pat;
				pat = NULL;
				}
			}
		break;

	case '#': /* isdigit matching */
		s= digit;
		goto range;

	case '@': /* isalpha matching */
		s= alpha;
		goto range;

	lblnomagic:

	default: /* this character doesn't have any magic */
		if(ignorecase && isalpha(*p)) {
			pat       = palloc(&pathd,&pattl);
			nocase[0] = tolower(*p);
			setrange(nocase,pat,(char **) NULL);
			if(not) pat->f= nrange;
			}
		else {
			pat   = palloc(&pathd,&pattl);
			pat->c= *p;
			pat->f= not? nequal : equal;
			}
		break;
		}	/* switch on *p */

	/* turn not mode off */
	not= 0;
	}	/* for p loop */

/* analyze for context and save stcmpma_mcnt in pathd */
if(pathd) {
	setcontxt(pathd);
	pathd->mcnt= (char) stcmpma_mcnt;
	}

return pathd;
}

/* --------------------------------------------------------------------- */

/* stcmpma_escape: maps a char* pointer to the <character> in \<character> into:
 *
 *    \b  backspace  |
 *    \e  escape     |[ \o###     octal character       -- obsolete]
 *    \f  formfeed   |  \t        tab
 *    \h  backspace  |[ \x##      hexadecimal character -- obsolete]
 *    \n  newline    |  \:A - \:Z control character
 *    \_  [ \t^$] is not handled here
 *
 *    Will return a pointer p to end of \<character> pattern
 *    (note that \xaf, for example, is a multi-char escape pattern)
 */
char stcmpma_escape(char **p)
{
char patc;


if(!p) {
	error(XTDIO_WARNING,"stcmpma_escape: p is null\n");
	return (char) NULL;
	}

if(!*p) {
	error(XTDIO_WARNING,"stcmpma_escape: *p is null\n");
	return (char) NULL;
	}

if(!**p) patc= **p;
else switch(**p) { /* escape changes following characters... */

case 'e':			/* \e => escape			*/
	patc= '\033';
	break;

case 'f':			/* \f => formfeed		*/
	patc= '\f';
	break;

case 'b':			/* \b => backspace		*/
case 'h':			/* \h => backspace		*/
	patc= '\010';
	break;

case 'n':			/* \n => newline		*/
	patc= '\n';
	break;

case 'o':			/* \o### => octal		*/
case '0':			/* \0### => octal		*/
	if(isoct((*p)[1])) {
		char ptmp;
		int  po;
		int  notoct= 2;

		if(isoct(*p[2])) notoct= isoct(*p[3])? 4 : 3;
		ptmp     = *p[notoct];
		p[notoct]= '\0';
		sscanf(*p+1,"%o",&po);
		*p[notoct]= ptmp;
		*p       += notoct - 1;
		patc      = (char) po;
		}
	else patc= **p;
	break;

case 't':			/* \t => tab			*/
	patc= '\t';
	break;

case 'x':			/* \x## => hexadecimal */
	if(ishex(*p[1])) {
		char ptmp;
		int  px;
		int  nothex= 2;

		if(ishex(*p[2])) nothex= 3;
		ptmp       = *p[nothex];
		*p[nothex] = '\0';
		sscanf(*p+1,"%x",&px);
		*p[nothex] = ptmp;
		*p        += nothex - 1;
		patc       = (char) px;
		}
	else patc= **p;
	break;

case '\\':
	patc= '\\';
	break;

case ':':
	if(isupper(*p[1])) {
		patc= (*p[1] - 'A' + 1);
		++p;
		}
	else patc= ':';
	break;

default:			/* uppercase => associated control character	*/
					/* otherwise, just copy the character			*/
	patc= isupper(**p)? (**p - 'A' + 1) : **p;
	break;
	}

return patc;
}

/* ---------------------------------------------------------------------- */

/* palloc: allocates and initializes a PATtern structure */
static PAT *palloc(PAT **pathd,PAT **pattl)
{
PAT *pat;


/* allocate a PATtern structure */
pat= (PAT *) malloc(sizeof(PAT));
if(*pathd) (*pattl)->nxt= pat;
else        *pathd       = pat;

*pattl      = pat;
pat->c      = '\0';
pat->range  = NULL;
pat->sfo    = pat->sfc= NULL;
pat->f      = pat->ff = NULL;
pat->eb     = 0;
pat->context= 0;
pat->nxt    = NULL;

return pat;
}

/* ---------------------------------------------------------------------- */

/* setbrace: this analyzes the pattern "p" for subfield braces */
static int setbrace(char *p)
{
char *p2;
char *phd;
int   isfc2;
int   isfc=0;
int   isfo=0;
int   lev;



isfc2       = isfc;
stcmpma_mcnt= 0;	/* initialize subfield count to zero	*/
phd         = p;	/* save pointer to head of pattern	*/

do {

	/* locate subfield opening '{' */
	for(isfc= isfc2; *p && *p != '{'; ++p) {
		if    (*p == '\\' && *(p+1)) ++p;
		else if(*p == '}')           ++isfc;
		}

	if(!*p) break;
	sfo[isfo++]= stcmpma_mcnt;

	/* having located '{', find associated closing '}' */
	isfc2= isfc;
	for(p2= p + 1, lev= 1; *p2; ++p2) {
		if(*p2 == '\\' && *(p2+1)) ++p2;
		else if(*p2 == '{') ++lev;
		else if(*p2 == '}') {
			--lev; ++isfc;
			if(lev == 0) break;
			}
		}
	if(*p2 == '\0') { /* unbalanced {} */
		error(XTDIO_WARNING,"setbrace:  unbalanced {} in p<%s>\n",phd);
		fprintf(stderr,"\tCouldn't find matching '}' for <%s>\n",p);
		return 1;
		}

	sfc[isfc-1]= stcmpma_mcnt++;
	isfc= isfc2 + 1;
	} while(*(p++) && stcmpma_mcnt < MTCHMAX);

return 0;
}

/* ---------------------------------------------------------------------- */

/* setrange: sets up a range */
static int setrange(
  char  *p,				/* current pattern character pointer					*/
  PAT   *pat,			/* place range into this PAT							*/
  char **pend)			/* pattern moves up to this position at end of range	*/
{
char  rngset = 0;
char *pp;
char *pp2;
int   i;
int   not    = 0;


/* allocate a pattern range. Set to all false, *unless* the first character
 * in the range is a ~.  In that case, set to all true
 */
pat->range= (char *) calloc((size_t) RANGE,sizeof(char));
if(!pat->range) { /* ran out of memory */
	error(XTDIO_ERROR,"ran out of memory allocating a range\n");
	}

/* determine how to initialize range PATtern */
rngset= p[0] == '~';

/* initialize range PATtern */
for(i= 1; i < RANGE; ++i) pat->range[i]= rngset;
pat->range[0]= (char) 0;	/* never match to null byte		*/
pat->f       = range;		/* pattern function is range	*/
pat->eb      = 0;			/* initially, no end/begin		*/
pat->c       = '\0';		/* match character is null		*/

/* if ignorecase, convert all PATtern alphamerics to lower case first */
if(ignorecase) for(pp= p; *pp && *pp != ']'; ++pp) {
	if(*pp == '\\' && pp[1] == ']') ++pp;
	else if(isupper(*pp))           *pp= tolower(*pp);
	}

/* determine range */
for(pp= p; *pp && *pp != ']'; ++pp) {


	/* backslash: special processing */
	if(*pp == '\\' && *(pp+1)) {
		++pp;
		switch(*pp) {

		case 'd':	/* [\d] : digits */
			for(i= (int) '0'; i <= (int) '9'; ++i) pat->range[i]= (char) !not;
			break;

		case 'D':	/* [\D] : non-digits */
			for(i= 0; i < RANGE; ++i) if(i < '0' && '9' < i) pat->range[i]= (char) !not;
			break;

		case 'i':	/* [\i] : identifier characters [a-zA-Z0-9_] (also '$' for vms) */
			for(i= (int) 'a'; i <= (int) 'z'; ++i) pat->range[i]= (char) !not;
			for(i= (int) 'A'; i <= (int) 'Z'; ++i) pat->range[i]= (char) !not;
			for(i= (int) '0'; i <= (int) '9'; ++i) pat->range[i]= (char) !not;
			pat->range['_']= (char) !not;
#ifdef vms
			pat->range['$']= (char) !not;
#endif
			break;

		case 'I':	/* [\I] : identifier characters excluding digits (also '$' for vms) */
			for(i= (int) 'a'; i <= (int) 'z'; ++i) pat->range[i]= (char) !not;
			for(i= (int) 'A'; i <= (int) 'Z'; ++i) pat->range[i]= (char) !not;
			pat->range['_']= (char) !not;
#ifdef vms
			pat->range['$']= (char) !not;
#endif
			break;

		case 'l':	/* [\l] : matches lower case characters [a-z] */
			for(i= 'a'; i <= 'z'; ++i) pat->range[i]= (char) !not;
			break;

		case 'L':	/* [\L] : matches non-lowercase characters [~a-z] */
			for(i= 0; i < 'a'; ++i)         pat->range[i]= (char) !not;
			for(i= 'z' + 1; i < RANGE; ++i) pat->range[i]= (char) !not;
			break;

		case 'o':	/* [\o] : matches octal digits [0-7] */
			for(i= (int) '0'; i <= (int) '7'; ++i) pat->range[i]= (char) !not;
			break;

		case 'O':	/* [\O] : matches non-octal digits [~0-7] */
			for(i= 0; i < RANGE; ++i) if(i < '0' && '7' < i) pat->range[i]= (char) !not;
			break;

		case '_':	/* matches any whitespace character (space, tab) */
		case 's':	/* matches any whitespace character (space, tab) */
			pat->range[' '] = (char) !not;
			pat->range['\t']= (char) !not;
			break;

		case 'S':	/* matches any non-whitespace character (!space,!tab) */
			for(i= 0; i < RANGE; ++i) pat->range[i]= (char) !not;
			break;

		case 'u':	/* [\u] : matches upper case characters [a-z] */
			for(i= 'A'; i <= 'Z'; ++i) pat->range[i]= (char) !not;
			break;

		case 'U':	/* [\U] : matches non-uppercase characters [~a-z] */
			for(i= 0; i < 'A'; ++i)         pat->range[i]= (char) !not;
			for(i= 'Z' + 1; i < RANGE; ++i) pat->range[i]= (char) !not;
			break;

		case 'x':	/* matches any hexadecimal digit [0-9a-fA-F] */
			for(i= (int) '0'; i <= (int) '9'; ++i) pat->range[i]= (char) !not;
			for(i= (int) 'a'; i <= (int) 'f'; ++i) pat->range[i]= (char) !not;
			for(i= (int) 'A'; i <= (int) 'F'; ++i) pat->range[i]= (char) !not;
			break;

		case 'X':	/* matches any non-hexadecimal digit [~0-9a-fA-F] */
			for(i= 0; i < RANGE; ++i)
			  if(!('0' <= i && i <= '9') &&
				 !('a' <= i && i <= 'f') &&
				 !('A' <= i && i <= 'F')) pat->range[i]= (char) !not;
			break;

		case '<':	/* \< : start of word */
			if(not) pat->eb|= NOT|STARTWORD;
			else    pat->eb|= STARTWORD;
			not= 0;
			break;

		case '>':	/* \> : end of word */
			if(not) pat->eb|= NOT|ENDWORD;
			else    pat->eb|= ENDWORD;
			not= 0;
			break;

		default:
			pat->range[(int) stcmpma_escape(&pp)] = (char) !not;
			break;
			}
		continue;
		}

	else if(*pp == '~') {
		not= !not;
		continue;
		}

	/* begin-line character */
	else if(*pp == '^') {
		if(not) pat->eb|= NOT|CARAT;
		else    pat->eb|= CARAT;
		not= 0;
		continue;
		}

	/* end-of-line character */
	else if(*pp == '$') {
		if(not) pat->eb|= NOT|DOLLAR;
		else    pat->eb|= DOLLAR;
		not= 0;
		continue;
		}

	/* shorthand for digits */
	else if(*pp == '#') {
		for(i= ((int) '0'); i <= ((int) '9'); ++i) pat->range[i]= (char) !not;
		continue;
		}

	/* shorthand for alphameric */
	else if(*pp == '@') {
		if(not) {
			for(i= 'A'; i <= 'Z'; ++i) pat->range[i]= (char) 0;
			for(i= 'a'; i <= 'z'; ++i) pat->range[i]= (char) 0;
			not= 0;
			}
		else {
			for(i= 'A'; i <= 'Z'; ++i) pat->range[i]= (char) 1;
			for(i= 'a'; i <= 'z'; ++i) pat->range[i]= (char) 1;
			}
		continue;
		}

	/* shorthand for white space and begin/end line */
	else if(*pp == '_') { /* white space and begin/end */
		if(stcmpma_underscore) {
			if(not) {
				for(i= 1; i < RANGE; ++i) if(isspace((char) i)) pat->range[i]= (char) 0;
				pat->eb|= NOT|DOLLAR|CARAT;
				not= 0;
				}
			else {
				for(i= 1; i < RANGE; ++i) if(isspace((char) i)) pat->range[i]= (char) 1;
				pat->eb|= DOLLAR|CARAT;
				}
			}
		else pat->range[*pp]= !not;
		continue;
		}

	/* range handler */
	if(*(pp+1) == '-') { /* range encountered */
		pp2= pp + 2;
		if(*pp2 == '\\') ++pp2;
		if(not) { /* not a range */
			for(i= (int) *pp; i <= (int) *pp2; ++i) pat->range[i]= (char) 0;
			not= 0;
			}
		else { /* a range */
			for(i= ((int) *pp); i <= ((int) *pp2); ++i)
			  pat->range[i]= (char) 1;
			}
		pp= pp2;
		continue;
		}

	/* no magic character */
	if(not) { /* not a specific character */
		pat->range[*pp]= (char) 0;
		not            = 0;
		}
	else pat->range[*pp]= (char) 1;
	}

/* ignore case: use lower case to control PATtern range */
if(ignorecase) {
	char c;
	for(c= 'a'; c <= 'z'; ++c) pat->range[toupper(c)]= pat->range[c];
	}

/* if normal range, then set pend to ending ']' */
if(pend) *pend= pp;
return 0;
}

/* ---------------------------------------------------------------------- */

/* setcontxt: this function determines whether or not the context will
 *	matter to the forward/backward scan multiple matching routines
 *	(bswild,fsrange, etc).
 */
static int setcontxt(PAT *pathd)
{
char c[2];
int  len;
PAT *pat  = NULL;
PAT *npat = NULL;
PAT *tpat = NULL;

#ifdef __PROTOTYPE__
int (*f)(char *,PAT **,int *);
int (*nf)(char *,PAT **,int *);
#else
int (*f)();
int (*nf)();
#endif


/* initialize */
c[0]= c[1]= '\0';

/* look over entire PATtern */
for(pat= pathd; pat; pat= npat) {
	npat= pat->nxt;

	/* skip over subfield control PATterns (sfopen, sfclose) */
	while(npat && (npat->f == sfopen || npat->f == sfclose)) npat= npat->nxt;
	if(npat == NULL) {
		pat->context= 0;
		continue;
		}

	/* only if present PATtern is a multiple-match type (fscan,bscan) is a
	 * context match ever needed.  The only types of matching functions which
	 * may also be of bscan/fscan type are wildcard, equal, nequal, and range.
	 */
	if(pat->f != bscan && pat->f != fscan) continue;

	/* set up f and nf */
	f= (pat->f == bscan || pat->f == fscan)? pat->ff : pat->f;
	nf= (npat->f == bscan || npat->f == fscan)? npat->ff : npat->f;

	/* determine if context matching is required. */
	if(f == wildcard) pat->context= 1;
	else if(nf == equal || nf == nequal) {
		c[0]= npat->c;
		tpat= pat;
		pat->context= (*f)(c,&tpat,&len);
		}
	else if(f == equal || f == nequal) {
		c[0]= pat->c;
		tpat= npat;
		pat->context= (*nf)(c,&tpat,&len);
		}
	else if(f == range && nf == range) pat->context= 1;
	else pat->context= 0;
	}
return 0;
}

/* =========================================================================
 *	Subfield Open/Close
 * =========================================================================
 */

/* sfopen: opens subfield */
static int sfopen(char *s,PAT **pat,int *len)
{

*((*pat)->sfo)= s;
*len          = 0;

return 1;
}

/* ---------------------------------------------------------------------- */

/* sfclose: closes a subfield */
static int sfclose(char *s,PAT **pat,int *len)
{

*((*pat)->sfc)= s - 1;
*len          = 0;

return 1;
}


/* ===================================================================
 * One Character Tests
 * ===================================================================
 */

/* equal: tests if string character and PATtern are equal */
static int equal(char *s,PAT **pat,int *len)
{

if(*s == (*pat)->c) {
	*len= 1;
	return 1;
	}
*len= 0;

return 0;
}

/* ---------------------------------------------------------------------- */

/* nequal: tests if string character and PATtern are not equal */
static int nequal(char *s,PAT **pat,int *len)
{

if(*s && *s != (*pat)->c) {
	*len= 1;
	return 1;
	}
*len= 0;

return 0;
}

/* ---------------------------------------------------------------------- */

/* nrange: tests if string character doesn't satisfy range */
static int nrange(char *s,PAT **pat,int *len)
{
int ret;

if(*s) ret= *len= !range(s,pat,len);
else if(((*pat)->eb & NOT) && ((*pat)->eb & DOLLAR)) { /* end-of-string and ~$ in (not) range */
	ret = 1;
	*len= 0;
	}
else ret= *len= 0;

return ret;
}

/* ---------------------------------------------------------------------- */

/* range: tests if string character lies in PATtern range */
static int range(char *s,PAT **pat,int *len)
{
int ret;
PAT *pathld;


pathld= *pat;
ret   = pathld->range[(int) *s]; /* check if character in range */
if(ret) {
	*len= 1;
	return ret;
	}

*len= 0;
if(pathld->eb) { /* ending/beginning/startword/endword tests */
	if        (pathld->eb & CARAT)  ret= (pathld->eb & NOT)? (s != sbeg)  : (s == sbeg);
	if(!ret && pathld->eb & DOLLAR) ret= (pathld->eb & NOT)? (*s != '\0') : (*s == '\0');
	if(!ret && pathld->eb & STARTWORD) {
		ret= s == sbeg || ispunct(s[-1]) || isspace(s[-1]);
		if(pathld->eb & NOT) ret= !ret;
		}
	if(!ret && pathld->eb & ENDWORD) {
		ret= *s == '\0' || ispunct(s[1]) || isspace(s[1]);
		if(pathld->eb & NOT) ret= !ret;
		}
	}

return ret;
}

/* ---------------------------------------------------------------------- */

/* wildcard: matches to any character */
static int wildcard(char *s,PAT **pat,int *len)
{

/* wildcard matches to everything but an end-of-string */
*len= *s != '\0';

return *len;
}

/* ===================================================================
 *  Multiple Character tests
 * ===================================================================
 */

/* bscan: implements '*' and '+' as a backward scan */
static int bscan(char *s,PAT **pat,int *len)
{
char *ss;
int length,ret,testonce;
PAT *pat2;


/* 1) move rightwards as far as possible given pat */
pat2= *pat;
for(ss= s; *ss; ++ss) {
	ret= (*pat2->ff)(ss,&pat2,&length);
	if(!ret || !length) break;
	}
*len= ret? length : 0;

/* 2) move backwards if context is true */
if((*pat)->context) {
	pat2= (*pat)->nxt;
	for(testonce= 1; ss >= s || testonce; --ss, testonce= 0)
	  if(stcmpmaP(ss,&pat2,&length)) {
		*len= ((int) (ss - s)) + length;
		if((*pat)->sfc) {
			*((*pat)->sfc)= (*ss)? ss : (ss - 1);
			}
		*pat= pat2;
		return 1;
		}
	/* if context enabled, but no matches, then no match here, either */
	return 0;
	}


*len= (int) (ss - s);

return 1;
}

/* ---------------------------------------------------------------------- */

/* fscan: implements '%' forward scan */
static int fscan(char *s,PAT **pat,int *len)
{
char *ss;
int length;
int tryend;
PAT *pat2;


/* initialize */
*len= 0;

/* 1) if context, move rightwards until context match occurs */
if((*pat)->context) {
	pat2= (*pat)->nxt;

	/*	if(pat2) while(pat2->f == sfclose) {  * close subfields *
	 *		sfclose(s,&pat2,&length);
	 *		pat2= pat2->nxt;
	 *		if(pat2 == NULL) break;
	 *		}
	 */
	if(pat2) for(ss= s, tryend= 1; tryend; ++ss) {
		if(!*ss) tryend= 0;
		if(stcmpmaP(ss,&pat2,&length)) {
			*len= ((int) (ss - s)) + length;
			if((*pat)->sfc) {
				*((*pat)->sfc)= (*ss)? ss : (ss - 1);
				}
			*pat= pat2;
			return 1;
			}
		}
	return 0;
	}

/* 2) if not context, move as far rightwards as matching allows */
for(ss= s; *ss && (*(*pat)->ff)(ss,pat,len); ++ss) if(!*len) break;

/* return status */
*len= (int) (ss - s);
return 1;
}

/* ---------------------------------------------------------------------- */

/* zero_one: PATtern may (or may not) match one character */
static int zero_one(char *s,PAT **pat,int *len)
{

/* initialize */
*len= 0;

/* perform pattern matching subfunction */
(*(*pat)->ff)(s,pat,len);

/* return status */
return 1;
}

/* ===================================================================
 *  Conditions: These tests may match, but with zero length
 * ===================================================================
 */

/*	ending:	  tests if string ends */
static int ending(char *s,PAT **pat,int *len)
{
int ret;


*len= 0;
ret = *s == '\0';

return ret;
}

/* ---------------------------------------------------------------------- */

/* begin: tests if string begins */
static int begin(char *s,PAT **pat,int *len)
{
int ret;


*len= 0;
ret = s == sbeg;

return ret;
}

/* ---------------------------------------------------------------------- */

/* nending: tests if string doesn't end */
static int nending(char *s,PAT **pat,int *len)
{
int ret;


*len= 0;
ret = *s != '\0';

return ret;
}

/* ---------------------------------------------------------------------- */

/* nbegin: tests if string doesn't begin */
static int nbegin(char *s,PAT **pat,int *len)
{
int ret;

*len= 0;
ret = s != sbeg;

return ret;
}

/* ---------------------------------------------------------------------- */

/* startword: this function determines if pointing to a potential start-of-word */
static int startword(char *s,PAT **pat,int *len)
{
int ret;

*len= 0;
ret = s == sbeg || ispunct(s[-1]) || isspace(s[-1]);

return ret;
}

/* ---------------------------------------------------------------------- */

/* nstartword: this function determines if *not* pointing to a potential start-of-word */
static int nstartword(char *s,PAT **pat,int *len)
{
int ret;

*len= 0;
ret = !(s == sbeg || ispunct(s[-1]) || isspace(s[-1]));

return ret;
}

/* ---------------------------------------------------------------------- */

/* endword: this function determines if pointing to a potential end-of-word */
static int endword(char *s,PAT **pat,int *len)
{
int ret;

*len= 0;
ret = *s == '\0' || ispunct(s[1]) || isspace(s[1]);

return ret;
}

/* ---------------------------------------------------------------------- */

/* nendword: this function determines if *not* pointing to a potential end-of-word */
static int nendword(char *s,PAT **pat,int *len)
{
int ret;

*len= 0;
ret = !(*s == '\0' || ispunct(s[1]) || isspace(s[1]));

return ret;
}

/* --------------------------------------------------------------------- */

/* always: always matches but with zero length */
static int always(char *s,PAT **pat,int *len)
{
int ret;


*len= 0;
ret = 1;

return ret;
}

/* ---------------------------------------------------------------------- */

/* ISMAGIC: determines if c is one of the magic characters */
static int ISMAGIC(char c)
{
static char magic[]="{}*+%[~?^$#@_|&!";
char *m;

for(m= magic; *m; ++m) if(*m == c) return 1;
return 0;
}

/* ---------------------------------------------------------------------- */

/* stcmsetcase: this function */
void stcmsetcase(int in_ignorecase)
{

ignorecase= in_ignorecase;

}

/* ===================================================================== */
/* ===================================================================== */
