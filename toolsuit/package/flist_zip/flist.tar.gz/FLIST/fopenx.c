/* fopenx.c: this opens a file with a suggested extension.  It allows the
 *  input filename to be missing the provided extension.
 *
 *  Routines Include: <fopenx.c>
 *    FILE *fopenx( char *filename,  char *mode,  char *ext,  char *env_var)
 *    void fopensave(char *fmt,...)
 */
#include <stdio.h>
#include "xtdio.h"

/* ---------------------------------------------------------------------- */

/* fopenx: fopen with automatic extension handling and PATH-ing
 *
 *  Returns: success = a valid FILE pointer
 *           failure = a null FILE pointer
 *                     fopen[xv]file will be freed and nulled on failure
 *
 *  Side Effects:
 *   fopenfilename will point to the full pathname of any successfully
 *                 opened file.
 */
FILE *fopenx(
  char *filename,	/* name of file to be opened, may be missing suffix */
  char *mode,    	/* r for reading, w for writing                     */
  char *ext,     	/* extension/suffix: may or may not have leading .  */
  char *env_var) 	/* environment variable for PATH-like searching     */
{
char *dirsep= NULL;
char *fn_ext= NULL;
FILE *fp    = NULL;


/* sanity checks */
if(!filename) {
	error(XTDIO_WARNING,"fopenx: null filename\n");
	return fp;
	}

if(!mode) {
	error(XTDIO_WARNING,"fopenx: null mode\n");
	return fp;
	}

if(!ext) {	/* no user-supplied extension, use fopenv */
	fp= fopenv(filename,mode,env_var);
	if(fp) fopensave(filename);
	return fp;
	}

/* ignore leading . in ext if any */
if(ext[0] == '.') ++ext;

#ifdef vms
/* locate extension (if any) */
dirsep= strchr(filename,']');
if(!dirsep) dirsep= strrchr(filename,':');
fn_ext= strrchr(filename,'.');
if(fn_ext < dirsep) fn_ext= NULL;
#endif

#ifdef unix
dirsep= strrchr(filename,'/');
fn_ext= strrchr(filename,'.');
if(fn_ext < dirsep) fn_ext= NULL;
#endif

#ifdef msdos
dirsep= (char *) strrchr(filename,'\\');
fn_ext= (char *) strrchr(filename,'.');
if(fn_ext < dirsep) fn_ext= NULL;
#endif

#ifdef AZTEC_C
dirsep= strrchr(filename,'/');
fn_ext= strrchr(filename,'.');
if(fn_ext < dirsep) fn_ext= NULL;
#endif

/* get fn_ext to point just past '.', too */
if(fn_ext) ++fn_ext;

/* filename has extension already provided, and it matches */
if(fn_ext && !strcmp(fn_ext,ext)) {

	/* use environment variable */
	if(env_var && env_var[0]) {
		fp= fopenv(filename,mode,env_var);
		}

	/* look only in current directory */
	else {
#ifdef __WIN32__
		fp= cygfopen(filename,mode);
#else
		fp= fopen(filename,mode);
#endif
		if(fp) fopensave(filename);
		}

	return fp;
	}

#ifdef vms
/* append suggested extension to filename (removing current extension if any) */
if(fn_ext) fopensave("%s%s", filename,fn_ext);
else       fopensave("%s.%s",filename,ext);
#else
/* append suggested extension to filename */
fopensave("%s.%s",filename,ext);
#endif

/* open the file and use environment variable */
if(env_var && env_var[0]) {
	fp= fopenv(fopenfilename,mode,env_var);
	}

/* open file but look only in current directory */
else {
	fp= fopen(fopenfilename,mode);
	}

return fp;
}

/* --------------------------------------------------------------------- */


/* --------------------------------------------------------------------- */
