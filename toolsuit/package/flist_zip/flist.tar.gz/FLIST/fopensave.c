/* fopensave.c:
 * Author:	Charles E. Campbell, Jr.
 * Date:	Mar 28, 2005
 */
#include <stdio.h>
#include <stdarg.h>
#include "xtdio.h"

/* ----------------------------------------------------------------------
 * Definitions:
 */
#define FILEPUTSIZ	256

/* ---------------------------------------------------------------------
 * Global Variables:
 */
char *fopenfilename= NULL;

/* --------------------------------------------------------------------- */

/* fopensave: put a filename into the fopenfilename.  Note that the
 *   fopenfilename buffer constantly grows.  Holds [path]file[.extension]
 */
void fopensave(char *fmt,...)
{
va_list         args;
char           *arg       = NULL;
char           *percent   = NULL;
int             fmtlen;
static char    *fsbuf1    = NULL;
static char    *fsbuf2    = NULL;
static char    *fsbuf3    = NULL;
static char    *fsbuf4    = NULL;
static size_t   fsbuflen1 = 0;
static size_t   fsbuflen2 = 0;
static size_t   fsbuflen3 = 0;
static size_t   fsbuflen4 = 0;
static char   **fsbuf     = NULL;
static size_t  *fsbuflen  = NULL;


/* determine necessary buffer length: sum of length of strings passed plus length of fmt
 * plus 2 bytes (thus it should be a bit longer than minimum)
 */
fmtlen= strlen(fmt) + 2;
va_start(args,fmt);
for(percent= strchr(fmt,'%'); percent; percent= strchr(percent+2,'%')) {
	arg     = va_arg(args,char *);
	fmtlen += strlen(arg);
	}
va_end(args);
fmtlen= FILEPUTSIZ*((fmtlen + FILEPUTSIZ)/FILEPUTSIZ);

/* maintain a rolling buffer set */
if     (!fsbuf)           fsbuf= &fsbuf1, fsbuflen= &fsbuflen1;
else if(*fsbuf == fsbuf1) fsbuf= &fsbuf2, fsbuflen= &fsbuflen2;
else if(*fsbuf == fsbuf2) fsbuf= &fsbuf3, fsbuflen= &fsbuflen3;
else if(*fsbuf == fsbuf3) fsbuf= &fsbuf4, fsbuflen= &fsbuflen4;
else                      fsbuf= &fsbuf1, fsbuflen= &fsbuflen1;

/* allocate or re-allocate *fsbuf as needed */
if(fmtlen > *fsbuflen) {
	*fsbuflen= fmtlen;
	if(!*fsbuf) *fsbuf= (char *) calloc(*fsbuflen,sizeof(char));
	else        *fsbuf= (char *) realloc(*fsbuf,*fsbuflen*sizeof(char));
	outofmem(*fsbuf,"fopensave: unable to allocate %u-byte buffer\n",fmtlen);
	}

/* put formatted info into fopenfilename buffer */
va_start(args,fmt);
vsprintf(*fsbuf,fmt,args);
va_end(args);
fopenfilename= *fsbuf;

}

/* ===================================================================== */
/* ===================================================================== */
