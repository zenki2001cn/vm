/* fopenv.c : this function attempts to open a file based on the
 *   environment variable if an fopen in the current directory fails.
 *   The environment string can have ";" as separators for multiple
 *   path searching.  Returns a NULL pointer if unsuccessful.
 */
#include <stdio.h>
#include <ctype.h>
#include "xtdio.h"

/* -----------------------------------------------------------------------
 * Definitions:
 */
#define CTRLBUF	32
#ifdef unix
# define PATHSEP ":"
#endif

#ifdef _AIX
# define PATHSEP ":"
#endif

#ifdef vms
# define PATHSEP ";"
#endif

#ifdef AZTEC_C
# define PATHSEP ";,"
#endif

#if defined(MSDOS) || defined(__BORLANDC__)
# define msdos
# define PATHSEP ";,"
#endif

#ifndef PATHSEP
# define PATHSEP ":"
#endif

/* -----------------------------------------------------------------------
 * Local Variables:
 */
static char *fopenvdflt= NULL;

/* -----------------------------------------------------------------------
 * Source Code:
 */

/* fopenv: opens file for read/write based on environment variable
 *	char *filename : name of file to be opened
 *	                                      from/to current     using
 *	char *ctrl     :  ctrl    attempt to    directory       env path
 *	                  ----    ----------  ---------------   --------
 *	                  "r"     read             1st            2nd
 *	                  "R"     read             ---            only
 *	                  "w"     write            2nd            1st
 *	                  "W"     write            ---            only
 *	                  "a"     append           2nd            1st
 *	                  "A"     append           ---            only
 *
 *	char *env_var  : environment variable to be used.  If null
 *	                 or env_var is "", will be as a regular fopen().
 *
 *	                 If the requested environment variable doesn't
 *	                 exist, for lower-case ctrl fopenv() will still
 *	                 behave like a regular fopen().  For upper-case
 *	                 ctrl, fopenv() will then fail (with a NULL pointer).
 *
 * Side Effect: fopenfilename will point to any successfully opened file.
 *              It will be overwritten every time fopenv(), fopenx(), or
 *              fopenf() is called.
 */
FILE *fopenv(
  char *filename,
  char *ctrl,    
  char *env_var) 
{
FILE *fp       = NULL;
char  charhold;
char  ctrlbuf[CTRLBUF];
char *brk      = NULL;
char *endchar  = NULL;
char *env      = NULL;
char *s        = NULL;


#ifdef msdos
/* an exception for "good" old stupid msdos */
for(s= env_var; *s; ++s) if(islower(*s)) *s= toupper(*s);
#endif

/* check out the environment variable */
env= (env_var && *env_var)? getenv(env_var) : NULL;
if(!env) {
	env= fopenvdflt;
	}

/* copy ctrl string to ctrlbuf so it's case may be manipulated as needed */
strcpy(ctrlbuf,ctrl);
if(isupper(ctrl[0])) {
	ctrlbuf[0]= tolower(ctrlbuf[0]);
	}

/* attempt to read file in current directory */
if(ctrl[0] == 'r') {
	/* see if file can be opened in current directory first */
#ifdef __WIN32__
	fp= cygfopen(filename,ctrlbuf);
#else
	fp= fopen(filename,ctrlbuf);
#endif
	if(fp) {
		fopensave("%s",filename);
		return fp;
		}
	}

/* attempt to open filename using environment search (if not open-for-write)
 * If 'w'is selected, then a write should succeed in the current directory,
 * so use that.
 */
if(env && ctrl[0] != 'w') {

	for(s= brk= env; brk; s= brk + 1) {

		/* determine end-of-token pointers brk and endchar */
		brk    = stpbrk(s,PATHSEP);
		endchar= brk? brk-1 : s+strlen(s)-1;

		/* terminate token with null byte */
		charhold  = endchar[1];
		endchar[1]= '\0';

#ifdef vms
		if(*endchar == ':' || *endchar == ']') fopensave("%s%s",s,filename);
		else                                   fopensave("[%s]%s",s,filename);
#endif
#ifdef unix
		if(*endchar == '/')  fopensave("%s%s",s,filename);
		else                 fopensave("%s/%s",s,filename);
#endif
#ifdef LATTICE
		if(*endchar == '\\') fopensave("%s%s",s,filename);
		else                 fopensave("%s\\%s",s,filename);
#endif
#ifdef DESMET
		if(*endchar == '\\') fopensave("%s%s",s,filename);
		else                 fopensave("%s\\%s",s,filename);
#endif
#ifdef msdos
		if(*endchar == '\\') fopensave("%s%s",s,filename);
		else                 fopensave("%s\\%s",s,filename);
#endif
#ifdef AZTEC_C
		if(*endchar == ':' || *endchar == '/') fopensave("%s%s",s,filename);
		else                                   fopensave("%s/%s",s,filename);
#endif

		/* attempt to open file given the path */
		fp= fopen(fopenfilename,ctrlbuf);

		if(fp) { /* successfully opened file */
			return fp;
			}
		endchar[1]= charhold;
		}
	}	/* if env ... */

/* attempt to write/append file in current directory */
if(!fp && (ctrl[0] == 'w' || ctrl[0] == 'a')) {
	fp= fopen(filename,ctrlbuf);
	if(fp) {
		fopensave("%s",filename);
		return fp;
		}
	}

/* return NULL pointer, thereby indicating a bit of a lack of success */
return (FILE *) NULL;
}

/* --------------------------------------------------------------------- */

/* fopenvDflt: this function sets a default string in case the environment variable {{{2
 *             doesn't exist.
 */
void fopenvDflt(char *i_fopenvdflt)
{

if(i_fopenvdflt) {
	if(fopenvdflt) free(fopenvdflt);
	stralloc(fopenvdflt,i_fopenvdflt,"fopenvDflt()");
	}
else {
	if(fopenvdflt) free(fopenvdflt);
	fopenvdflt= NULL;
	}

}

/* -----------------------------------------------------------------------
 * Test Code:
 */

/* --------------------------------------------------------------------- */
