/* flist.c: makes various reports on functions in a C/C++ file
 *          (found,used-lists prototypes externs trees latex-tree-pictures)
 *
 *  Usage  : flist [-options] filename1 [filename2 [filename3 ...]]
 *  Author : Dr. Charles E. Campbell, Jr.
 *  Version: 22
 *
 *  History: {{{1
 *     v22    09/09/05   - -h will now include a line to set command height to 2 if needed
 *     v21    03/24/04   - namelinefmt bug found&fixed (a %%s instead of %s was showing up)
 *                       - added Latex tree support
 *            08/04/04   - nflag to suppress newline insertion
 *     v2.20   8/27/2002 - improved hints (uses <c-o> now); its shorter, no marks used
 *     v2.19   1/ 4/2001 - added -Tg report
 *     v2.18   9/ 6/2000 - works with template <> stuff in function headers
 *     v2.17b  8/18/2000 - -h=hl_groupname now supported for hints
 *     v2.17a 12/16/1999 - hints now includes class member functions for C++
 *     v2.17  12/14/1999 - includes -h option
 *     v2.16a 11/ 8/1999 - fixed problem exemplified by <tst39.c>: int main(int argc,argv[]){}
 *                         was terminating function pick-up.  Fix to v2.16 fix.
 *     v2.16  10/28/1999 - handles c++'s operator<<, operator>>, operator?=, operator[]
 *                         function recognition.
 *     v2.15   7/23/1999 - included more usage notes
 *                       - fixed recursive descent (dodir)
 *                       - included dummy-function generation (-D option)
 *                       - unused variables removed
 *     v2.14   7/12/1999 - made most functions static
 *     v2.13a  4/12/1999 - -Tfs didn't set up psname; now it does
 *     v2.13   4/ 7/1999 - improved ctree report handling and linenum_last
 *     v2.12a  2/19/1998 - added trailing / to tag search patterns
 *     v2.12   6/25/1997 - installed ctree-like reports (-Tf, -Tu, -Tt)
 *     v2.11   6/11/1997 - installed dodir
 *                       - now allows whitespace preceding # for preprocessing statements
 *                       - now skips #pragma asm ... #pragma endasm  lines
 *     v2.10   6/ 6/1997 - handles *.l and *.y files (lex and yacc)
 *     v2.09  12/18/1996 - -S and -s flipped meanings
 *                         -G became -g
 *     v2.08  10/23/1996 - "-F filename" code installed
 *
 *     Output consists of the files' names (filenames) and a list of
 *     functions contained therein.  This software assumes that the
 *     language is C for *.c, C++ for *.cpp, *.c++, *.C, and Lex
 *     for *.l files.
 *
 *  Routines Include: <flist.c> {{{1
 *    int main(int argc,char **argv)
 *    static void GenerateCtreeReport(int argc,char **argv)
 *    int options(char **s,char **a)
 *    static void fprior(int parmqty,PARMDEF *parms)
 *    static void makePatMatch(char *pattern)
 *    static void flist(char *filename)
 *    static void makeETag(char *filename)
 *    static int inwhite(void)
 *    static int incomment(void)
 *    static int instring(char delim)
 *    static int incurly(void)
 *    static int isfunction(void)
 *    static void cmmnt_output(void)
 *    static void commonOutput(char *buf,char *leader,char *cmmnt)
 *    static void ctree_output(void)
 *    static void ctree_defaultnamelist(void)
 *    static void ext_output(void)
 *    static void patmatch_output(void)
 *    static void proto_output(void)
 *    static void std_output(void)
 *    static void output_dummyfunc(void)
 *    static void tags_output(void)
 *    static void CheckPatMatch(void)
 *    static void stripUserVar(char *argbuf)
 *    static void ioreset(int mode)
 *    static char nxtc(char *routine)
 *    static char *flist_preprocess(void)
 *    static void skipdirlines(void)
 *    static void nxtline(void)
 *    static char *prtword(char *wbgn,char *wend)
 *    static void tags_generate(void)
 *    static int tag_compare(const char **tag1,const char **tag2)
 *    static int hdrtagmerge(void)
 *    static char *antimagic(char *line)
 *    static void etags_output(void)
 *    static void hdretagmerge(void)
 *    static void CtreeSetup(void)
 *    static void CtreeFoundReport(int argc,char **argv)
 *    static void CtreeUseReport(int argc,char **argv)
 *    static void CtreeTreeReport(int argc,char **argv)
 *    static void CtreePrintTitle( int argc, char **argv, char *title, ...)
 *    static void CtreePrintName(NameList *name)
 *    static void CtreeGraphReport(NameList *output,int depth)
 *    static void setnamefmt(void)
 *    static void CtreeUseList(void)
 *    static void CtreePrintTree(NameList *name, int lvl, int ifline)
 *    static void CtreeLoadNames(char *loadfile)
 *    static void CtreeLatexSizing(NameList *name, int lvl, int ifline)
 *    static void CtreeLatex(NameList *name, int lvl, int ifline)
 */

/* ---------------------------------------------------------------------
 * Header Information: {{{1
 */
#include <stdio.h>
#include <ctype.h>

/* --------------------------------------------------------------------- */
#include <setjmp.h>
#include "xtdio.h"

/* -----------------------------------------------------------------------
 * Definitions Section: {{{2
 */
#define	NAMELINEFMT		33
#define EJECT	  		(12)               /* a <CTRL>-L */
#define FFLAG_BUFSIZE	(4*MAXBUF)
#define FMAXBUF			9*MAXBUF
#define MAXBUF			256
#define MAX_FNAME_LEN	15
#define TITLEBUF		100
#define VERSION			"21"

#if defined(MCH_AMIGA) || defined(unix)
# define USE_DODIR
#endif

#define SUPPRESS_LXN	1

/* ---------------------------------------------------------------------
 * Enumerations: {{{2
 */
enum LanguageMode {C,CPP,LEX,YACC};

/* -----------------------------------------------------------------------
 * Typedefs: {{{2
 */
typedef struct ETag_str		ETag;
typedef struct NameList_str	NameList;
typedef struct PatMatch_str	PatMatch;
typedef struct Tag_str		Tag;
typedef struct UseList_str	UseList;

/* -----------------------------------------------------------------------
 * Data Structures: {{{2
 */
struct ETag_str {           /* ETag: {{{3                                   */
	char *filename;         /* associated filename                          */
	Tag  *taghd;            /* beginning of associated Tag list             */
	Tag  *tagtl;            /* ending    of associated Tag list             */
	ETag *nxt,*prv;         /* linked list support                          */
	};

struct NameList_str {       /* NameList: {{{3                               */
	char      recursion;    /* ' ', no recursion, '*' for recursion         */
	char      suppress;     /* suppress printing in tree reports            */
	char     *filename;     /* file in which function is defined            */
	char     *name;         /* function name                                */
	char     *type;         /* function return type string                  */
	long      linenum;      /* 1st line in file in which func is def'nd     */
	long      linenum_last; /* last line in file in which func is def'nd    */
	UseList  *phd,*ptl;     /* predecessor (called by) list                 */
	UseList  *uhd,*utl;     /* used (calls) routine list                    */
	NameList *nxt;          /* linked list of NameList support              */
	NameList *prv;          /* linked list of NameList support              */
	};

struct PatMatch_str {       /* PatMatch: {{{3                               */
	char *pattern;          /* original pattern from -Ppattern              */
	PAT  *pat;              /* if no logic, a PAT results (uses stcmpm2)    */
	LPAT *lpat;             /* if logic, a LPAT results   (uses stlpm2)     */
	};

struct Tag_str {            /* Tag: {{{3                                    */
	char *tagline;          /* tag (search string, etc)                     */
	Tag  *nxt,*prv;         /* linked list support                          */
	};

struct UseList_str {        /* UseList: {{{3                                */
	int       ifline;       /* used on an "if" line                         */
	NameList *name;         /* parent NameList function calls this function */
	UseList  *prv,*nxt;     /* linked list support                          */
	};

/* -----------------------------------------------------------------------
 * Prototypes: {{{2
 */
int main(int,char **);                                          /* flist.c */
static void GenerateCtreeReport(int,char **);                   /* flist.c */
int options(char **,char **);                                   /* flist.c */
static void fprior(int,PARMDEF *);                              /* flist.c */
static void makePatMatch(char *);                               /* flist.c */
static void flist(char *);                                      /* flist.c */
static void makeETag(char *);                                   /* flist.c */
static int inwhite(void);                                       /* flist.c */
static int incomment(void);                                     /* flist.c */
static int instring(char);                                      /* flist.c */
static int incurly(void);                                       /* flist.c */
static int isfunction(void);                                    /* flist.c */
static void cmmnt_output(void);                                 /* flist.c */
static void commonOutput(char *,char *,char *);                 /* flist.c */
static void ctree_output(void);                                 /* flist.c */
static void ctree_defaultnamelist(void);                        /* flist.c */
static void ext_output(void);                                   /* flist.c */
static void patmatch_output(void);                              /* flist.c */
static void proto_output(void);                                 /* flist.c */
static void std_output(void);                                   /* flist.c */
static void output_dummyfunc(void);                             /* flist.c */
static void tags_output(void);                                  /* flist.c */
static void CheckPatMatch(void);                                /* flist.c */
static void stripUserVar(char *);                               /* flist.c */
static void ioreset(int);                                       /* flist.c */
static char nxtc(char *);                                       /* flist.c */
static char *flist_preprocess(void);                            /* flist.c */
static void skipdirlines(void);                                 /* flist.c */
static void nxtline(void);                                      /* flist.c */
static void tags_generate(void);                                /* flist.c */
static int tag_compare(const char **,const char **);            /* flist.c */
static int hdrtagmerge(void);                                   /* flist.c */
static char *antimagic(char *);                                 /* flist.c */
static void etags_output(void);                                 /* flist.c */
static void hdretagmerge(void);                                 /* flist.c */
static void CtreeSetup(void);                                   /* flist.c */
static void CtreeFoundReport(int,char **);                      /* flist.c */
static void CtreeUseReport(int,char **);                        /* flist.c */
static void CtreeTreeReport(int,char **);                       /* flist.c */
static void CtreePrintTitle( int, char **, char *, ...);        /* flist.c */
static void CtreePrintName(NameList *);                         /* flist.c */
static void CtreeGraphReport(NameList *,int);                   /* flist.c */
static void setnamefmt(void);                                   /* flist.c */
static void CtreeUseList(void);                                 /* flist.c */
static void CtreePrintTree( NameList *, int, int);              /* flist.c */
static void CtreeLoadNames(char *);                             /* flist.c */
static void CtreeLatex( NameList *, int, int);                  /* flist.c */
static char *LatexName(char *);                                 /* flist.c */
static void CtreeLatexSizing( NameList *, int, int);            /* flist.c */

/* -----------------------------------------------------------------------
 * Global Variables: {{{2
 */
#ifdef __PROTOTYPE__
void (*output)(void) = NULL;                /* user-selected output function                             */
#else
void (*output)()     = NULL;                /* user-selected output function                             */
#endif

#if defined(unix) || defined(__linux)
char *magic          = "^$.\\";             /* default magic characters                                  */
#endif
#ifdef MCH_AMIGA
char *magic          = "^$.[]|\\";          /* default magic characters                                  */
#endif
#ifdef MSDOS
char *magic          = "";                  /* default magic characters                                  */
#endif
#ifdef vms
char *magic          = "\\";                /* default magic characters                                  */
#endif
#ifdef __BORLANDC__
char *magic          = "";                  /* default magic characters                                  */
#endif

FILE             *flistout     = NULL;      /* flist's output goes here                                  */
FILE             *fp           = NULL;
NameList         *namehd       = NULL;      /* head of linked list of NameLists                          */
NameList         *nametl       = NULL;      /* tail of linked list of NameLists                          */
PS               *psname       = NULL;      /* ParSrch database of NameLists                             */
PS               *exclname     = NULL;		/* CtreeLoadNames exclude from use list                      */
char              buffer[FMAXBUF];           /* current line                                             */
char              currfuncname[FMAXBUF];     /* current function name                                    */
char              fbuf[FMAXBUF];
char              fbufline[FMAXBUF];        /* holds tag's buffer line                                   */
char              flinefmt[NAMELINEFMT];    /* used by Ctree reports                                     */
char              fnamebuf[MAXBUF];         /* complete filename (with extension)                        */
char              namelinefmt[NAMELINEFMT]; /* used by Ctree reports                                     */
char              outbuf[FMAXBUF];
char             *hinthl       = NULL;      /* hint highlight group: -h=group                            */
char              q0;                       /* current character                                         */
char              q1;                       /* next character                                            */
char             *fbufmax      = NULL;      /* point to end of fbuf buffer                               */
char             *fname        = NULL;      /* current filename being processed                          */
enum LanguageMode langmode     = C;         /* indicates C, C++, or LEX                                  */
int               buflen       = 0;         /* length (in chars) in buffer                               */
int               fnamelen     = 0;         /* filename string length                                    */
int               lexpp        = 0;         /* counts %% sections in lex files                           */
int               lexskip      = 0;         /* subsequent lines are not to be processed if true	for lex  */
int               preprocmode  = 0;			/* =0: don't preprocess  =1: do                              */
int               uselistmode  = 0;         /* CtreeSetup sets uselistmode which modifies flist behavior */
int               linecnt      = 0;         /* maintain line count                                       */
jmp_buf           endfile;
long              tagtell      = 0L;        /* current position in file                                  */

char *halfheight     = NULL;				/* supports -Tp's halfheight vertical bars                   */
int   ctreeheight    = 0;                   /* -Tp's current tree height                                 */
int   ctreemaxheight = 60;                  /* -Tp's maximum tree height in a picture                    */
int   ctreewidth     = 0;                   /* -Tp's current tree width                                  */


Tag  *taghd          = NULL;                /* beginning of Tag list                                     */
Tag  *tagtl          = NULL;                /* ending    of Tag list                                     */
ETag *etaghd         = NULL;                /* beginning of ETag list                                    */
ETag *etagtl         = NULL;                /* ending    of ETag list                                    */

PatMatch *patmatch   = NULL;                /* supports -Ppattern                                        */

                                            /* flag variables:                                           */
static int   aflag   = 0;                   /* use antimagic on tags's patterns                          */
static int   cflag   = 0;                   /* comment mode flag                                         */
static int   Cflag   = 0;                   /* comments next to prototypes                               */
static int   dflag   = 0;                   /* make class::func and func duplicates                      */
static int   Dflag   = 0;                   /* generate dummy function definitions                       */
static int   eflag   = 0;                   /* generate etags file output                                */
static int   fflag   = 0;                   /* include filename:tag for tags                             */
static char *Fflag   = NULL;                /* optional file listing files                               */
static int   gflag   = 0;                   /* only globally usable (no static)                          */
static int   hflag   = 0;                   /* generate hints                                            */
static int   lflag   = 0;                   /* put linecnt into comment                                  */
static int   Lflag   = 0;                   /* lint mode output                                          */
static int   mflag   = 0;                   /* merge with <hdrtags> if true                              */
static int   noflag  = 1;                   /* standard output mode                                      */
static int   nflag   = 1;                   /* suppress newlines insertion if zero                       */
static int   pflag   = 0;                   /* generate prototypes                                       */
#ifdef USE_DODIR
static int   rflag   = 0;                   /* =1: permit recursive descent                              */
#endif
static int   sflag   = 0;                   /* only statics (no global)                                  */
static int   tflag   = 0;                   /* generate tags file output                                 */
static int   uflag   = 0;                   /* generate prototypes w/ varnames                           */
static int   vflag   = 0;                   /* print filenames as processed                              */
static int   xflag   = 0;                   /* extern mode flag                                          */

static char *Trflag  = NULL;				/* points to desired root of tree (a function name)          */
static int   Taflag  = 0;                   /* generate all trees                                        */
static int   Tflag   = 0;                   /* generate c-tree report(s)                                 */
static int   Tfflag  = 0;                   /* generate c-tree "found" report                            */
static int   Tgflag  = 0;                   /* generate c-tree "graphical" report                        */
static int   Tiflag  = 0;                   /* optional if... suppression                                */
static int   Tlflag  = 0;                   /* include line number                                       */
static int   Tpflag  = 0;                   /* latex tree picture environment support                    */
static int   Tuflag  = 0;                   /* generate c-tree "use"   report                            */
static int   Tsflag  = 0;                   /* use sorted names                                          */
static int   Ttflag  = 0;                   /* generate c-tree "tree" report                             */
static int   Txflag  = 0;                   /* exclude duplicates in use/tree                            */

/* -----------------------------------------------------------------------
 * Source Code: {{{1
 */

/* main: the rule driver {{{2 */
int main(int argc,char **argv)
{
char *envmagic       = NULL;
static char *usage[] = {
	XYELLOW,"flist",XGREEN," [",XCYAN,"filename1 ",XGREEN,"[",XCYAN,
	"filename2 ",XGREEN,"[",XCYAN,"filename3",XGREEN,"...]]\n\n",

	XUWHITE,"Options:",XGREEN,"\n",
	"\t",XCYAN,"-a",XGREEN,"        : use antimagic on patterns\n",
	"\t",XCYAN,"-Amagic",XGREEN,"   : specify \"magic\" characters for antimagic\n",
	"\t",XCYAN,"-c ",XGREEN,"       : produce output suitable for inclusion in a comment\n",
	"\t",XCYAN,"-C ",XGREEN,"       : no comments next to prototypes, etc\n",
	"\t",XCYAN,"-d ",XGREEN,"       : ctags mode: allow duplication of class::func as func\n",
	"\t",XCYAN,"-D ",XGREEN,"       : output a dummy-function file (composed of abc(){})\n",
	"\t",XCYAN,"-e ",XGREEN,"       : etags mode (generates a <TAGS> file)\n",
	"\t",XCYAN,"-f ",XGREEN,"       : like -m, but filename:func tags too\n",
	"\t",XCYAN,"-F file",XGREEN,"   : apply flist to a file which lists filenames\n",
	"\t",XCYAN,"-g ",XGREEN,"       : only global functions printed (no static)\n",
	"\t",XCYAN,"-h ",XGREEN,"       : generate a hints file for vim\n",
	"\t",XCYAN,"-h=hlgroup",XGREEN,": like -h, but hints are highlighted with given group\n",
	"\t",XCYAN,"-l ",XGREEN,"       : include linenumber in comment field\n",
	"\t",XCYAN,"-l ",XGREEN,"       : modify -Ppat output: \"filename : funcname : matching-line\"\n",
	"\t",XCYAN,"-ll",XGREEN,"       : modify -Ppat output: \"filename : linenum : funcname : matching-line\"\n",
	"\t",XCYAN,"-L ",XGREEN,"       : lint mode output\n",
	"\t",XCYAN,"-m ",XGREEN,"       : merge tags with hdrtags if present\n",
#ifdef AZTEC_C
	"\t",XCYAN,"-ofile ",XGREEN,"   : output goes to given file\n",
#endif
	"\t",XCYAN,"-p ",XGREEN,"       : produce prototype declarations without user variables\n",
	"\t",XCYAN,"-Ppat",XGREEN,"     : print lines matching pattern as \"funcname : matching-line\"\n",
#ifdef USE_DODIR
	"\t",XCYAN,"-r ",XGREEN,"       : permit recursive descent\n",
#endif
	"\t",XCYAN,"-s ",XGREEN,"       : only static functions printed (no global)\n",
	"\t",XCYAN,"-S#",XGREEN,"       : set screenwidth to specified value\n",
	"\t",XCYAN,"-t ",XGREEN,"       : ctags mode: creates a tags file\n",
	"\t",XCYAN,"-u ",XGREEN,"       : produce prototypes with user variables\n",
	"\t",XCYAN,"-v ",XGREEN,"       : print filenames as they're processed\n",
	"\t",XCYAN,"-x ",XGREEN,"       : extern type listing\n",

	"\n",
	"\t",XCYAN,"-T  ",XGREEN,"      : subsequent flags are for the tree reports\n",
	"\t",XCYAN,"-Ta ",XGREEN,"      : generate tree reports for all roots\n",
	"\t",XCYAN,"-Tf ",XGREEN,"      : functions found report\n",
	"\t",XCYAN,"-Tl ",XGREEN,"      : include last line number in found/use reports\n",
	"\t",XCYAN,"-Tp[#] ",XGREEN,"   : produces LaTeX picture environment trees\n",
	"\t            (optionally limited to # lines per picture)\n",
	"\t",XCYAN,"-Tr fnc",XGREEN,"   : construct tree using fnc as rootname\n",
	"\t",XCYAN,"-Ts ",XGREEN,"      : sort functions in reports\n",
	"\t",XCYAN,"-Tt ",XGREEN,"      : generate a tree\n",
	"\t",XCYAN,"-Tu ",XGREEN,"      : generate function calls/is-called-by report\n",
	"\t",XCYAN,"-Tx ",XGREEN,"      : exclude duplicated called functions\n",

	"\n",XUWHITE,"Explanation:",XGREEN,"\n",
	"\tOutput consists of the files' names and a list of\n",
	"\tfunctions contained therein (for the C and C++ languages)\n",
	"\tflist can accept input from standard input\n\n",

	"\tThe \"ctags\" mode supports both C and C++.  The C++ mode generates\n",
	"\ttags by function name as usual, but will also generate tags of the\n",
	"\tform class::func, class::~class, operatorX, where X is an operator,\n",
	"\tand class::operatorX.\n\n",

	"\tThe -T[tau] reports make two passes over the source files.  The\n",
	"\ttree reports show functions as\n",
	"\t\t. . . abc     : normal function\n",
	"\t\t. . . (abc)   : called with if() on same line\n",
	"\t\t. . . abc*    : recursive call to abc\n",

	"\n",XWHITE,"Author",XGREEN,"   : Dr. Charles E. Campbell, Jr.\n",
	     XWHITE,"Version",XGREEN,"  : ",VERSION,
	"\n",
	     XWHITE,"Copyright",XGREEN,": 1999-2004  Charles E. Campbell, Jr.\n",
	"",""};

rdcolor();				/* read in color definition(s)	*/

/* initialization */
fbufmax           = fbuf + FMAXBUF;
output         = std_output;
flistout       = stdout;
currfuncname[0]= '\0';

/* get TAGMAGIC if any */
envmagic= getenv("TAGMAGIC");
if(envmagic && envmagic[0]) magic= envmagic;

/* change defaults based on program name */
if(!strcmp(argv[0],"ctags")) {
	noflag= 0;
	tflag = 1;
	}

/* process command line */
#ifdef USE_DODIR
getarg(argc,argv,0,(PARMDEF *) NULL,usage,options,fprior,dodir,1,"Enter filename(s)");
#else
getarg(argc,argv,0,(PARMDEF *) NULL,usage,options,fprior,flist,1,"Enter filename(s)");
#endif

/* process any files given by a Fflag */
if(Fflag) {
	FILE *Ffp;
	char  buf[FFLAG_BUFSIZE];
	Ffp= fopen(Fflag,"r");
	while(fgets(buf,FFLAG_BUFSIZE,Ffp)) {
		srmtrblk(buf);
		flist(stpblk(buf));
		}
	fclose(Ffp);
	}

/* close down <tags> file if its been opened */
if(taghd) {
	if     (eflag && etagtl) etags_output();
	else if(tflag)           tags_output();
	}

/* generate ctree reports */
if(Tflag) GenerateCtreeReport(argc,argv);

#ifdef vms
return 1;
#else
return 0;
#endif
}

/* ----------------------------------------------------------------------- */

/* GenerateCtreeReport: this function calls what's needed to generate one of {{{2
 * the ctree-style reports
 */
static void GenerateCtreeReport(int argc,char **argv)
{

/* initialize formats and handle default flag settings */
CtreeSetup();

/* generate report(s) */
if(Tfflag)                     CtreeFoundReport(argc,argv);
if(Tuflag)                     CtreeUseReport(argc,argv);
if(Tgflag || Ttflag || Tpflag) CtreeTreeReport(argc,argv);

}

/* --------------------------------------------------------------------- */

/* options: this routine handles options {{{2 */
int options(char **s,char **a)
{
int ret=0;


if(s && *s) switch(**s) {

case 'a':	/* use antimagic on tags's patterns	*/
	if(Tflag) Taflag= 1;
	else      aflag = !aflag;
	break;

case 'A':	/* -Astring or -A string: specify magic characters for antimagic */
	if(!s[0][1]) {
		magic= a[1];
		ret  = 1;
		}
	else {
		magic= *s + 1;
		ret  = -1;
		}
	aflag= 1;
	break;

case 'c': /* comment mode			*/
	cflag = !cflag;
	noflag= pflag= xflag= tflag= 0;
	output= cmmnt_output;
	break;

case 'C': /* no comments next to prototypes, etc. */
	Cflag= 1;
	break;

case 'd':	/* make class::func *and* func tags */
	dflag= !dflag;
	if(dflag) {
		tflag = 1;
		output= tags_generate;
		}
	break;

case 'D':	/* -D: make dummy function-file */
	Dflag= !Dflag;
	if(Dflag) output= output_dummyfunc;
	break;

case 'e':	/* generate "etags" style tags */
	eflag= !eflag;
	if(eflag) {
		tflag = 1;
		output= tags_generate;
		noflag= cflag= pflag= xflag= uflag= 0;
		}
	break;

case 'f':	/* tags get filename:func in addition */
	if(Tflag) Tfflag= 1;
	else {
		fflag= !fflag;
		if(fflag) {
			mflag= tflag= 1;
			output= tags_generate;
			noflag= cflag= pflag= xflag= uflag= 0;
			}
		}
	break;

case 'F':	/* -F filename: read a file of filenames to be hdrtag'ed */
	if(!s[0][1]) {
		Fflag= a[1];
		ret  = 1;
		}
	else {
		Fflag= *s + 1;
		ret  = -1;
		}
	ga_dofile= 0;
	break;

case 'g': /* only globals */
	if(Tflag) Tgflag= 1;
	else {
		gflag= 1;
		sflag= 0;
		}
	break;

case 'h':	/* -h : generate a hints file */
	hflag= !hflag;
	if(hflag) {
		cflag    = dflag= tflag = xflag = 0;
		pflag    = uflag              = 1;
		output   = proto_output;
		flistout = fopen("hints","w");
		if(s[0][1] == '=' && s[0][2]) {
			stralloc(hinthl,*s+2,"-h=... allocation failure");
			ret= -1;
			}
		}
	else if(hinthl) {
		free(hinthl);
		hinthl= NULL;
		}
	break;

case 'i':	/* -Ti : allows optional suppression of if... */
	if(Tflag) Tiflag= 1;
	break;

case 'l': /* put linecnt into comment */
	if(Tflag) Tlflag= 1;
	else      ++lflag;
	break;

case 'L':	/* lint mode output */
	Lflag = pflag= uflag= 1;
	xflag = 0;
	output= proto_output;
	break;

case 'm':	/* merge with <hdrtags> file */
	mflag= !mflag;
	if(mflag) {
		tflag = 1;
		output= tags_generate;
		noflag= cflag= pflag= xflag= uflag= 0;
		}
	break;

case 'n':	/* suppress newlines in supportive output modes */
	nflag= !nflag;
	break;

#ifdef AZTEC_C
case 'o':	/* -ofile or -o file: direct commonOutput to this file */
	if(isalpha(s[0][1])) {
		flistout= fopen(s[0] + 1,"w");
		ret     = -1;
		}
	else {
		flistout= fopen(a[1],"w");
		ret     = 1;
		}
	if(!flistout) flistout= stdout;
	break;
#endif	/* AZTEC_C */

case 'p':
	if(Tflag) { /* -Tp : create a tree-report using Latex picture environment */
		        /* -Tp# : also specify maximum picture size */
		Tpflag= !Tpflag;
		if(isdigit(s[0][1])) {
			sscanf(s[0]+1,"%d",&ctreemaxheight);
			ret= -1;
			}
		}
	else { /* generate prototypes	*/
		pflag = !pflag;
		if(pflag) {
			noflag= cflag= dflag= tflag= 0;
			output= proto_output;
			}
		}
	break;

case 'P':	/* -Ppattern or -P pattern */
	if(s[0][1]) {
		makePatMatch(s[0]+1);
		ret= -1;	/* skip rest of argument */
		}
	else {
		makePatMatch(a[1]);
		ret= 1;
		}
	output= patmatch_output;
	noflag= 0;
	break;

case 'r':	/* permit recursive descent down directories using dodir */
	if(Tflag) {
		if(a[1] && (isalpha(a[1][0]) || a[1][0] == '_')) {
			Trflag= a[1];
			Ttflag= 1;
			ret   = 1;
			}
		else error(XTDIO_ERROR,"-Tr but missing function name\n");
		break;
		}
#ifdef USE_DODIR
	rflag= !rflag;
#endif
	break;

case 'S': /* -S# is screenwidth */
	if(isdigit(*(*s+1))) {
		sscanf(*s+1,"%d",&screenwidth);
		*s+= strlen(*s) - 1;
		}
	break;

case 's': /* only statics */
	if(Tflag) Tsflag= 1;
	else {
		sflag= 1;
		gflag= 0;
		}
	break;

case 't': /* -t : tags output */
	if(Tflag) Ttflag= 1;
	else {
		tflag= !tflag;
		if(tflag) {
			output= tags_generate;
			noflag= cflag= pflag= xflag= uflag= 0;
			}
		}
	break;

case 'T':	/* -T[fuv]: tree reports */
	Tflag = 1;
	output= ctree_output;
	break;

case 'u': /* keep variables in prototypes */
	if(Tflag) Tuflag= 1;
	else {
		cflag = dflag= tflag= xflag= 0;
		pflag = uflag= 1;
		output= proto_output;
		}
	break;

case 'v':	/* verbose flag : print filenames as they're processed */
	vflag = !vflag;
	break;

case 'x': /* extern mode			*/
	if(Tflag) Txflag= 1;
	else {
		xflag    = 1;
		cflag    = dflag       = pflag = tflag = noflag = 0;
		output   = ext_output;
		langmode = C;
		}
	break;

default:
	error(XTDIO_WARNING,"<%s> is an unsupported option\n",cprt(**s));
	break;
	}

return ret;
}

/* ----------------------------------------------------------------------- */

/* fprior: this function {{{2 */
static void fprior(int parmqty,PARMDEF *parms)
{
#ifdef USE_DODIR
static char *suffices[] = {"c","C","cpp","c++","cxx","l","lex","y","yacc","lxn",""};
#endif


#ifdef USE_DODIR
/* set up directory processing */
setup_dodir(flist,suffices,rflag);
#endif

}

/* --------------------------------------------------------------------- */

/* makePatMatch: this function makes a PatMatch {{{2 */
static void makePatMatch(char *pattern)
{

if(patmatch) {	/* flist only supports *one* PatMatch */
	error(XTDIO_WARNING,"makePatMatch: flist only supports *one* pattern, using <%s>\n",sprt(pattern));
	if(patmatch->pattern) free(patmatch->pattern);
	if(patmatch->pat)     freepat(patmatch->pat);
	if(patmatch->pat)     freelpat(patmatch->lpat);
	}
else {
	patmatch= alloc(PatMatch);
	outofmem(patmatch,"makePatMatch: unable to allocate a PatMatch!\n");
	}

stralloc(patmatch->pattern,pattern,"makePatMatch: unable to allocate pattern");
patmatch->pattern= NULL;

if(stlpm_haslogic(pattern)) {
	patmatch->lpat= setlpat(pattern);
	patmatch->pat = NULL;
	if(!patmatch->lpat) error(XTDIO_ERROR,"unable to setlpat<%s>\n",sprt(pattern));
	}
else {
	patmatch->lpat= NULL;
	patmatch->pat = setpat(pattern);
	if(!patmatch->pat) error(XTDIO_ERROR,"unable to setpat<%s>\n",sprt(pattern));
	}

}

/* --------------------------------------------------------------------- */

/* flist: do a function list for the file {{{2 */
static void flist(char *filename)
{
char *bln;


/* if filename is null, then dodir is telling flist that it just finished
 * processing a directory -- this function will do nothing with that information.
 */
if(!filename) {
	return;
	}

/* reset lexskip and lexpp for new file */
lexskip= 0;
lexpp  = 0;

/* use standard input */
if(!strcmp(filename,"stdin")) {
	fp= stdin;
	strcpy(fnamebuf,"stdin");
	}

/* open file and set up fnamebuf */
else {
	char *f;

	bln= strrchr(filename,'.');
	if(Tflag && bln && !strcmp(bln,".lxn")) {	/* handle a load/exclude name file */
		CtreeLoadNames(filename);
		return;
		}
	else {
		fp= fopenx(filename,"r","c","");
		if(!fp) {	/* check for C++ */
			fp= fopenx(filename,"r","cpp","");
			if(!fp) fp= fopenx(filename,"r","c++","");
			if(!fp) fp= fopenx(filename,"r","C","");
			if(!fp) fp= fopenx(filename,"r","cc","");

			if(!fp) {
				fp= fopenx(filename,"r","y","");
				if(!fp) fp= fopenx(filename,"r","yacc","");
				if(fp) {
					langmode= YACC;
					lexskip = 1;
					lexpp   = 0;
					}
				}

			if(!fp) {	/* check for lex */
				fp= fopenx(filename,"r","l","");
				if(!fp) fp= fopenx(filename,"r","lex","");

				/* error: can't open filename */
				if(fp) {
					langmode = LEX;
					lexskip  = 1;
					lexpp    = 0;
					}
				else {
					error(XTDIO_WARNING,"can't find <%s%s%s>\n",YELLOW,filename,GREEN);
					return;
					}
				}
			else langmode= CPP;
			}

		else {	/* suffix may have been explicitly provided by user (or implied .c) */
			langmode = C;
			f        = strrchr(fopenfilename,'.');

			/* check if lex */
			if(!strcmp(f,".l")   || !strcmp(f,".lex")) {
				langmode= LEX;
				lexskip = 1;
				lexpp   = 0;
				}

			/* check if yacc */
			else if(!strcmp(f,".y")   || !strcmp(f,".yacc")) {
				langmode= YACC;
				lexskip = 1;
				lexpp   = 0;
				}
			else if(!strcmp(f,".c++") || !strcmp(f,".cpp") || !strcmp(f,".C")   || !strcmp(f,".cc")) langmode= CPP;

			}
		strcpy(fnamebuf,fopenfilename);
		}
	}
linecnt= 0;

/* verbose */
if(vflag) {
	if(mflag || tflag)  fprintf(stderr,"%sctag       %s%s%s%s\n",CYAN,GREEN,fnamebuf,CYAN,GREEN);
	else if(Tflag) {
		if(uselistmode) fprintf(stderr,"%suselist functions %s%s%s\n",CYAN,GREEN,fnamebuf,GREEN);
		else            fprintf(stderr,"%sfinding functions %s%s%s\n",CYAN,GREEN,fnamebuf,GREEN);
		}
	else                fprintf(stderr,"  %s<%s%s%s>%s\n",CYAN,GREEN,fnamebuf,CYAN,GREEN);
	}

/* etags support */
if(eflag) makeETag(fopenfilename);

/* document filename */
if(cflag) {
	fputs(" *  Routines Include:",stdout);
	if(fp == stdin) fputs("\n",stdout);
	else            printf(" <%s>\n",fnamebuf);
	}
else if(noflag && !Tflag && !Dflag && !hflag) {
	if(fp == stdin) printf("%sstdin%s\n",CYAN,GREEN);
	else            printf("%s%s%s\n",CYAN,fnamebuf,GREEN);
	}

/* set up fname: if fnamelen is greater than MAX_FNAME_LEN, then
 * try to keep only the portion following the slash, and then
 * restrict it, too, to less than MAX_FNAME_LEN characters.
 */
fname   = fnamebuf;
fnamelen= strlen(fname);
if(fnamelen > MAX_FNAME_LEN && !tflag) {
	char *slash;
	slash= strrchr(fnamebuf,'/');
	if(slash) {
		if(strlen(slash+1) < MAX_FNAME_LEN) {
			fname   = slash + 1;
			fnamelen= strlen(fname);
			}
		else {
			fname= slash + 1;
			fname[MAX_FNAME_LEN]= '\0';
			}
		}
	else {
		fname               = fnamebuf;
		fname[MAX_FNAME_LEN]= '\0';
		}
	fnamelen            = MAX_FNAME_LEN - 1;
	}

/* uselistmode supports Ctree's Use and Tree reports */
if(uselistmode) {
	CtreeUseList();
	return;
	}

/* reset i/o variables */
ioreset(1);

/* set up a long jump */
if(!setjmp(endfile)) {
	(void) nxtc("flist");	/* read in first character/line		*/

	while(1) {				/* process the source code			*/


		(void) inwhite();
		if(incomment())    continue;
		if(instring('"'))  continue;
		if(instring('\'')) continue;
		if(isfunction())   continue;
		if(incurly())      continue;
		if(!nxtc("flist")) break;
		}
	}

/* close up file handle and depart */
if(fp != stdin) {
	fclose(fp);
	}

}

/* --------------------------------------------------------------------- */

/* makeETag: allocates, links, and initializes a new ETag {{{2 */
static void makeETag(char *filename)
{

/* move Tag list to old ETag */
if(etagtl) {
	etagtl->taghd= taghd;
	etagtl->tagtl= tagtl;
	}

taghd= tagtl= NULL;

if(filename) {	/* allocate, link, and initialize a new ETag */
	double_link(ETag,etaghd,etagtl,"new Etag");
	stralloc(etagtl->filename,filename,"etag filename");
	etagtl->taghd= etagtl->tagtl= NULL;
	}

}

/* ----------------------------------------------------------------------- */

/* inwhite: this function compresses multiple white space to one blank {{{2 */
static int inwhite(void)
{
if(isspace(q0)) {

	if(!tflag) {	/* compress multiple white -> one space */
		while(isspace(q0) && isspace(q1)) (void) nxtc("inwhite");
		if(isspace(q0)) q0= ' ';
		}

	return 1;
	}
return 0;
}

/* ----------------------------------------------------------------------- */

/* incomment: this function skips over C or C++ comments {{{2 */
static int incomment(void)
{

/* test if in a C comment */
if(q0 == '/' && q1 == '*') {

	while(q0 != '*' || q1 != '/') (void) nxtc("incomment");
	(void) nxtc("incomment");	/* get rid of * */
	(void) nxtc("incomment");	/* get rid of / */

	return 1;
	}

/* test if in a C++ comment */
if(q0 == '/' && q1 == '/') {

	while(nxtc("incomment") != '\n') ;

	return 1;
	}
return 0;
}

/* ----------------------------------------------------------------------- */

/* instring: this function skips over strings and (multi-byte) characters {{{2 */
static int instring(char delim)
{
char c;

if(q0 == delim) {

	do {
		c= nxtc("instring");
		if(c == '\\') (void) nxtc("instring (\\ skip)");
		if(c == '\n') error(XTDIO_WARNING,"newline in string\n<%s:%d> <%s>\n",sprt(fnamebuf),linecnt,sprt(buffer));
		} while(c != delim);
	(void) nxtc("instring (skip delim)");	/* ignore string delimiter */
	return 1;
	}
return 0;
}

/* ----------------------------------------------------------------------- */

/* incurly: this function handles stuff inside curly braces {{{2 */
static int incurly(void)
{
static int curlycnt=0;

if(q0 == '{') {
	++curlycnt;

	(void) nxtc("incurly (skip {)");
	while(1) {
		(void) inwhite();
		if(incomment())     continue;
		if(instring('"'))   continue;
		if(instring('\''))  continue;
		if(incurly())       continue;
		if(q0 == '}')       break;
		(void) nxtc("incurly");
		}

	/* skip the '}' character */
	(void) nxtc("incurly (skip })");
	--curlycnt;

	/* record linenum_last */
	if(nametl && curlycnt == 0 && nametl->linenum_last == 0) {
		nametl->linenum_last= linecnt;
		}

	return 1;
	}
return 0;
}

/* ----------------------------------------------------------------------- */

/* isfunction: this routine looks for function definitions' declarations {{{2 */
static int isfunction(void)
{
int          ret           = 0;
static char *f             = fbuf;
static int   maybefunc     = 0;
static int   notafunc      = 0;
static int   opcppmode     = 0;
static int   parens        = 0;
static int   record        = 1;
static int   waitforbrace  = 0;
static int   maybeptr2func = 0;


/* record character in function buffer */
if(record) {
	/* ignore leading blanks */
	if(f == fbuf && isspace(q0)) {
		if(!tflag || q0 == '\n') {
			return 0;
			}
		}
	if(f >= fbufmax) {
		f= fbuf;	/* overflow protection			*/
		error(XTDIO_ERROR,"function buffer overflow\n<%s:%d> <%s>\n",sprt(fnamebuf),linecnt,sprt(buffer));
		}
	if(maybefunc && isspace(q0)) {
		return 0;
		}
	*(f++)= q0;
	*f    = '\0'; /* terminate fbuf properly */
	}

/* attempts to rule out pointers to functions without ruling
 * out such nasty constructions as functions which return
 * pointers to functions returning something, etc
 *
 *  example: ptr to func ret int                 = int (*var)()
 *  example: ptr to func ret ptr to func ret int = int (*(*var)())()
 *  example: func ret ptr to int                 = int *f()
 *  example: func ret ptr to func ret int        = int (*f())()
 */
switch(maybeptr2func) {

case 0:
	break;

case 1:	/* ... ( */
	maybeptr2func= (q0 == '*')? 2 : 0;
	break;

case 2:	/* ... (\* */
	if(isalpha(q0) || q0 == '_') maybeptr2func= 3;
	else if(q0 == ')') { /* reset fbuf */
		f            = fbuf;
		*f           = '\0';
		maybefunc    = 0;
		record       = 0;
		notafunc     = 1;
		maybeptr2func= 0;
		}
	else if(q0 == '(') maybeptr2func= 1;
	break;

case 3:	/* ...(\*[ \t]*[a-zA-Z_]* */
	if(q0 == '(') maybeptr2func= 0;
	else if(q0 == ')') {
		f            = fbuf;
		*f           = '\0';
		maybefunc    = 0;
		record       = 0;
		notafunc     = 1;
		maybeptr2func= 0;
		}
	break;
	}

/* special character handling */
switch(q0) {

case '(': /* function possible */
	maybefunc= 0;
	++parens;
	if(tflag && parens == 1) strcpy(fbufline,buffer);	/* for tags use */
	if(parens == 1)          maybeptr2func= 1;
	break;

case ')': /* function-end check */
	if(--parens < 0) error(XTDIO_ERROR,"mismatched parentheses\n<%s:%d> <%s>\n", sprt(fnamebuf),linecnt,sprt(buffer));
	else if(parens == 0 && !notafunc && !waitforbrace) maybefunc= 1;
	break;

case ';': /* reset fbuf */
	f            = fbuf;
	*f           = '\0';
	maybefunc    = 0;
	record       = 1;
	notafunc     = 0;
	maybeptr2func= 0;
	break;

case '^': case '|':	/* these characters *may* shut down function recording */
case '=': case '-': case '+': case '/':
case '<': case '>': case '[': case ']':
	if(langmode == CPP) {
		if(f >= fbuf + 9) {	/* allow operatorX, where X is an op */
			if(f[-9] == 'o' &&
			   f[-8] == 'p' &&
			   f[-7] == 'e' &&
			   f[-6] == 'r' &&
			   f[-5] == 'a' &&
			   f[-4] == 't' &&
			   f[-3] == 'o' &&
			   f[-2] == 'r') {
				break;
				}
			else if(f[-10] == 'o' &&
			        f[-9]  == 'p' &&
			        f[-8]  == 'e' &&
			        f[-7]  == 'r' &&
			        f[-6]  == 'a' &&
			        f[-5]  == 't' &&
			        f[-4]  == 'o' &&
			        f[-3]  == 'r' &&
					(f[-1] == '=' ||
					 (f[-2] == '[' && f[-1] == ']') ||
					 (f[-2] == '<' && f[-1] == '<') ||
					 (f[-2] == '>' && f[-1] == '>'))) {
				break;
				}
			else if(parens == 1 && q0 == '=') {
				opcppmode= 1;
				break;
				}
			else if(parens == 1 && (q0 == '<' || q0 == '>')) break;
			}
		else if(parens == 0 && opcppmode && q0 == '=') {
			opcppmode= 0;
			break;
			}
		else if(parens == 1 && q0 == '=') break;
		else if(parens == 1 && (q0 == '<' || q0 == '>')) break;
		}
	else if(q0 == '[' || q0 == ']') break;

	/* shut down function recording */
	f        = fbuf;
	*f       = '\0';
	maybefunc= 0;
	record   = 0;
	notafunc = 1;
	opcppmode= 0;
	break;

/* { */
case '}':	/* these characters shut down function recording */
case '@': case '#': case '%':
	f           = fbuf;
	*f          = '\0';
	maybefunc   = 0;
	record      = 0;
	notafunc    = 1;
	waitforbrace= 0;
	break;

case ',': /* maybefunc true => not function definition */
	if(parens == 0) {
		maybefunc= 0;
		record   = 0;	/* turn off function buffer recording */
		f        = fbuf;
		*f       = '\0';
		}
	break;

case ':':
	if(langmode == CPP) {
		if(q1 == ':') {
			(void) nxtc("isfunction");	/* permit :: in C++ function names */
			*(f++)= q0;
			*f    = '\0';
			break;
			}
		}
	/* fall through to default */

default:
	if(maybefunc && (isalpha(q0) || q0 == '_' || q0 == '{' || (langmode == CPP && q0 == ':'))) /*}*/ {

		/* found a function! */

		*(f-1)= '\0';	/* remove character which signalled func-def'n found*/

		/* Globally accessable functions only (ie. not static) */
		if(gflag) {
			f= stpblk(fbuf);
			if(*f     != 's' || *(f+1) != 't' || *(f+2) != 'a' ||
			   *(f+3) != 't' || *(f+4) != 'i' || *(f+5) != 'c' ||
			   !isspace(*(f+6))) (*output)();
			}

		/* Static functions only (ie. not globally accessable) */
		else if(sflag) {
			f= stpblk(fbuf);
			if(*f     == 's' && *(f+1) == 't' && *(f+2) == 'a' &&
			   *(f+3) == 't' && *(f+4) == 'i' && *(f+5) == 'c' &&
			   isspace(*(f+6))) (*output)();
			}

		/* put any detected function out */
		else if(!waitforbrace) {
			(*output)();	/* print out function declaration				*/
			waitforbrace= q0 != '{';	/*}*/
			}
		else waitforbrace= 0;/* skip C++'s basefunc: func() : basefunc() ... { } */

		maybefunc= 0;
		f        = fbuf;	/* function buffer is emptied					*/
		*f       = '\0';	/* terminate function buffer properly			*/
		ret      = q0 != '{'; /* set up return value }						*/
		}
	else if(q0 == '{') /* } */ {
		waitforbrace= 0;
		maybefunc   = 0;
		f           = fbuf;	/* function buffer is emptied					*/
		*f          = '\0';	/* terminate function buffer properly			*/
		record      = 1;	/* re-start recording mode						*/
		}
	break;
	}

return ret;
}

/* ========================================================================
 * Output Routines:
 */

/* cmmnt_output: this function prints out prototypes in a comment-includable {{{2
 * format
 */
static void cmmnt_output(void)
{
if(lflag) sprintf(outbuf," *    %-10s:%4d",fbuf,linecnt);
else      sprintf(outbuf," *    %-15s",fbuf);
commonOutput(outbuf," *      ",(char *) NULL);
}

/* ----------------------------------------------------------------------- */

/* commonOutput: this function prints out a buffer, forcing lines to fit {{{2
 *  in screenwidth columns
 */
static void commonOutput(char *buf,char *leader,char *cmmnt)
{
char  chold;
char *b;
char *s;
int   blanks;
int   blen;		/* buffer length in chars							*/
int   cmmntlen;	/* comment length in chars							*/
int   leadlen;
int   plen;		/* screenwidth - cmmntlen - 1 (usable func space)	*/


/* get length of cmmnt and leader strings */
if(Cflag) cmmnt= NULL;
cmmntlen= cmmnt? strlen(cmmnt) : 0;
leadlen = strlen(leader);
blen    = strlen(buf);

/* print out the local buffer'ed version of the function */
if(!nflag || blen < screenwidth - cmmntlen - 1) {
	fputs(buf,flistout);
	if(cmmnt) {
		int iblank;

		blanks= screenwidth - cmmntlen - blen;
		for(iblank= 0; iblank < blanks; ++iblank) fputc(' ',flistout);
		fprintf(flistout,"%s\n",cmmnt);
		}
	else fputc('\n',flistout);
	}

else { /* put out screenwidth-limited function */

	if(cmmnt) { /* put out function + comment */
		int iblank;

		plen= screenwidth - cmmntlen - 1;
		if(plen > blen) plen= blen;
		for(b= buf + plen, blanks= 0; b > buf; --b, ++blanks)
		  if(*b == ',') break;

		if(b == buf) { /* sigh - funcname ( one arg ) awfully long case */
			for(b= buf + plen, blanks= 0; b > buf; --b, ++blanks)
			  if(*b == '(') break;
			}

		chold= *++b;
		*b   = '\0';
		fputs(buf,flistout);
		for(iblank= 0; iblank < blanks; ++iblank) fputc(' ',flistout);
		fprintf(flistout,"%s\n",cmmnt);
		*b   = chold;
		blen-= (b - buf);
		}

	else {
		b   = buf;
		for(s= b + screenwidth; s > b; --s) if(*s == ',') break;
		chold= *++s;
		*s   = '\0';
		fprintf(flistout,"%s\n",b);
		*s   = chold;
		blen-= (s - b);
		b    = s;
		}

	while(blen >= screenwidth - leadlen) {
		for(s= b + screenwidth - leadlen; s > b; --s) if(*s == ',') break;
		chold= *++s;
		*s   = '\0';
		fprintf(flistout,"%s%s\n",leader,b);
		*s   = chold;
		blen-= (s - b);
		b    = s;
		}

	/* put out rest of function line */
	fprintf(flistout,"%s%s\n",leader,b);
	}

}

/* ----------------------------------------------------------------------- */

/* ctree_output: this function supports the three c-tree style reports: {{{2
 *   found, use, tree.  This function parses the function definition
 *   and sets up NameList entries.  Note: this function does not, itself,
 *   actually produce any output.
 */
static void ctree_output(void)
{
char         funcbuf[MAXBUF];
char        *f           = NULL;
char        *fbgn        = NULL;
char        *fend        = NULL;
char        *fn          = NULL;
char        *p1          = NULL;
int          parens      = 0;
static char *locfilename = NULL;


ctree_defaultnamelist();

/* if locbuf hasn't been set up yet or if locfilename
 * differs from the current filename
 */
if(!locfilename || strcmp(fbuf,locfilename)) {
	stralloc(nametl->filename,stpblk(fnamebuf),"NameList allocation for filename\n");
	locfilename= nametl->filename;
	}
nametl->linenum= linecnt;

/* get rid of stuff (arguments, declarations, etc) between final parentheses pair */
for(f= fbuf, parens= 0; *f; ++f) {
	if(*f == '(') {
		++parens;
		if(parens == 1) p1= f;
		}
	else if(*f == ')') --parens;
	}
if(p1) strcpy(p1,"()");
else   strcat(fbuf,"()");

/* extract function name */
for(f= fbuf; *f; ++f) {
	if(isalpha(*f) || *f == '_') {
		fbgn = f;
		if(langmode == CPP) {
			for(fn= funcbuf; *f && (isalnum(*f) || *f == '_' || *f == ':' || *f == '~'); ++f, ++fn) {
				*fn= *f;
				if(*fn == ':' || *fn == '~') fbgn= f + 1;
				}
			}
		else for(fn= funcbuf; *f && (isalnum(*f) || *f == '_'); ++f, ++fn) *fn= *f;
		*fn  = '\0';
		fend = f;
		}
	}

/* elide function name from fbuf */
if(fbgn && fend > fbgn) {
	while(fbgn > fbuf && isspace(fbgn[-1])) --fbgn;
	memcpy(fbgn,fend,strlen(fend) + 1);
	}
stralloc(nametl->name,funcbuf,"NameList function name\n");
stralloc(nametl->type,fbuf,"NameList function type\n");

}

/* --------------------------------------------------------------------- */

/* ctree_defaultnamelist: this function {{{2 */
static void ctree_defaultnamelist(void)
{

/* first, generate and link a NameList entry */
double_link(NameList,namehd,nametl,"while in ctree_output\n");

/* second, initialize NameList entry to a generic nothing */
nametl->name         = NULL;
nametl->suppress     = 0;
nametl->recursion    = ' ';
nametl->filename     = NULL;
nametl->type         = NULL;
nametl->linenum      = 0L;
nametl->linenum_last = 0L;
nametl->phd          = nametl->ptl = NULL;
nametl->uhd          = nametl->utl = NULL;

}

/* --------------------------------------------------------------------- */

/* ext_output: this function prints out function definitions as externs, {{{2
 * *not* prototypes
 */
static void ext_output(void)
{
char  cmmnt[MAXBUF];
char *f= NULL;
char *p1= NULL;
int   parens;

/* get rid of stuff between parentheses */
for(f= fbuf, parens= 0; *f; ++f) {
	if(*f == '(') {
		++parens;
		if(parens == 1) p1= f;
		}
	else if(*f == ')') --parens;
	}
*p1= '\0';

/* set up output and call commonOutput */
if(fbuf[0] == 's' && fbuf[1] == 't' && fbuf[2] == 'a' &&
   fbuf[3] == 't' && fbuf[4] == 'i' && fbuf[5] == 'c' &&
   isspace(fbuf[6])) sprintf(outbuf,"%s();",fbuf);
else                 sprintf(outbuf,"extern %s();",fbuf);
if(lflag) sprintf(cmmnt,"/* %-10s:%4d */",fname,linecnt);
else      sprintf(cmmnt,"/* %-15s */",fname);
commonOutput(outbuf,"  ",cmmnt);
}

/* ----------------------------------------------------------------------- */

/* patmatch_output: this function uses PatMatch {{{2 */
static void patmatch_output(void)
{
char *f;
char *funcname    = NULL;
char *funcnameEnd = NULL;


for(f= fbuf, funcname= NULL; *f; ++f) {
	if(*f == '_' || isalpha(*f)) {
		funcname= f;
		for(++f; *f; ++f) if(!isalnum(*f) && *f != '_') break;
		funcnameEnd= f;
		f          = stpblk(f);
		if(*f == '(') {
			f= stpblk(f+1);
			if(*f != '*') break;
			}
		funcname= NULL;
		--f;
		}
	}
if(funcname) {
	strncpy(currfuncname,funcname,(funcnameEnd - funcname));
	currfuncname[(funcnameEnd - funcname)]= '\0';
	}
else strcpy(currfuncname,"");

}

/* --------------------------------------------------------------------- */

/* proto_output: this function prints out prototype definitions if the {{{2
 * functions are declared using prototype-format.
 */
static void proto_output(void)
{
char  argbuf[MAXBUF];
char  cmmnt[MAXBUF];
char  locbuf[FMAXBUF];
char *f          =NULL;
char *funcname   =NULL;
char *funcnameEnd=NULL;
char *lb         =NULL;
char *type       =NULL;


cmmnt[0]= '\0';

/* C declarations have the format:   ({...} is optional)
 *
 *   {type} {(* {(* ...}} funcname ( arglist ) {{[#] {[#] )} {()}
 *
 * find funcname:
*/
for(f= fbuf, funcname= type= NULL; *f; ++f) {
	if(*f == '_' || isalpha(*f)) {
		if(!type) type= f;
		funcname= f;
		for(++f; *f; ++f) if(!isalnum(*f) && *f != '_') break;
		funcnameEnd= f;
		f          = stpblk(f);
		if(*f == '(') {
			f= stpblk(f+1);
			if(*f != '*') break;
			}
		funcname= NULL;
		--f;
		}
	}
if(!funcname) {	/* unable to locate function name in fbuf! */
	fbuf[FMAXBUF-30]= '\0';	/* overflow of locbuf protection */
	if(langmode == CPP) {
		/* assume operator+ etc or some other function that is presumably
		 * defined in a class somewhere.  Such a function doesn't need
		 * to be prototyped, anyway.
		 */
		return;
		}
	else error(XTDIO_ERROR,"fbuf<%s> has no function name!\n<%s:%d> <%s>\n",
	  fbuf,sprt(fnamebuf),linecnt,sprt(buffer));
	}

/* determine if there's a type */
if(type == funcname) type= NULL;

/* copy fbuf up to and including funcname */
for(f= fbuf, lb= locbuf; f < funcnameEnd; ++f, ++lb) *lb= *f;
*lb= '\0';
f  = stpblk(funcnameEnd);

if(strchr(locbuf,':') && !hflag) { /* C++: no :: or ::~ stuff in prototypes */
	return;
	}


/* check for presence of keyword "void" */
if(*f == '(' &&
  *(f+1) == 'v' && *(f+2) == 'o' && *(f+3) == 'i' && *(f+4) == 'd' &&
  *(f+5) == ')') {
	strcpy(lb,"(void)");
	}

/* check for (): will be mapped to (void) */
else if(*f == '(' && *stpblk(f+1) == ')') {
	strcpy(lb,"(void)");
	}

else if(uflag) { /* keep user-variables in prototype */
	strcpy(lb,f);
	}

else { /* strip off user-variables */
	strcpy(argbuf,f);
	stripUserVar(argbuf);
	strcpy(lb,argbuf);
	}			/* strip off user-variables	*/


/* infer a leading "int" if no type is present */
if(Lflag) {
	if(!type) sprintf(outbuf,"int %s{return 0;}",locbuf);
	else {
		char *endtype;

		strcpy(cmmnt,type);
		endtype= cmmnt + (funcname - type);
		if(isalpha(*endtype) || *endtype == '_') endtype[-1]= '\0';
		else {
			while(*endtype && ispunct(*endtype) && *endtype != '_') ++endtype;
			endtype[0]= '\0';
			}
		srmtrblk(cmmnt);
		if(!strcmp(cmmnt,"void")) sprintf(outbuf,"%s{};",locbuf);
		else sprintf(outbuf,"%s{return (%s) NULL;}",locbuf,cmmnt);
		}
	cmmnt[0]= '\0';
	}
else if(xflag) {
	if(!type) sprintf(outbuf,"extern int %s;",locbuf);
	else if(locbuf[0] == 's' && locbuf[1] == 't' && locbuf[2] == 'a' &&
	        locbuf[3] == 't' && locbuf[4] == 'i' && locbuf[5] == 'c' &&
	                                                isspace(locbuf[6])) sprintf(outbuf,"%s;",locbuf);
	else                                                                sprintf(outbuf,"extern %s;",locbuf);
	}
else {
	if(!type) sprintf(outbuf,"int %s;",locbuf);
	else      sprintf(outbuf,"%s;",locbuf);
	}

if(hflag) {
	char        funcnamebuf[NAMELINEFMT];
	char       *fnb                      = NULL;
	static int  first                    = 1;

	if(first) {
		first= 0;
		fprintf(flistout,"if &ch < 2|set ch=2|endif\n");
		}

	/* extract function name */
	for(f= funcname, fnb= funcnamebuf; *f && *f != '('; ++f, ++fnb) *fnb= *f;
	*fnb= '\0';

	/* print out a hint version - older version used mark-a, which Kirk Korver
	 * pointed out was unnecessary.  Although I didn't use his solution, this
	 * one is both shorter and doesn't use any marks.
	 */
	if(hinthl) fprintf(flistout,"inorea %s %s<c-o>:echoh %s<Bar>echo \"%s\"<Bar>echoh None<CR>\n",
	  funcnamebuf,
	  funcnamebuf,
	  hinthl,
	  locbuf);
	else fprintf(flistout,"inorea %s %s<c-o>:echo \"%s\"<CR>\n",
	  funcnamebuf,
	  funcnamebuf,
	  locbuf);
	}
else {
	/* finally, print out the local buffer'ed version of the function */
	if(!Lflag) {
		if(lflag) sprintf(cmmnt,"/* %-10s:%4d */",fname,linecnt);
		else      sprintf(cmmnt,"/* %-15s */",fname);
		}
	commonOutput(outbuf,"  ",cmmnt);
	}

}

/* ----------------------------------------------------------------------- */

/* std_output: this function prints out function definitions {{{2 */
static void std_output(void)
{

sprintf(outbuf,"  %s",fbuf);
commonOutput(outbuf,"    ",(char *) NULL);

}

/* --------------------------------------------------------------------- */

/* output_dummyfunc: this function generats dummy functions for subsequent -T[tau] use {{{2 */
static void output_dummyfunc(void)
{
char *paren;

if(flistout) {
	paren= strchr(fbuf,'(');
	do {
		if(paren && *stpblk(paren+1) == '*') paren= strchr(paren+1,'(');
		else                                 break;
		} while(paren);
	if(paren) {
		*paren= '\0';
		fprintf(flistout,"%s(){}\n",fbuf);
		*paren= '(';
		}
	}

}

/* --------------------------------------------------------------------- */

/* tags_output: this function sorts the Tags and prints them out {{{2 */
static void tags_output(void)
{
char **tagbase = NULL;
int    itag;
int    ntags;
Tag   *tag     = NULL;
Tag   *tagnxt  = NULL;
FILE  *tagsfp  = NULL;


/* count tags and generate tagbase */
for(tag= taghd, ntags= 0; tag; tag= tag->nxt) ++ntags;
if(mflag) ntags+= hdrtagmerge();
tagbase= (char **) calloc((size_t) ntags,sizeof(char *));

for(tag= taghd, itag= 0, tagnxt= NULL; tag; tag= tagnxt, ++itag) {
	tagnxt       = tag->nxt;
	tagbase[itag]= tag->tagline;
	free((char *) tag);
	}

/* sort tags */

#ifdef __PROTOTYPE__
qsort(tagbase,(size_t) ntags,sizeof(char *),(int (*)(const void *,const void *)) tag_compare);
#else
qsort(tagbase,(size_t) ntags,sizeof(char *),(int (*)()) tag_compare);
#endif

/* open <tags> file for output */
if(vflag) fprintf(stderr,"%sgenerating <%stags%s>%s\n",CYAN,GREEN,CYAN,NRML);
tagsfp= fopen("tags","w");
if(!tagsfp) {
	error(XTDIO_WARNING,"unable to open <%stags%s> file\n",YELLOW,GREEN);
	tagsfp= stdout;
	}

/* print out tags and free up memory */
for(itag= 0; itag < ntags; ++itag) {
	fputs(tagbase[itag],tagsfp);
	free(tagbase[itag]);
	}
free((char *) tagbase);

if(tagsfp != stdout) fclose(tagsfp);

}

/* =======================================================================
 * Utilities: {{{1
 */

/* CheckPatMatch: this function compares the buffer to the patmatch {{{2 */
static void CheckPatMatch(void)
{

if(patmatch->pat) {
	char *q;
	int   len;
	if(stcmpm2(buffer,patmatch->pat,&q,&len)) {
		if     (lflag == 1) printf("%s : %s : %s",fnamebuf,currfuncname,buffer);
		else if(lflag == 2) printf("%s %d : %s : %s",fnamebuf,linecnt,currfuncname,buffer);
		else                printf("%s : %s",currfuncname,buffer);
		}
	}
else if(patmatch->lpat) {
	if(stlpm2(buffer,patmatch->lpat)) {
		if     (lflag == 1) printf("%s : %s : %s",fnamebuf,currfuncname,buffer);
		else if(lflag == 2) printf("%s %d : %s : %s",fnamebuf,linecnt,currfuncname,buffer);
		else                printf("%s : %s",currfuncname,buffer);
		}
	}

}

/* --------------------------------------------------------------------- */

/* stripUserVar: strip user variable {{{2 */
static void stripUserVar(char *argbuf)
{
char *abgn     = NULL;
char *aend     = NULL;
char *argbufend= NULL;
char *u        = NULL;
char *uvarbgn;
char *uvarend;
int   parens   = 1;
int   finf     = 0;
int   space    = 0;



/* get abgn to point to the function's first '(' and
 *     argbufend to point to the function's trailing ')'
 */
for(parens= 0, abgn= NULL, argbufend= argbuf; *argbufend; ++argbufend) {
	if(*argbufend == '(') {
		++parens;
		if(!abgn) abgn= argbufend;		/* first '(' encountered now	*/
		}
	else if(*argbufend == ')') --parens;
	if(abgn && parens == 0) break;		/* '(' ... balanced ... ')'		*/
	}

if(!abgn) {	/* not a function call */
	return;
	}

/* get one arg at a time */
for(parens= 0; *abgn && abgn < argbufend; abgn= aend + 1, space= finf= 0) {


	/* find aend and uvarbgn/end */
	for(aend= stpblk(abgn), uvarbgn= uvarend= NULL; *aend; ++aend) {

		/* aend search */
		if     (*aend == '(') ++parens;
		else if(*aend == ')') --parens;
		else if(*aend == ',' && parens == 1) {
			if(!uvarend) uvarend= aend;
			break;
			}

		/* uvar search */
		if(!uvarbgn && (*aend == '_' || isalpha(*aend))) {
			uvarbgn= aend;
			space  = 0;
			}
		else if(uvarbgn && !uvarend) {
			if(isspace(*aend)) {
				uvarend= aend;
				space  = 1;
				}
			else if(*aend == '[') {
				uvarend= aend;
				space  = 0;
				}
			else if(*aend == ')') {
				uvarend= aend;
				space  = 0;
				finf   = 1;
				}
			}
		else if(uvarbgn && uvarend) {
			if(parens == 1) {
				if(isspace(*aend)) {
					space= 1;
					}
				else if(space && (*aend == '_' || isalpha(*aend))) {
					uvarbgn= aend;
					uvarend= NULL;
					space  = 0;
					}
				}
			else if(parens > 1) {
				if(!finf && (*aend == '_' || isalpha(*aend))) {
					space  = 0;
					finf   = 1;
					uvarbgn= aend;
					uvarend= NULL;
					}
				}
			}
		}


	/* strip off user variable */
	if(uvarbgn && uvarend) {
		while(uvarbgn > argbuf && isspace(uvarbgn[-1])) --uvarbgn;
		uvarend= stpblk(uvarend);

		aend-= (uvarend - uvarbgn);
		for(u= uvarend; *u; ++u, ++uvarbgn) {
			*uvarbgn= *u;
			}
		*uvarbgn= '\0';

		}
	}

}

/* ========================================================================
 * I/O Handling Software
 */
static char *b     = NULL;
static int   ifctr = 0;
static int   block = 0;

/* ----------------------------------------------------------------------- */

/* ioreset: this resets i/o package below {{{2
 * mode=0: don't preprocess
 *     =1: do    preprocess
 */
static void ioreset(int mode)
{

ifctr       = block = 0;
b           = NULL;
preprocmode = mode;

}

/* ----------------------------------------------------------------------- */

/* nxtc: delivers the next character from filename {{{2 */
static char nxtc(char *routine)
{
int ic;


if(!b) { /* initialize buffer pointer */
	b = buffer;
	*b= '\n';
	}

/* if character *s is a newline, then get the next line */
if(*b == '\n') {
	b= flist_preprocess();
	if(b == NULL) { /* end-of-file found */
		q0= q1= '\0';
		b = NULL;
		longjmp(endfile,1);
		}
	}
else ++b;

q0= *b;
if(q0 == '\n') { /* look ahead in stream, one char */
	ic= fgetc(fp);
	q1= (ic == -1)? '\0' : ((char) ic);
	ungetc((int) q1,fp);
	}
else q1= *(b+1);

return q0;
}

/* ----------------------------------------------------------------------- */

/* flist_preprocess: this function is a *very* stupid flist_preprocessor.  {{{2
 *   It passes lines that are
 *     1) not directives (ie. not #ifdef/#if/#... flist_preprocessor commands)
 *     2) not in #else, #elseif blocks
 */
static char *flist_preprocess(void)
{
char *bb     = NULL;
int   asmskip= 0;


do {
GetNewLine:
	if(eflag) tagtell= ftell(fp);

	/* get new line */
	fgets(buffer,FMAXBUF,fp);
	if(feof(fp)) {
		if(ifctr)
		  error(XTDIO_ERROR,
		   "premature end-of-file (#if[...] is missing #endif)\n<%s:%d> <%s>\n",
		   sprt(fnamebuf),
		   linecnt,
		   sprt(buffer));

		return (char *) NULL;
		}

	/* keep linecnt up-to-date */
	++linecnt;

	/* lex mode "preprocessing" */
	if(langmode == LEX || langmode == YACC) {
		if(buffer[0] == '%' && buffer[1] == '{') {
			lexskip= 0;
			if(buffer[2] == '\n') {
				goto GetNewLine;
				}
			memcpy(buffer,buffer+2,strlen(buffer+2) + 1);
			}
		else if(buffer[0] == '%' && buffer[1] == '}') lexskip= 1;
		else if(buffer[0] == '%' && buffer[1] == '%') {
			if(++lexpp == 2) lexskip= 0;
			goto GetNewLine;
			}
		if(lexskip) goto GetNewLine;
		}

	/* check for PatMatch output */
	if(patmatch) CheckPatMatch();

	while(*(stpblk(buffer)) == '#') {
		bb= stpblk(stpblk(buffer)+1);

		/* #if #ifdef #ifndef */
		if     (bb[0] == 'i' && bb[1] == 'f') ++ifctr;

		/* #else #elif */
		else if(bb[0] == 'e' && bb[1] == 'l' && (bb[2] == 's' || bb[2] == 'i') && (bb[3] == 'e' || bb[3] == 'f') ) {
			if(!block) block= ifctr;
			if(ifctr <= 0)
			  error(XTDIO_ERROR,"#el{se|if} missing preceding #if[...]\n<%s:%d> <%s>\n",
			  sprt(fnamebuf),linecnt,sprt(buffer));
			}

		/* #endif */
		else if(bb[0] == 'e' && bb[1] == 'n' && bb[2] == 'd' && bb[3] == 'i' && bb[4] == 'f') {
			if(block == ifctr--) block= 0;
			if(ifctr < 0) error(XTDIO_ERROR,"unmatched #endif\n<%s:%d> <%s>\n", sprt(fnamebuf),linecnt,sprt(buffer));
			}

		/* #pragma */
		else if(bb[0] == 'p' && bb[1] == 'r' && bb[2] == 'a' && bb[3] == 'g' && bb[4] == 'm' && bb[5] == 'a') {
			bb= stpblk(bb + 6);
			if(bb[0] == 'a' && bb[1] == 's' && bb[2] == 'm') {	/* #pragma asm */
				asmskip= 1;
				goto GetNewLine;
				}
			else if(bb[0] == 'e' && bb[1] == 'n' && bb[2] == 'd' && bb[3] == 'a' && bb[4] == 's' && bb[5] == 'm') {	/* #pragma endasm */
				asmskip= 0;
				}
			}
		skipdirlines();	/* skip multi-line #... directives */

		/* if lexmode and $}, return to skipping lex-lines */
		if(langmode == LEX || langmode == YACC) {
			if(buffer[0] == '%' && buffer[1] == '}') {
				lexskip= 1;
				goto GetNewLine;
				}
			}
		}
	} while(block || asmskip);

/* set up buflen, a global parameter */
buflen= strlen(buffer);

return buffer;
}

/* ----------------------------------------------------------------------- */

/* skipdirlines: skip over (multiple) directive lines {{{2 */
static void skipdirlines(void)
{
char *bsrc      = NULL;
char  isstring  = 0;
int   stop_at_end_comment= 0;


/* elide comments from (multiline) directive */
while(1) {
	for(b= buffer; *b; ++b) {
		if     (!bsrc && b[0] == '"')  isstring= *b;
		else if(!bsrc && b[0] == '\'') isstring= *b;

		if(isstring) {
			while(*b && *b != isstring) {
				if(*b == '\\') b+= 2;
				else           ++b;
				}
			isstring= 0;
			}
		else if(b[0]  == '/' && b[1] == '*') bsrc= b;
		else if(b[-1] == '*' && b[0] == '/' && bsrc) {
			strcpy(bsrc,b+1);
			b   = bsrc - 1;
			bsrc= NULL;
			if(stop_at_end_comment) {
				buflen= strlen(buffer);
				if(buffer[buflen-1] == '\n') nxtline();
				return;
				}
			}
		}

	if(bsrc) {	/* elide all trailing comment from directive */
		nxtline();
		stop_at_end_comment= 1;
		bsrc               = buffer;
		}
	else if(b[-2] == '\\' && b[-1] == '\n') {
		nxtline();	/* handle multiline directives */
		}
	else if(!*b) {
		nxtline();
		break;
		}
	}

buflen= strlen(buffer);

}

/* ----------------------------------------------------------------------- */

/* nxtline: this function dumps the buffer and retrieves an entire new line {{{2
 */
static void nxtline(void)
{

/* load buffer with a new line */
if(eflag) tagtell= ftell(fp);
b   = fgets(buffer,FMAXBUF,fp);
++linecnt;

if(b == NULL || !*b) { /* end-of-file found */
	buffer[0]= '\0';
	q0       = q1= '\0';
	b        = NULL;
	longjmp(endfile,1);
	}
buflen= strlen(buffer);

/* check for PatMatch output */
if(patmatch) CheckPatMatch();

}

/* =====================================================================
 * Tags Support: {{{1
 */

/* tags_generate: this function creates ctags-compatable output.  The nice {{{2
 *  thing about this function is that, since flist seems to work with
 *  c++, flist can handle tag-making for c++ programs.  Unfortunately,
 *  not all ctags programs can do that yet.
 */
static void tags_generate(void)
{
char        *fbgn    = NULL;
char        *fend    = NULL;
char         fendhold;
char        *cpp     = NULL;	/* NULL if no :: or ::~, otherwise to class	*/
char        *cnstrctr= NULL;
static char  locbuf[MAXBUF];
static char  cppbuf[MAXBUF];



/* locate beginning of function name */
fbgn= fend= strchr(fbuf,'(');
if(!fbgn) {
	error(XTDIO_WARNING,"%s line %d: could not locate '(' in function name<%s>\n",fnamebuf,linecnt,sprt(fbuf));
	return;
	}
else if(fbgn > fbuf) --fbgn;

/* back up fbgn from '(' over white space */
for(; fbgn > fbuf && isspace(*fbgn); --fbgn) ;
if(fbgn < fend) fend= fbgn + 1;

fendhold= *fend;
*fend   = '\0';

if(langmode == CPP) {
	/* for C++: go to front of operator? */
	if(fbgn >= fbuf + 8 &&
	   fbgn[-8] == 'o' &&
	   fbgn[-7] == 'p' &&
	   fbgn[-6] == 'e' &&
	   fbgn[-5] == 'r' &&
	   fbgn[-4] == 'a' &&
	   fbgn[-3] == 't' &&
	   fbgn[-2] == 'o' &&
	   fbgn[-1] == 'r') fbgn-= 8;

	/* for C++: go to front of operator?? */
	else if(fbgn >= fbuf + 9 &&
	   fbgn[-9] == 'o' &&
	   fbgn[-8] == 'p' &&
	   fbgn[-7] == 'e' &&
	   fbgn[-6] == 'r' &&
	   fbgn[-5] == 'a' &&
	   fbgn[-4] == 't' &&
	   fbgn[-3] == 'o' &&
	   fbgn[-2] == 'r') fbgn-= 9;
	}

/* back up fbgn over "C-variable" letters */
for(; fbgn > fbuf && (isalpha(*fbgn) || isdigit(*fbgn) || *fbgn == '_'); --fbgn) ;
if(!isalpha(*fbgn)) ++fbgn;


/* c++ short tagline support
 *  class::func is tagged normally
 *  func        is "short" tagged
 *
 * Note: constructors and destructors (class::class and class::~class) are
 *       *not* "short" tagged when merge with hdrtags is selected
 */
if(langmode == CPP && (fbgn[-1] == '~' || fbgn[-1] == ':')) {
	cpp= fbgn - 1;
	if(*cpp == '~' && cpp > fbuf) --cpp;
	if(*cpp == ':' && cpp > fbuf) --cpp;
	if(*cpp == ':' && cpp > fbuf) --cpp;
	if(cpp >= fbuf && cpp < fbgn - 1) {
		char ctmp;

		/* back up over space preceding the :: */
		for(; cpp > fbuf && isspace(*cpp); --cpp) ;
		cnstrctr= cpp+1;	/* [whitespace]::[~]func */

		/* back up to the beginning of the C++ class name */
		for(; cpp > fbuf && (isalpha(*cpp) || isdigit(*cpp) || *cpp == '_'); --cpp) ;
		if(!isalpha(*cpp)) ++cpp;

		ctmp     = *cnstrctr;
		*cnstrctr= '\0';
		if(mflag && !strcmp(cpp,fbgn)) {	/* class::[~]class detector */
			*cnstrctr= ctmp;
			}
		else {
			*cnstrctr= ctmp;
			cnstrctr = NULL;
			}

		}
	else cpp= NULL;
	}
else cpp= NULL;

if(eflag) {
	/* generate a tag, almost etag style (has additional leading tag id)*/
	char *fb;
	fb= strchr(fbufline,'(');
	if(fb) *(++fb)= '\0';
	else   fb     = fbufline + strlen(fbufline);
	sprintf(locbuf,"%s\t%s%c%d,%ld",fbgn,fbufline,127,linecnt,tagtell);
	}

else if(!strcmp(fbgn,"main")) {
	/* exception: handle main() in the standard tags manner!
	 *  Ie. generate a "Mfilename" instead of the function name "main"
	 */
	char *dot;
	char *slash;

	dot= strrchr(fnamebuf,'.');
	if(dot) *dot= '\0';
	slash= strrchr(fnamebuf,'/');
	slash= slash? slash + 1 : fnamebuf;
#ifdef AZTEC_C
	if(!slash) slash= strrchr(fnamebuf,':');
#endif
	sprintf(locbuf,"M%s",slash);
	if(dot) *dot= '.';
	strcat(locbuf,strprintf("	%s	/^%s\n",fnamebuf,antimagic(fbufline)));
	}

else {
	/* generate an ordinary tag */
	sprintf(locbuf,"%s	%s	/^%s\n",fbgn,fnamebuf,antimagic(fbufline));

	if(cpp) { /* generate an additional tag for C++ */
		sprintf(cppbuf,"%s	%s	/^%s\n",cpp,fnamebuf,antimagic(fbufline));
		}
	}

*fend= fendhold;	/* restore character at fend (was null-byte for fnamebuf use */

/* --- generate a Tag --- */

if(langmode == CPP && cpp) {	/* allocate and link a C++ Tag */

	if(!cnstrctr && dflag) {	/* generate function Tag for non-[con/de]structors */
		double_link(Tag,taghd,tagtl,"Tag");
		stralloc(tagtl->tagline,locbuf,"Tag");
		}

	if(!eflag && langmode == CPP && cpp) {		/* generate class::function Tag */
		double_link(Tag,taghd,tagtl,"Tag");
		stralloc(tagtl->tagline,cppbuf,"Tag");
		}
	}

else { /* generate a normal C tag */
	double_link(Tag,taghd,tagtl,"Tag");
	stralloc(tagtl->tagline,locbuf,"Tag");
	}

if(fflag) {	/* generate filename:func tag */
	char *dot;

	dot= strrchr(fnamebuf,'.');
	if(dot) *dot= '\0';
	sprintf(locbuf,"%s:%s",fnamebuf,tagtl->tagline);
	if(dot) *dot= '.';

	double_link(Tag,taghd,tagtl,"Tag");
	stralloc(tagtl->tagline,locbuf,"Tag");
	}

}

/* ----------------------------------------------------------------------- */

/* tag_compare: compare two tags {{{2 */
static int tag_compare(const char **tag1,const char **tag2)
{
int ret;


ret= strcmp(*tag1,*tag2);

return ret;
}

/* --------------------------------------------------------------------- */

/* hdrtagmerge: this function reads <hdrtags> and merges them with {{{2
 * the usual flist's function tags
 *
 * This routine gives preference to flist's functions; ie. hdrtags
 * with labels duplicating an flist function (which may happen when
 * hdrtag is run with the -p option which picks up prototypes).
 */
static int hdrtagmerge(void)
{
char  buf[MAXBUF];
char  tagbuf[MAXBUF];
int   ntag   = 0;
FILE *fptag;
PS   *pstags = NULL;
Tag  *tag;


if(vflag) fprintf(stderr,"%smerging    <%shdrtags%s>%s\n",CYAN,GREEN,CYAN,NRML);

/* first, construct a parsrch table for current tags */
pstags= ps_make();
for(tag= taghd; tag; tag= tag->nxt) {
	sscanf(tag->tagline,"%s",tagbuf);
	ps_insert(pstags,tagbuf,(void *) tag);
	}

/* read the <hdrtags> file and append if the tag is not already
 * in the flist database using Dr. Chip's ParSrch routines
 */
fptag= fopen("hdrtags","r");
if(fptag) {
	while(fgets(buf,MAXBUF,fptag)) {

		if(buf[0] == 12) {
			error(XTDIO_ERROR,"<%shdrtags%s> was generated for etags (e) but flist wasn't\n",YELLOW,GREEN);
			}

		sscanf(buf,"%s",tagbuf);
		ps_search(pstags,tagbuf,(void **) &tag);
		if(!tag) {
			++ntag;
			double_link(Tag,taghd,tagtl,"Tag");
			stralloc(tagtl->tagline,buf,"Tag");
			}
		}
	fclose(fptag);
	}

/* free up ParSrch structure */
#ifdef __PROTOTYPE__
ps_free(pstags,(void (*)(void *)) NULL);
#else
ps_free(pstags,(void (*)()) NULL);
#endif

return ntag;
}

/* --------------------------------------------------------------------- */

/* antimagic: this function converts a line with potentially "magic" {{{2
 *  characters into one with those characters escaped.  It also refuses
 *  to allow comments into the search string.
 */
static char *antimagic(char *line)
{
char       *a;
char       *b;
static char buf[MAXBUF+MAXBUF+1];
char       *l;


for(b= buf, l= line; *l && *l != '\n' && *l != '/'; ++l, ++b) {
	if(aflag) {	/* apply antimagic to magic characters (an escape character)	*/
		for(a= magic; *a; ++a) if(*l == *a) break;
		if(*a) *(b++)= '\\';
		}
	*b= *l;                 /* copy character into buffer        */
	}

switch(*l) {

case '\0':
case '\n':
	*(b++)= '$';
	*(b++)= '/';
	*b    = '\0';							/* terminate buffer with null		*/
	break;

case '/':
	*(b++)= '/';
	*b    = '\0';							/* terminate buffer with null		*/
	break;

default:
	error(XTDIO_SEVERE,"antimagic: line<%s> yielded l<%s>\n",sprt(line),sprt(l));
	break;
	}

return buf;
}

/* --------------------------------------------------------------------- */

/* etags_output: this function sorts the ETags and prints them out {{{2 */
static void etags_output(void)
{
char  *ptag;
char **tagbase= NULL;
int    itag;
int    ntags;
long   tagbytes;
ETag  *etag   = NULL;
FILE  *tagsfp = NULL;
Tag   *tag    = NULL;
Tag   *tagnxt = NULL;


if(vflag) fprintf(stderr,"%setag       %s%s%s%s\n",CYAN,GREEN,fnamebuf,CYAN,GREEN);

/* open <TAGS> file for output */
tagsfp= fopen("TAGS","w");
if(!tagsfp) {
	error(XTDIO_WARNING,"unable to open <%stags%s> file\n",YELLOW,GREEN);
	tagsfp= stdout;
	}

/* merge hdrtag-generated tags with ETags data */
if(mflag) hdretagmerge();

if(tagtl) makeETag(NULL);	/* move Tag list to old ETag */

/* for every etag ... */
for(etag= etaghd; etag; etag= etag->nxt) {

	/* simplify access */
	taghd= etag->taghd;
	tagtl= etag->tagtl;

	/* count tags and generate tagbase */
	for(tag= taghd, ntags= 0; tag; tag= tag->nxt) ++ntags;
	tagbase= (char **) calloc((size_t) ntags,sizeof(char *));

	/* initialize tagbase */
	for(tag= taghd, itag= 0, tagnxt= NULL, tagbytes= 0; tag; tag= tagnxt, ++itag) {
		tagnxt       = tag->nxt;
		tagbase[itag]= tag->tagline;
		tagbytes    += strlen(strchr(tag->tagline,'\t'));;
		free((char *) tag);
		}

	/* sort tags */

#ifdef __PROTOTYPE__
	qsort(tagbase,(size_t) ntags,sizeof(char *),
	 (int (*)(const void *,const void *)) tag_compare);
#else
	qsort(tagbase,(size_t) ntags,sizeof(char *),(int (*)()) tag_compare);
#endif

	/* print out etags and free up memory */
	fprintf(fp,"\014\n%s,%ld\n",etag->filename,tagbytes);

	for(itag= 0; itag < ntags; ++itag) {
		ptag= strchr(tagbase[itag],'\t') + 1;
		fputs(ptag,tagsfp);
		fputc('\n',tagsfp);
		free(tagbase[itag]);
		}
	free((char *) tagbase);
	}

if(tagsfp != stdout) fclose(tagsfp);

}

/* --------------------------------------------------------------------- */

/* hdretagmerge: this function reads <hdrtags> and merges them with
 * the flist's function etags
 *
 * This routine gives preference to flist's functions; ie. hdrtags
 * with labels duplicating an flist function (which may happen when
 * hdrtag is run with the -p option which picks up prototypes).
 */
static void hdretagmerge(void)
{
char  buf[MAXBUF];
char  ok    = 0;
char  tagbuf[MAXBUF];
ETag *etag  = NULL;
FILE *fptag = NULL;
PS   *pstags= NULL;
Tag  *tag   = NULL;


/* first, construct a parsrch table for current tags
 *  Note: hdrtag generates etags with the additional
 *  tag label itself.  tags_generate() does this, too,
 *  although it strips off that extra label before printing
 *  it out.  Makes the duplicate-removal operation work
 *  and allows sorting to occur like the gnu etags does it.
 */
pstags= ps_make();
for(etag= etaghd; etag; etag= etag->nxt) {
	for(tag= etag->taghd; tag; tag= tag->nxt) {
		sscanf(tag->tagline,"%s",tagbuf);
		ps_insert(pstags,tagbuf,(void *) tag);
		}
	}

/* read the <hdrtags> file and append if the tag is not already
 * in the flist database using Dr. Chip's ParSrch routines
 */
fptag= fopen("hdrtags","r");
if(fptag) {
	while(fgets(buf,MAXBUF,fptag)) {
		if(buf[0] == 12 && buf[1] == '\n') {
			if(!fgets(buf,MAXBUF,fptag)) {
				error(XTDIO_ERROR,"missing filename in hdrtag file\n");
				}
			srmtrblk(buf);
			makeETag(buf);
			ok= 1;
			}

		else if(!ok) {	/* sanity check: does <hdrtags> start with ^L\n */
			error(XTDIO_WARNING,"<%shdrtags%s> needs to be generated with the -e flag\n",YELLOW,GREEN);
			fclose(fptag);
			break;
			}

		else {			/* enter <hdrtags> tagline into ETag database */
			sscanf(buf,"%s",tagbuf);
			ps_search(pstags,tagbuf,(void **) &tag);
			if(!tag) {
				srmtrblk(buf);
				double_link(Tag,taghd,tagtl,"Tag");
				stralloc(tagtl->tagline,buf,"Tag");
				}
			}
		}
	fclose(fptag);				/* close <hdrtag> file	*/
	}

/* free up ParSrch structure */
#ifdef __PROTOTYPE__
ps_free(pstags,(void (*)(void *)) NULL);
#else
ps_free(pstags,(void (*)()) NULL);
#endif

}

/* =====================================================================
 * Ctree functions: {{{1
 */

/* CtreeSetup: this function {{{2 */
static void CtreeSetup(void)
{
NameList *nm;
char     *lxn;


/* set up implied report flags */
if(!Tfflag && !Tgflag && !Tuflag && !Ttflag && !Tpflag) {
	if     (Trflag || Taflag) Ttflag= 1;	/* specified root or all roots -> tree report */
	else if(Txflag || Tsflag) Tuflag= 1;	/* not tree, but exclude/sort  -> use report  */
	else                      Tfflag= 1;	/* gotta use a ctree report, choose easiest   */
	}

if(Tgflag || Tpflag || Tuflag || Ttflag || Tsflag) {
	int ifile;
	uselistmode= 1;


	/* generate a (blank) ParSrch database */
	psname= ps_make();

	/* set up UseList pointers:
	 * install NameList (by function names) into ParSrch database:
	 * This allows ps_search() to map a candidate word into a pointer
	 * to the associated NameList
	 */
	for(nm= namehd; nm; nm= nm->nxt) {
		if(exclname) {
			/* however, if the name is in the exclname ParSrch database,
			 * *don't* include it!
			 */
			char *output= NULL;
			ps_search(exclname,nm->name,(void **) &output);
			if(output) {
				continue;
				}
			}
		ps_insert(psname,nm->name,(void *) nm);
		}

	/* -Tu or -Tt needs uselist; -Ts only needed psname to be set up */
	if(Tgflag || Tpflag || Tuflag || Ttflag) {
		for(ifile= 0; ifile < ga_getargc; ++ifile) {
			lxn= strrchr(ga_getargv[ifile],'.');
			if(lxn && !strcmp(lxn,".lxn")) continue;
#ifdef USE_DODIR
			dodir(ga_getargv[ifile]);
#else
			flist(ga_getargv[ifile]);
#endif
			}
		}
	}
else psname= NULL;

/* set up namelinefmt */
setnamefmt();

/* if uselistmode, then remove "if" from psname database */
if(uselistmode && psname) ps_delete(psname,"if",NULL);

/* sort database */
if(Tsflag) {
	ps_srtinit(psname);
	/* COMBAK -- need to sort uselists */
	}

}

/* --------------------------------------------------------------------- */

/* CtreeFoundReport: this function generates the "Found" report (-Tf) {{{2 */
static void CtreeFoundReport(int argc,char **argv)
{
NameList *name;


if(vflag) fprintf(stderr,"Writing Found Report\n");

CtreePrintTitle(argc,argv,"Functions Found Report");
if(Tsflag) {
	NameList *output;
	while((output= (NameList *) ps_srtnxt(psname))) CtreePrintName(output);
	}
else for(name= namehd; name; name= name->nxt) CtreePrintName(name);
printf("\n\n");

}

/* --------------------------------------------------------------------- */

/* CtreeUseReport: this function generates the used/called report (-Tu) {{{2 */
static void CtreeUseReport(int argc,char **argv)
{
NameList *name;
UseList  *p;
UseList  *u;


if(vflag) fprintf(stderr,"Writing Use Report\n");

/* print "Used" title */
CtreePrintTitle(argc,argv,"%sFunctions Called Upon %s| %sFunction Called By  Report%s",WHITE,CYAN,WHITE,NRML);

if(Tsflag) { /* used sorted names */
	NameList *output;

	while((output= (NameList *) ps_srtnxt(psname))) {
		if(output->suppress & SUPPRESS_LXN) continue;
		CtreePrintName(output);
		p= output->phd;
		u= output->uhd;
		for(; u && p; u= u->nxt, p= p->nxt) {
			printf("\t%-34s",u->name->name);
			printf(" %s|%s %s\n",CYAN,GREEN,p->name->name);
			}
		for(; p; p= p->nxt) printf("\t%-34s %s|%s %s\n"," ",CYAN,GREEN,p->name->name);
		for(; u; u= u->nxt) printf("\t%-34s %s|%s\n",u->name->name,CYAN,GREEN);
		}
	printf("\n\n");
	return;
	}

/* handle namelist */
for(name= namehd; name; name= name->nxt) {
	if(name->suppress & SUPPRESS_LXN) continue;
	CtreePrintName(name);
	p= name->phd;
	u= name->uhd;
	for(; u && p; u= u->nxt, p= p->nxt) {
		printf("\t%-34s",u->name->name);
		printf(" %s|%s %s\n",CYAN,GREEN,p->name->name);
		}
	for(; p; p= p->nxt) printf("\t%-34s %s|%s %s\n"," ",CYAN,GREEN,p->name->name);
	for(; u; u= u->nxt) printf("\t%-34s %s|%s\n",u->name->name,CYAN,GREEN);
	}
printf("\n\n");

}

/* --------------------------------------------------------------------- */

/* CtreeTreeReport: this function forms a calling tree (-Ta) {{{2 */
static void CtreeTreeReport(int argc,char **argv)
{
NameList *name= NULL;


if(vflag) fprintf(stderr,"Writing Tree Report\n");

/* print out Tree title */
if(!Tgflag) {
	if     (Taflag)  CtreePrintTitle(argc,argv,"All Roots' Function Trees Report");
	else if(Trflag)  CtreePrintTitle(argc,argv,"Function Tree Report <%s%s%s>",GREEN,Trflag,WHITE);
	else if(!Tpflag) CtreePrintTitle(argc,argv,"Function Tree Report");
	}

if(Taflag) { /* print out all roots */

	/* print out tree for all roots, sorted */
	if(Tsflag) {
		NameList *output;

		while((output= (NameList *) ps_srtnxt(psname))) {
			if(!output->phd || (output->phd->name == output && !output->phd->nxt)) {
				/* this routine has no predecessors => this is a root routine */
				if(Tgflag) CtreeGraphReport(output,0);
				else {
					if(Tpflag) {
						CtreeLatexSizing(name,0,0);
						CtreeLatex(name,0,0);
						}
					else {
						printf("\n\n%s    ----    ----    ----  ",CYAN);
						printf("%s%s  ----    ----    ----%s%s\n",WHITE,output->name,CYAN,GREEN);
						CtreePrintTree(name,0,0);
						}
					}
				}
			}
		}

	else { /* print out tree for all roots, not sorted */
		for(name= namehd; name; name= name->nxt) {
			if(!name->phd || (name->phd->name == name && !name->phd->nxt)) {

				/* this routine has no predecessors => this is a root routine */
				if(Tgflag) CtreeGraphReport(name,0);
				else {
					if(Tpflag) {
						CtreeLatexSizing(name,0,0);
						CtreeLatex(name,0,0);
						}
					else {
						printf("\n\n    %s----    ----    ----  %s%s%s  ----    ----    ----%s\n", CYAN,WHITE,name->name,CYAN,GREEN);
						CtreePrintTree(name,0,0);
						}
					}
				}
			}
		}
	}

else {
	if(Trflag) {
		/* print out tree for specified root function */
		for(name= namehd; name; name= name->nxt) if(!strcmp(Trflag,name->name)) break;
		if(!name) error(XTDIO_ERROR,"function<%s> was not found, cannot generate a tree for it\n",Trflag);
		}
	/* use the root name -- check for "main" first, then for the first root */
	else {
		for(name= namehd; name; name= name->nxt) if(!strcmp("main",name->name)) break;
		}

	if(name) {
		if(Tpflag) {
			CtreeLatexSizing(name,0,0);
			CtreeLatex(name,0,0);
			}
		else CtreePrintTree(name,0,0); /* print tree for specified root function      */
		}
	else {                             /* choose first root function (main not found) */
		for(name= namehd; name; name= name->nxt) if(!name->phd || (name->phd->name == name && !name->phd->nxt)) break;
		if(name) {
			if(Tgflag) CtreeGraphReport(name,0);
			else if(Tpflag) {
				CtreeLatexSizing(name,0,0);
				CtreeLatex(name,0,0);
				}
			else CtreePrintTree(name,0,0);
			}
		else error(XTDIO_WARNING,"no \"main\" in tree and no root functions, either\n");
		}
	}

}

/* --------------------------------------------------------------------- */

/* CtreePrintTitle: prints out a title {{{2 */
static void CtreePrintTitle(
  int    argc,
  char **argv,
  char *title,
  ...)
{
char       rpt_title[TITLEBUF];
char       tbuf[TITLEBUF];
int        iargc;
int        numfiles;
int        tlen;
static int first = 1;
va_list    args;

/* put out a page eject if not first report */
if(first) first= 0;
else      fputc(EJECT,stdout);

/* print out the title to the report */
fputs(WHITE,stdout);
va_start(args,title);
vprintf(title,args);
va_end(args);
printf("%s\n",GREEN);

/* count number of files present */
for(iargc= numfiles= 0; iargc < argc; ++iargc) if(argv[iargc][0] != '-') ++numfiles;

if(numfiles > 1) { /* document files used to build tree */
	sprintf(rpt_title,"%sFiles Used:%s ",CYAN,GREEN);
	tlen= strlen(rpt_title) + 7;

	for(iargc= 1; iargc < argc; ++iargc) {
		if(argv[iargc][0] == '-') continue;

		sprintf(tbuf,"%s ",argv[iargc]);
		if(strlen(tbuf) + tlen > 60) {
			puts(rpt_title);
			strcpy(rpt_title,"\t    ");
			tlen= strlen(rpt_title) + 7;
			}
		else tlen+= strlen(tbuf);
		strcat(rpt_title,tbuf);
		}

	printf("%s\n",rpt_title);
	}

/* put out one blank line */
fputs("\n",stdout);
}

/* --------------------------------------------------------------------- */

/* CtreePrintName: prints a name line {{{2 */
static void CtreePrintName(NameList *name)
{
if(name && name->name && name->filename) {
	fputs(CYAN,stdout);
	printf(namelinefmt,sprt(name->name),GREEN,sprt(name->type));
	fputs(GREEN,stdout);
	printf(flinefmt,CYAN,GREEN,sprt(name->filename),CYAN,GREEN,name->linenum);
	if(Tlflag) printf("-%ld",name->linenum_last);
	printf("\n");
	}
}

/* --------------------------------------------------------------------- */

/* CtreeGraphReport: this function {{{2 */
static void CtreeGraphReport(NameList *output,int depth)
{
int      idepth;
UseList *u;


/* print top-of-tree */
if(depth == 0) printf("%s()\n",output->name);

/* print any functions that output->name uses */
for(u= output->uhd; u; u= u->nxt) {
	if(output->suppress & SUPPRESS_LXN) continue;

	/* print out leader and function */
	for(idepth= 0; idepth < depth; ++idepth) printf("| ");
	printf("|-%s()%c\n",u->name->name,u->name->recursion);

	/* output any more functions that get used by this one */
	if(u->name->recursion != '*') {
		u->name->recursion= '*';
		CtreeGraphReport(u->name,depth+1);
		u->name->recursion= ' ';
		}
	}

}

/* ----------------------------------------------------------------------- */

/* setnamefmt: this function sets up the namelinefmt used by pnameline {{{2 */
static void setnamefmt(void)
{
NameList *name;
int      flen;
int      len;
int      nlen;	/* max strlen(name->name)	*/
int      tlen;	/* max strlen(name->type)	*/


if(namehd) {
	for(name= namehd, nlen= tlen= flen= 0; name; name= name->nxt) {
		len= strlen(name->name);
		if(len > nlen) nlen= len;
		len= strlen(name->type);
		if(len > tlen) tlen= len;
		len= strlen(name->filename);
		if(len > flen) flen= len;
		}

	/* set up namelinefmt */
	if(nlen + tlen + 3 <= 44) {
		sprintf(namelinefmt,"%%-%ds : %%s%%-%ds",nlen,tlen);
		}
	else strcpy(namelinefmt,"%-30s : %s%-11s");

	/* set up flinefmt */
	if(flen + 17 <= 30) {
		sprintf(flinefmt," %%sfile<%%s %%-%ds %%s> line %%s%%ld",flen);
		}
	else if(flen + 17 <= 32) {
		sprintf(flinefmt," %%sfile<%%s%%-%ds%%s> line %%s%%ld",flen);
		}
	else strcpy(flinefmt," %%sfile<%%s%-15s%%s> line %%s%ld");
	}

else {	/* default format strings */
	strcpy(namelinefmt,"%-30s : %%s%-11s");
	strcpy(flinefmt," %%sfile<%%s%15s%%s> line %%s%ld");
	}

}

/* --------------------------------------------------------------------- */

/* CtreeUseList: this function sets up UseLists {{{2 */
static void CtreeUseList(void)
{
NameList        *called       = NULL;
UseList         *callby       = NULL;
char             cword[MAXBUF];
char             mode_comment = 0;
char             mode_string  = 0;
char            *b;
char            *cw;
char            *ignore       = NULL;
int              linecnt      = 0;
static NameList *inname       = NULL;
static int       ifline;
static void     *pifline      = NULL;


/* supports -Ti option, which allows user to suppress functions
 * called via "if" lines
 */
if(!pifline) {
	pifline= (void *) &ifline;
	ps_insert(psname,"if",pifline);
	}
if(!inname) {
	inname= namehd;
	}

/* sanity check -- insure that inname's filename and what flist opened are the same */
if(!inname || !inname->filename || strcmp(inname->filename,fopenfilename)) {
	/* this test may occur if a C file doesn't actually contain any functions */
	return;
	}

/* prepare i/o package for non-preprocessed code */
ioreset(0);

/* read in *all* lines, using NameList's linenum and linenum_last to figure out
 * what lines to make UseList linkages for
 */
while(inname && fgets(buffer,FMAXBUF,fp)) {
	++linecnt;
	buffer[FMAXBUF-1]= '\0';
	ifline= 0;

	if(inname->linenum <= linecnt && linecnt <= inname->linenum_last) {

		/* examine all characters in line */
		for(b= buffer; *b; ++b) {

			/* skip over comments and strings */
			if(!mode_comment) {
				if(!mode_string) {
					if(*b == '"') {       /* skip "..." string */
						mode_string= '"';
						continue;
						}
					else if(*b == '\'') { /* skip '...' string */
						mode_string= '\'';
						continue;
						}
					}
				else if(mode_string) {
					if     (*b == mode_string) mode_string= 0;
					else if(*b == '\\' && b[1]) ++b;
					continue;
					}
				if(b[0] == '/') {
					if(b[1] == '/') break; /* skip C++ style comment */
					if(b[1] == '*') {      /* skip C   style comment */
						++b;
						mode_comment= 1;
						continue;
						}
					}
				/* not a string or a comment */
				}
			else if(b[0] == '*' && b[1] == '/') {	/* in C-style comment, look for terminator */
				++b;
				mode_comment= 0;
				continue;
				}
			else continue;

			/* skip characters that don't begin C function names */
			if(!isalpha(*b) && *b != '_') continue;

			/* pick up potential C/C++ function name */
			for(cw= cword; b && *b && (isalnum(*b) || *b == '_'); ++cw, ++b) *cw= *b;
			if(!*b) --b;	/* allows for() loop to terminate properly */
			*cw= '\0';		/* terminate cword properly                */

			/* search psname database and see if the cword is, in fact, a function name
			 * If it *is* in the database, check if we're excluding it (<*.lxn> file)
			 */
			called= NULL;
			ignore= NULL;
			ps_search(psname,cword,(void **) &called);
			if(called && exclname) ps_search(exclname,cword,(void **) &ignore);

			if(called && !ignore) {
				if(((void *) called) == pifline) ifline= 1;
				else if(called) {
					if(Txflag) {	/* exclude duplicate functions that inname calls */
						UseList *icall;
						for(icall= inname->uhd; icall; icall= icall->nxt) if(icall->name == called) break;
						if(!icall) {
							double_link(UseList,inname->uhd,inname->utl,"    UseList calls entry\n");
							inname->utl->ifline= ifline;
							inname->utl->name  = called;
							}
						}
					else {	/* include all functions that inname calls */
						double_link(UseList,inname->uhd,inname->utl,"UseList calls entry\n");
						inname->utl->ifline= ifline;
						inname->utl->name  = called;
						}

					/* set up called's called-by list - avoid duplicating called-by NameList entries */
					for(callby= called->phd; callby; callby= callby->nxt) if(callby->name == inname) break;
					if(!callby) {
						double_link(UseList,called->phd,called->ptl,"UseList called-by entry\n");
						called->ptl->ifline= ifline;
						called->ptl->name  = inname;
						}

					}
				}
			}

		/* update inname to next function at last-line-of-inname */
		if(inname && linecnt == inname->linenum_last) {
			inname       = inname->nxt;
			mode_string  = 0;
			mode_comment = 0;
			}
		}
	}

}

/* --------------------------------------------------------------------- */

/* CtreePrintTree: print out the name tree with entire hierarchy {{{2 */
static void CtreePrintTree(
  NameList *name,
  int       lvl,
  int       ifline)
{
UseList *u;
int      ilvl;
int      lvlp1;

/* print lvl pairs of blanks */
for(ilvl= 0; ilvl < lvl; ++ilvl) fputs(". ",stdout);

if(ifline) {
	if(name->recursion == ' ') printf("(%s)\n",name->name);
	else if(printf("(%s%c)\n",name->name,name->recursion) == EOF) error(XTDIO_ERROR,"can't write to output\n");
	}
else if(printf("%s%c\n",name->name,name->recursion) == EOF)       error(XTDIO_ERROR,"can't write to output\n");

if(name->recursion != '*') { /* if not recurrence, print name's call tree */
	name->recursion = '*';
	lvlp1           = lvl + 1;
	if(!dflag || ilvl < dflag) for(u= name->uhd; u; u= u->nxt) {
		if(Tiflag) {
			if(!u->ifline) CtreePrintTree(u->name,lvlp1,u->ifline);
			}
		else CtreePrintTree(u->name,lvlp1,u->ifline);
		}
	name->recursion= ' ';
	}
}

/* --------------------------------------------------------------------- */

/* CtreeLoadNames: this function serves two purposes: (handles <*.lxn> files) {{{2
 * 1) takes a list of names and makes NameList stubs for them
 * 2) takes a list of !names and excludes them from the UseList
 *
 * Allows # to lead off a comment, and ignores blank lines
 */
static void CtreeLoadNames(char *loadfile)
{
FILE *fp;
int   linecnt;
char *cmmnt;


/* open file */
fp= fopenx(loadfile,"r","lxn",NULL);
if(!fp) error(XTDIO_ERROR,"unable to open <%s> for reading\n",sprt(loadfile));

/* read file */
linecnt= 0;
while(fgets(buffer,FMAXBUF,fp)) {

	/* handle linecnt, remove comments, ignore blank lines */
	++linecnt;
	cmmnt= strchr(buffer,'#');
	if(cmmnt) *cmmnt= '\0';
	srmtrblk(buffer);
	if(!buffer[0]) continue;

	if(buffer[0] != '!') {
		ctree_defaultnamelist();

		stralloc(nametl->name,buffer,"CtreeLoadNames");
		stralloc(nametl->filename,fopenfilename,"CtreeLoadNames");
		nametl->type         = "";
		nametl->linenum      = linecnt;
		nametl->linenum_last = linecnt;
		nametl->suppress     = SUPPRESS_LXN;
		}
	else {
		char *xfunc;
		if(!exclname) {
			exclname = ps_make();
			}
		xfunc= stpblk(buffer + 1);
		ps_insert(exclname,xfunc,(void **) 1);
		}
	}

/* close file */
fclose(fp);

}

/* --------------------------------------------------------------------- */


/* --------------------------------------------------------------------- */

/* CtreeLatexSizing: this function prints out a tree using Latex's {{{2
 * picture environment
 */
void CtreeLatexSizing(
  NameList *name,
  int       lvl,
  int       ifline)
{
UseList *u     = NULL;
int      ilvl  = 0;
int      lvlp1 = 0;
int      width = 0;


/* initialize */
if(lvl == 0) {
	ctreewidth= ctreeheight= 0;
	if(halfheight) free(halfheight);
	halfheight= NULL;
	}

/* consider lvl pairs of blanks */
width = lvl;
width+= strlen(name->name);
if(name->recursion == ' ') width+= 2;
else                       width+= 3;
if(ifline)                 width+= 2;
if(width > ctreewidth) ctreewidth= width;
++ctreeheight;

if(name->recursion != '*') { /* if not recurrence, print name's call tree */
	name->recursion = '*';
	lvlp1           = lvl + 1;
	if(!dflag || ilvl < dflag) for(u= name->uhd; u; u= u->nxt) {
		if(Tiflag) {
			if(!u->ifline) CtreeLatexSizing(u->name,lvlp1,u->ifline);
			}
		else CtreeLatexSizing(u->name,lvlp1,u->ifline);
		}
	name->recursion= ' ';
	}

}

/* --------------------------------------------------------------------- */

/* CtreeLatex: this function prints out a tree using Latex's picture environment {{{2 */
void CtreeLatex(
  NameList *name,
  int       lvl,
  int       ifline)
{
UseList     *u          = NULL;
int          ilvl;
int          lvlp1;
static int   curhoff    = 0;
static int   neednewpic = 0;
static FILE *fpout      = NULL;


if(lvl == 0) {
	if(fpout) fclose(fpout);
	fpout= fopen(strprintf("%s.flist",name? name->name : "main"),"w");
	if(!fpout) error(XTDIO_ERROR,"unable to open file<%s%s.flist%s> for writing\n",name? name->name : "main");
	else       printf("LaTeX tree in file<%s.flist>\n",name? name->name : "main");
	fprintf(fpout,"\\setlength{\\unitlength}{1em}\n");
	curhoff= ctreeheight - ctreemaxheight;
	if(curhoff < 0) curhoff= 0;
	if(ctreeheight < ctreemaxheight) fprintf(fpout,"\\begin{picture}(%d,%d)\n",ctreewidth,ctreeheight);
	else                             fprintf(fpout,"\\begin{picture}(%d,%d)\n",ctreewidth,ctreemaxheight);
	neednewpic= ctreemaxheight;
	halfheight= (char *) calloc((size_t) ctreewidth+1,sizeof(char));
	}

/* print lvl vertical lines */
for(ilvl = 1; ilvl < lvl; ++ilvl) {
	if(!halfheight[ilvl-1]) fprintf(fpout,"\\put(%d.1,%d){\\line(0,-1){1}}\n", ilvl-1,ctreeheight - curhoff+1);
	}
if(lvl >= 1) {
	if(halfheight[lvl-1]) fprintf(fpout,"\\put(%d.1,%d){\\line(0,-1){.5}}\n",ilvl-1,ctreeheight - curhoff+1);
	else                  fprintf(fpout,"\\put(%d.1,%d){\\line(0,-1){1}}\n", ilvl-1,ctreeheight - curhoff+1);
	/* the horizontal tick mark */
	fprintf(fpout,"\\put(%d.1,%.1f){\\line(1,0){.2}}\n",lvl-1,((float)ctreeheight-curhoff)+.5);
	}

/* print out [(]function name[*)] */
fprintf(fpout,"\\put(%d,%d)",lvl,ctreeheight - curhoff);
if(ifline) {
	if(name->recursion == ' ') fprintf(fpout,"{(%s)}\n",LatexName(name->name));
	else                       fprintf(fpout,"{(%s%c)}\n",LatexName(name->name),name->recursion);
	}
else fprintf(fpout,"{%s%s}\n",LatexName(name->name),(name->recursion == ' ')? "" : "*");

--ctreeheight;
if(--neednewpic == 0) {
	int oldcurhoff;
	fprintf(fpout,"\\end{picture}\n");
	oldcurhoff = curhoff;
	curhoff   -= ctreemaxheight;
	if(curhoff < 0) curhoff= 0;
	neednewpic= ctreemaxheight;
	fprintf(fpout,"\\begin{picture}(%d,%d)\n",ctreewidth,(curhoff > 0)? ctreemaxheight : oldcurhoff);
	}

if(name->recursion != '*') { /* if not recurrence, print name's call tree */
	name->recursion    = '*';
	lvlp1              = lvl + 1;
	halfheight[lvl] = 0;
	if(!dflag || lvl < dflag) for(u= name->uhd; u; u= u->nxt) {
		if(u->nxt == NULL) halfheight[lvl]= 1;
		if(Tiflag) {
			if(!u->ifline) CtreeLatex(u->name,lvlp1,u->ifline);
			}
		else CtreeLatex(u->name,lvlp1,u->ifline);
		}
	name->recursion= ' ';
	}

if(lvl == 0) fprintf(fpout,"\\end{picture}\n");

}

/* --------------------------------------------------------------------- */

/* LatexName: this function makes a name a legal Latex name {{{2 */
#define CNAMESIZ	33
static char *LatexName(char *name)
{
int          nlen;
static char  buf1[CNAMESIZ];
static char  buf2[CNAMESIZ];
static char  buf3[CNAMESIZ];
static char *buf            = buf1;
static char *n;


if     (buf == buf1) buf= buf2;
else if(buf == buf2) buf= buf3;
else if(buf == buf3) buf= buf1;

for(n= name, b= buf, nlen= 0; *n && nlen < CNAMESIZ-1; ++b, ++n, ++nlen) {
	if(*n == '_') {
		*b++= '\\';
		*b  = *n;
		}
	else *b= *n;
	}
*b= '\0';

return buf;
}

/* --------------------------------------------------------------------- */
/* vim: ts=4  fdm=marker
 */
