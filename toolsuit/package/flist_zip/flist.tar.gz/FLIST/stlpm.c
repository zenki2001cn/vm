/* stlpm3.c: generates LPAT trees for boolean logic-based pattern matching
 *   Author:  Dr. Charles E. Campbell, Jr.
 * Copyright  Dec 14, 1999: Charles E. Campbell, Jr. -- see <Copyright> file
 */
#include <stdio.h>
#include "xtdio.h"

/* ---------------------------------------------------------------------
 * Definitions:
 */
#define PATBUFSIZE	256
#define INCPREC		4

/* ---------------------------------------------------------------------
 * Local Data:
 */
static LPAT *lpathd = NULL;		/* temporary head of forward-linked list of LPATs	*/
static LPAT *lpattl = NULL;		/* temporary tail of forward-linked list of LPATs	*/
static LPAT *dstkhd = NULL;		/* head of data stack								*/
static LPAT *opstkhd= NULL;		/* head of operator stack							*/

/* ---------------------------------------------------------------------
 * Static Prototypes:
 */
#ifdef __PROTOTYPE__
static int lpatexec(char *);                           /* stlpm.c         */
static LPAT *lpatlex(char **);                         /* stlpm.c         */
#else
static int lpatexec();                                 /* stlpm.c         */
static LPAT *lpatlex();                                /* stlpm.c         */
#endif

/* ---------------------------------------------------------------------
 * Source Code:
 */

/* setlpat: analyzes a boolean-logical-pattern string for the subsequent
 *  use of stlpm2
 */
LPAT *setlpat(char *logpat)
{
char *s;
LPAT *lpat   = NULL;


/* initialize the forward linked list */
lpathd= lpattl= NULL;

/* lexically analyze the boolean-logical-pattern string */
for(s= logpat; *s; ) {
	lpat= lpatlex(&s);
	if(!lpat) {
		freelpat(lpathd);
		lpathd= lpattl= NULL;
		break;
		}
	}

/* sanity check */
if(!lpathd) {
	return NULL;
	}

return lpathd;
}

/* --------------------------------------------------------------------- */

/* stlpm: perform boolean-logic-pattern matching using a
 *  string and a pattern string
 */
int stlpm(
  char *str,
  char *pat)
{
int          ret;
static char *opat= NULL;
static LPAT *lpat= NULL;


/* compute the LPATtern (whenever the pattern changes) */
if(!opat) {
	stralloc(opat,pat,"stlpm pat copy");
	lpat= setlpat(pat);
	}
else if(strcmp(pat,opat)) {
	free(opat);
	if(lpat) freelpat(lpat);
	stralloc(opat,pat,"stlpm pat copy");
	lpat= setlpat(pat);
	}

/* perform boolean-logic-pattern matching */
ret= stlpm2(str,lpat);

return ret;
}

/* --------------------------------------------------------------------- */

/* stlpm2: perform boolean-logic-pattern matching on a user's string
 *  in "str" according to the directions in the LPAT
 *   Returns:  0=no match
 *             1=match
 *            -1=error
 */
int stlpm2(char *str,LPAT *lpat)
{

/* initialize */
dstkhd= opstkhd= NULL;

/* handle just a PATtern */
if(lpathd && !lpathd->nxt && lpat->pat) {
	int   len;
	int   ret;
	char *q;
	ret= stcmpm2(str,lpat->pat, &q,&len);
	return ret;
	}

/* handle boolean logic */
for(; lpat; lpat= lpat->nxt) {
	if(lpat->pat) {
		/* push data onto head of data stack */
		lpat->stknxt = dstkhd;
		lpat->preclvl= -1;
		dstkhd       = lpat;
		}
	else {
		/* while lpat->op's preclvl <= dstkhd->op's preclvl:
		 *      Perform top-of-stack operation
		 *      Pop parameter stack, and replace top of parameter stack
		 *        with result of operation.
		 *      Pop top of operator stack.
		 */

		while(opstkhd && lpat->preclvl <= opstkhd->preclvl) {
			lpatexec(str);
			opstkhd= opstkhd->stknxt;
			}

		/* push lpat onto operator stack */
		lpat->stknxt= opstkhd;
		opstkhd     = lpat;
		}
	}	/* lpat for loop */

/* do any remaining operations left on opstk */
if(opstkhd) while(opstkhd) {
	lpatexec(str);
	opstkhd= opstkhd->stknxt;
	}

/* if anything is left on the data stack, then
 * there was an unacceptable expression entered
 */
if(dstkhd && dstkhd->stknxt) {
	return -1;
	}

return dstkhd? dstkhd->preclvl : -1;
}

/* --------------------------------------------------------------------- */

/* lpatexec: execute top-of-stack LPAT
 *
 *  PATtern LPATs are using their "preclvl" as pattern matching result
 *              -1 : use pattern matching
 *   preclvl ==  0 : pattern matching indicated PAT not in user string
 *               1 : pattern matching indicated PAT is  in user string
 *
 *  Returns: 0=ok  1=failure
 */
static int lpatexec(char *str)
{
char *q;		/* on match, will point to matched substring in str	*/
int   left;
int   len;		/* on match, length of matched string				*/
LPAT *dleft;
LPAT *dright;


switch(opstkhd->op) {

case '&':
	/* pop the data stack twice, logical-and 'em, push result */
	if(!dstkhd || !dstkhd->stknxt) {
		return 1;
		}
	dleft        = dstkhd;
	dright       = dstkhd->stknxt;
	dstkhd       = dstkhd->stknxt;
	dleft->stknxt= NULL;


	/* attempt to avoid performing unnecessary pattern matching */
	if(!dleft->preclvl || !dright->preclvl) dright->preclvl= 0;
	else {
		left  = (dleft->preclvl >= 0)?
		  dleft->preclvl             :
		  stcmpm2(str,dleft->pat, &q,&len);
		if(!left) dright->preclvl= 0;
		else      dright->preclvl= (dright->preclvl >= 0)?
		  dright->preclvl                                :
		  stcmpm2(str,dright->pat,&q,&len);
		}
	break;

case '|':
	/* pop the data stack twice, logical-or 'em, push result */
	if(!dstkhd || !dstkhd->stknxt) {
		return 1;
		}
	dleft        = dstkhd;
	dright       = dstkhd->stknxt;
	dstkhd       = dstkhd->stknxt;
	dleft->stknxt= NULL;


	/* attempt to avoid performing unnecessary pattern matching */
	if(dleft->preclvl == 1 || dright->preclvl == 1) dright->preclvl= 1;
	else {
		left  = (dleft->preclvl >= 0)?
		  dleft->preclvl             :
		  stcmpm2(str,dleft->pat, &q,&len);
		if(left) dright->preclvl= 1;
		else     dright->preclvl= (dright->preclvl >= 0)?
		  dright->preclvl                               :
		  stcmpm2(str,dright->pat,&q,&len);
		}
	break;

case '!':
	/* pop the data stack once, push result */
	if(!dstkhd) {
		return 1;
		}


	dstkhd->preclvl= (dstkhd->preclvl >= 0)?
	  !dstkhd->preclvl                     :
	  !stcmpm2(str,dstkhd->pat, &q,&len);
	break;

default:
	error(XTDIO_ERROR,"lpatexec: lpat%d has bad op<%s>\n",
	  dstkhd? dstkhd->id       : 0,
	  dstkhd? cprt(dstkhd->op) : "null dstkhd");
	break;
	}

return 0;
}

/* --------------------------------------------------------------------- */

/* lpatlex: tokenizes a LPAT given a string (lexical analysis)
 *  Yields a double-linked list (lpathd,lpattl) and bumps *s
 *  to point to the next character past the current token substring
 */
static LPAT *lpatlex(char **s)
{
char                *ss;
LPAT                *lpat;
LPAT                *lastlpat;
static int           preclvl= 0;
static unsigned long lpatid= 0L;


/* initial open curly precedence level changing */
for(; **s && **s == '{'; ++*s) preclvl+= INCPREC;

/* sanity check */
if(!**s) {
	freelpat(lpathd);
	preclvl= 0;
	return NULL;
	}

/* initial close curly precedence level changing */
for(; **s && **s == '}'; ++*s) {
	if(preclvl >= INCPREC) preclvl-= INCPREC;
	else {
		freelpat(lpathd);
		preclvl= 0;
		return NULL;
		}
	}

if(!**s) {	/* end-of-string */
	if(preclvl != 0) {
		freelpat(lpathd);
		preclvl= 0;
		return NULL;
		}
	if(lpattl) {
		preclvl= 0;
		return lpathd;
		}
	preclvl= 0;
	freelpat(lpathd);
	return NULL;
	}

/* allocate a new LPAT */
lastlpat= lpattl;
tail_link(LPAT,lpathd,lpattl,"LPAT");
lpat    = lpattl;

/* initialize */
lpat->id     = ++lpatid;
lpat->pat    = NULL;
lpat->op     = 'p';
lpat->preclvl= preclvl;

/* lexically analyze (ie. get a token) */
for(ss= NULL; **s; ++*s) {
	switch(**s) {

	case '{':	/* precedence changing									*/
		if(ss) {
			**s      = '\0';
			lpat->pat    = setpat(ss);
			lpat->preclvl= 0;
			**s          = '{';
			}
		else {
			freelpat(lpathd);
			preclvl= 0;
			return NULL;
			}
		goto lpatexit;
	
	case '}':	/* final close curly precedence level changing			*/
		if(ss) {
			**s      = '\0';
			lpat->pat    = setpat(ss);
			lpat->preclvl= 0;
			**s          = '}';
			}
		else {
			freelpat(lpathd);
			preclvl= 0;
			return NULL;
			}
		goto lpatexit;
	
	case '&':	/* PAT & PAT handler									*/
	case '|':	/* PAT | PAT handler									*/
	case '!':	/* !PAT handler											*/
		if(ss) {	/* terminate a PAT */
			char op;
			op       = **s;
			**s      = '\0';
			lpat->pat    = setpat(ss);
			lpat->preclvl= 0;
			**s          = op;
			}
		else {		/* set up an operator */
			lpat->op      = **s;
			lpat->preclvl+= (**s == '|')? 1 :
			                (**s == '&')? 2 : 3;
			if(**s == '!' && lastlpat && lastlpat->pat) {
				freelpat(lpathd);
				preclvl= 0;
				return NULL;
				}
			++*s;
			}
		goto lpatexit;
	
	case '\\':	/* escape a LPAT special character {}!&| */
		switch((*s)[1]) {

		case '{': case '}':
		case '&': case '|':
		case '!':
			++*s;
			break;

		default:
			break;
			}
		if(!ss) ss= *s;
		break;
	
	default:
		if(!ss) ss= *s;
		break;
		}
	}

/* do a set pat if at end of string */
if(ss && !**s) {
	lpat->pat    = (lpathd != lpat)? setpat_nosetbrace(ss) : setpat(ss);
	lpat->preclvl= 0;
	preclvl      = 0;
	}

lpatexit:
return lpat;
}

/* --------------------------------------------------------------------- */

/* lpatprint: return a string describing the LPAT */
char *lpatprint(LPAT *lpat)
{
char       *b;
int         preclvl    = 0;
int         nxtpreclvl = 0;
static char buf1[PATBUFSIZE];
static char buf2[PATBUFSIZE];
static char buf3[PATBUFSIZE];
static char *buf= buf1;


/* round robin the buffer so lpatprint can be used
 * up to three times in a single printf statement
 */
if     (buf == buf1) buf= buf2;
else if(buf == buf2) buf= buf3;
else                 buf= buf1;

for(b= buf; lpat; lpat= lpat->nxt) {
	switch(lpat->op) {

	case '&':
	case '|':
		*(b++)     = lpat->op;
		break;

	case '!':
		while(preclvl + INCPREC < lpat->preclvl) {
			preclvl+= INCPREC;
			*(b++)  = '{';
			}
		*(b++)     = lpat->op;
		break;

	default:
		nxtpreclvl= lpat->nxt? lpat->nxt->preclvl : 0;
		while(preclvl + INCPREC < nxtpreclvl) {
			preclvl+= INCPREC;
			*(b++)  = '{';
			}

		strcpy(b,patprint(lpat->pat));
		b   += strlen(b);

		while(preclvl >= nxtpreclvl + INCPREC) {
			preclvl-= INCPREC;
			*(b++)  = '}';
			}
		break;
		}
	}
*b= '\0';

return buf;
}

/* --------------------------------------------------------------------- */

/* freelpat: frees LPAT memory use */
void freelpat(LPAT *lpat)
{
LPAT *lpatnxt= NULL;


for(; lpat; lpat= lpatnxt) {
	lpatnxt= lpat->nxt;
	if(lpat->pat) freepat(lpat->pat);
	free((char *) lpat);
	}

}

/* --------------------------------------------------------------------- */

/* stlpm_haslogic: returns 1 if pattern has boolean logic, 0 else */
int stlpm_haslogic(char *pattern)
{
char *p;


for(p= pattern; *p; ++p) {
	if(*p == '\\' && p[1]) ++p;
	else if(*p == '[') {	/* look for matching ] */
		for(++p; *p && *p != ']'; ++p) if(*p == '\\') ++p;
		if(!*p) break;
		}
	else if(*p == '|' || *p == '&' || *p == '!') {
		return 1;
		}
	}

return 0;
}

/* ===================================================================== */

/* --------------------------------------------------------------------- */
