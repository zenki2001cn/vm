/* ps_iterate.c: contains
 *   ps_srtnxt() : returns a pointer to the next     sorted item
 *   ps_srtprv() : returns a pointer to the previous sorted item
 * Copyright  Dec 14, 1999: Charles E. Campbell, Jr. -- see <Copyright> file
 */
#include <stdio.h>
#include "xtdio.h"

/* ---------------------------------------------------------------------
 * Local Prototypes:
 */
static void ps_srtinit2(PS *,PS_LEAF *);                                                                            /* ps_iterate.c    */


/* --------------------------------------------------------------------- */

/* ps_srtinit: this function initializes ps_srtnxt, ps_srtprv */
void ps_srtinit(ParSrch *ps)
{
int ileaf;


/* sanity check */
if(!ps) {
	return;
	}

/* clear out pre-existing ps's PS_SORT list */
if(ps->shd) ps_srtclear(ps);
else {
	ps->shd= ps->stl= NULL;
	}
ps->current= NULL;

/* go through hash list and construct PS_SORTs for those leaves with character! */
for(ileaf= 0; ileaf < ps->treesize; ++ileaf) if(ps->tree[ileaf].c) ps_srtinit2(ps,&ps->tree[ileaf]);

}

/* --------------------------------------------------------------------- */

/* ps_srtinit2: this function recurses down the various trees, setting up ps's PS_SORT list */
static void ps_srtinit2(PS *ps,PS_LEAF *leaf)
{

/* sanity check */
if(!leaf) {
	return;
	}

/* if this leaf has output, append to PS_SORT list */
if(leaf->output) {
	double_link(PS_SORT,ps->shd,ps->stl,"ps_srtinit2: allocated a PS_SORT\n");
	ps->stl->leaf= leaf;
	}

/* recursion down, left, and right */
if(leaf->left)  ps_srtinit2(ps,leaf->left);
if(leaf->nxt)   ps_srtinit2(ps,leaf->nxt);
if(leaf->right) ps_srtinit2(ps,leaf->right);

}

/* --------------------------------------------------------------------- */

/* ps_srtnxt: this function returns a pointer to the
 * next (first) pointer in list.
 */
void *ps_srtnxt(ParSrch *ps)
{

/* sanity check */
if(!ps) {
	return NULL;
	}

ps->current= ps->current? ps->current->nxt : ps->shd;

return (ps->current && ps->current->leaf)? ps->current->leaf->output : NULL;
}

/* --------------------------------------------------------------------- */

/* ps_srtprv: this function returns a pointer to the previous (last)
 * pointer in list.
 */
void *ps_srtprv(ParSrch *ps)
{

/* sanity check */
if(!ps) {
	return NULL;
	}

ps->current= ps->current? ps->current->prv : ps->stl;

return (ps->current && ps->current->leaf)? ps->current->leaf->output : NULL;
}

/* --------------------------------------------------------------------- */

/* ps_srtclear: this function clears out a PS_SORT list */
void ps_srtclear(PS *ps)
{

while(ps->shd) {
	delete_double_link(PS_SORT,ps->shd,ps->shd,ps->stl);
	}

ps->shd     = ps->stl = NULL;
ps->current = NULL;

}

/* ===================================================================== */

/* ===================================================================== */
