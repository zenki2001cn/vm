/* parsrch.c: this file contains a set of functions which implement a
 *  Finite State Automaton.  The FSA appears to permit a search in
 *  parallel for a match to a given set of words
 * Copyright  Dec 14, 1999: Charles E. Campbell, Jr. -- see <Copyright> file
 *
 * You'll need to #include "xtdio.h"
 *
 *  Routines for External Usage:
 *
 *    PS *ps_make()
 *       ps_make: make a parallel search structure (PS) and initializes it
 *
 *    void ps_free(PS *ps, void (*outputfree)())
 *       ps_free: delete a PS and its tree.  The outputfree function
 *       is provided by the user to perform any cleanup actions associated
 *       with the output pointers.  It may be null.
 *
 *    void *ps_insert(PS *ps, char *word, void *output)
 *       ps_insert: insert a word into the parallel searcher.  Returns the
 *       output pointer to be associated with the word, unless it is an
 *       invalid word (has white space in it): in that case, it will return
 *       NULL.
 *
 *    int ps_delete(PS *ps, char *word, void (*outputfree()))
 *       ps_delete deletes a word from the ps parallel searcher.  The
 *       outputfree function is provided by the user to perform any cleanup
 *       actions associated with the output pointers.  It may be null.
 *
 *    char *ps_search(PS *ps, char *string, void **output)
 *       ps_search: search string for appearance of one of the inserted words
 *       Returns: a pointer just after the current word
 *                **output: a pointer associated with the match-th word
 *                found.  (see ps_insert)
 *                If null, then the word was *not* in the tree!
 *
 *    char *ps_beginwith(PS *ps, char *string, void **output)
 *        Just like ps_search, except that the longest word in the tree
 *        matching to the beginning of string is returned (ie. not all
 *        of string need match).
 *
 *    void ps_prtleaf(FILE *fp,PS_LEAF *leaf)
 *       This function prints out information on a leaf.  The leader
 *       text is emitted first.
 *
 *    void ps_prttree(FILE *fp,PS *ps)
 *        This function prints out an entire parsrch tree.
 *
 *    void ps_functree(PS *ps, void (*funcleaf)(PS_LEAF *))
 *        This function applies the user specified function (funcleaf) to
 *        every leaf of the tree.
 *
 *    void ps_optimize(PS *ps)
 *        Optimize the binary trees between states.  Will let ps_search and
 *        ps_beginwith run a tad faster.
 *
 * The PS_str has a int (*accept)(char) pointer-to-a-function-taking a char
 * and returning an int.  This function should return 1 if the char is
 * acceptable as part of a word and 0 otherwise.
 *
 * The default function for accept is ps_accept(), which accepts
 * characters satisfying [a-zA-Z_0-9]* .
 *
 * There is a isany() function which accepts *all* characters available
 * here, too, which may be used.
 *
 */
#include <stdio.h>
#include <ctype.h>
#include "xtdio.h"

/* -------------------------------------------------------------------------
 * Local Definitions:
 */
#define PS_TREESIZE		128
#define PS_BIGTREESIZE	256
#define BUFSIZE		256

#ifdef oldvms
# define SIGNEDCHAR
#else
# if CHAR_MAX == SCHAR_MAX
#  define SIGNEDCHAR
# endif
#endif

/* -------------------------------------------------------------------------
 * Local Prototypes:
 */
#ifdef __PROTOTYPE__
static void ps_make2(PS *);                                /* parsrch.c       */
static void ps_free2(PS_LEAF *);                           /* parsrch.c       */
static int ps_delete2( PS_LEAF *, PS_LEAF *);              /* parsrch.c       */
static void ps_functree2( PS_LEAF *, void (*)(PS_LEAF *)); /* parsrch.c       */
static void ps_prttree2( FILE *, PS_LEAF *);               /* parsrch.c       */
static void ps_optleaf(PS_LEAF *);                         /* parsrch.c       */
static PS_LEAF *ps_optree(PS_LEAF *);                      /* parsrch.c       */
static void ps_optflatten(PS_LEAF *);                      /* parsrch.c       */
static PS_LEAF *ps_formtree(int);                          /* parsrch.c       */

#else

static void ps_make2();                                    /* parsrch.c       */
static void ps_free2();                                    /* parsrch.c       */
static int ps_delete2();                                   /* parsrch.c       */
static void ps_functree2();                                /* parsrch.c       */
static void ps_prttree2();                                 /* parsrch.c       */
static void ps_optleaf();                                  /* parsrch.c       */
static PS_LEAF *ps_optree();                               /* parsrch.c       */
static void ps_optflatten();                               /* parsrch.c       */
static PS_LEAF *ps_formtree();                             /* parsrch.c       */
#endif

/* -------------------------------------------------------------------------
 * Local Data:
 */
static PS_LEAF *oldlf   = NULL;
static PS_LEAF *srchleaf= NULL;
static int      leafnum = 0;
static int      psnum   = 0;

/* -------------------------------------------------------------------------
 * Source Code:
 */
int ps_accept(int c)
{
int ret;


ret= isalnum(c) || c == '_';

return ret;
}

/* ----------------------------------------------------------------------- */

/* isany: true for all chars.  To use, set ps->accept:
 *   ps->accept= isany;
 */
int isany(int c)
{
return 1;
}

/* --------------------------------------------------------------------- */

/* ps_make: make a parallel search structure (PS) and initializes it */
PS *ps_make()
{
int i;
PS *ps;


/* allocate memory for a ps */
ps= alloc(PS);
if(!ps) {
	return (PS *) NULL;
	}

/* initialize tree to PS_TREESIZE leaves */
ps->tree     = (PS_LEAF *) calloc((size_t) PS_TREESIZE,sizeof(PS_LEAF));
outofmem((void *) ps->tree,"attempted to allocate %d leaves\n",PS_TREESIZE);
ps->treesize = PS_TREESIZE;
ps->accept   = ps_accept;	/* default character acceptance function */

/* initialize ps tree to nothing-in-it */
for(i= 0; i < PS_TREESIZE; ++i) {
	ps->tree[i].c      = '\0';
	ps->tree[i].left   = ps->tree[i].right= NULL;
	ps->tree[i].nxt    = ps->tree[i].prv  = NULL;
	ps->tree[i].output = NULL;
	}
ps->nwords= 0;	/* initially, there are no words in the tree */
ps->id    = ++psnum;
ps->shd   = ps->stl = NULL;

return ps;
}

/* ----------------------------------------------------------------------- */

/* ps_make2: this function re-allocates a PS and makes its tree table larger
 */
static void ps_make2(PS *ps)
{
int      ileaf;
PS_LEAF *newtree;


/* allocate new tree */
newtree= (PS_LEAF *) calloc((size_t) PS_BIGTREESIZE,sizeof(PS_LEAF));
outofmem((void *) newtree,"allocating newtree with %d leaves\n",PS_BIGTREESIZE);

#ifdef SIGNEDCHAR
newtree+= 128;		/* (char)128 -> -1 for signed characters */
#endif

/* copy old ps->tree to new tree */
for(ileaf= 0; ileaf < ps->treesize; ++ileaf) {
	newtree[ileaf]= ps->tree[ileaf];
	}

/* initialize new part of tree */
#ifdef SIGNEDCHAR
for(ileaf= -1; ileaf > -128; --ileaf) {
	newtree[ileaf].c      = '\0';
	newtree[ileaf].left   = newtree[ileaf].right= NULL;
	newtree[ileaf].nxt    = newtree[ileaf].prv  = NULL;
	newtree[ileaf].output = NULL;
	}
#else
for(; ileaf < PS_BIGTREESIZE; ++ileaf) {
	newtree[ileaf].c      = '\0';
	newtree[ileaf].left   = newtree[ileaf].right= NULL;
	newtree[ileaf].nxt    = newtree[ileaf].prv  = NULL;
	newtree[ileaf].output = NULL;
	}
#endif

/* free up old tree and set ps to use new one */
free((char *) ps->tree);
ps->tree    = newtree;
ps->treesize= PS_BIGTREESIZE;

}

/* ----------------------------------------------------------------------- */

/* ps_duplicate: this function creates a duplicate PS tree */
PS *ps_duplicate(PS *ps)
{
PS *dup;


if(!ps) {
	error(XTDIO_WARNING,"ps_duplicate: null PS tree\n");
	return (PS *) NULL;
	}

/* make a new PS tree */
dup= ps_make();

return dup;
}

/* ----------------------------------------------------------------------- */

/* ps_insert: insert a word into the parallel searcher.  Returns the
 *  output pointer to be associated with the word, unless it is an
 *  invalid word (has white space in it): in that case, it will return
 *  NULL
 */
void *ps_insert(
  PS   *ps,
  char *word,
  void *output)
{
char    *s;
PS_LEAF *leaf    = NULL;
PS_LEAF *lf      = NULL;
PS_LEAF *oldleaf = NULL;


if(!ps) {
	error(XTDIO_WARNING,"ps_insert: null PS tree\n");
	return NULL;
	}

/* sanity check: only legal ispschar characters in "words", please... */
for(s= word; *s; ++s) if(!ps->accept(*s)) {
	return NULL;
	}
s= word;

if(ps->treesize == PS_TREESIZE) {
	/* re-allocate and initialize tree
	 * The following oddball test should call ps_make2()
	 * whenever *s is *not* a [0,127]-type character.  Since
	 * char is unsigned on some systems and signed on others,
	 * simpler tests like (*s <0)  or (*s >= ps->treesize)
	 * either don't work and/or give compiler warnings.
	 */
	if( !(0 <= *s && *s <= (char) (ps->treesize-1)) ) ps_make2(ps);
	}

/* set up leaf and oldleaf */
oldleaf= oldlf= NULL;
leaf   = &(ps->tree[*s]);
if(!leaf->c) { /* string not in tree at first character */
	leaf->c    = *s;
	leaf->id   = ++leafnum;
	leaf->left = leaf->right = leaf->nxt = leaf->right = NULL;
	++s;
	oldleaf= leaf;
	leaf   = NULL;
	}

/* advance as many leaves as possible */
else for(++s; *s; ++s) {
	oldleaf= leaf;
	leaf   = ps_goto(leaf,*s);
	if(!leaf) break;
	}

/* end-of-word handler */
if(!*s) {

	/* if *s is null and output is set, then the word has already been
	 * seen (end of word && leaf isn't null)
	 */
	if(leaf) {
		if(leaf->output) {	/* output already set (ignore) */
			return leaf->output;
			}

		/* otherwise: the new word is part of another (larger) word */
		else {	/* (end of word && leaf isn't null && output available) */
			++ps->nwords;
			return (leaf->output= output);
			}
		}

	else {	/* single character word can cause end-of-word && null leaf */
		leaf   = oldleaf;
		oldleaf= NULL;
		}
	}

/* not end-of-word but there's a null leaf.
 * Allocate and link the leaves:
 */
for(lf= oldleaf; *s; ++s, lf= leaf) { /* add new leaves */
	leaf        = alloc(PS_LEAF);
	leaf->c     = *s;
	leaf->output= NULL;
	leaf->right = leaf->left= leaf->nxt= NULL;
	leaf->prv   = lf;
	if(oldlf) {		/* Link right/left pointer of oldlf */
		if(*s > oldlf->c) oldlf->right= leaf;
		else              oldlf->left = leaf;
		oldlf= NULL;
		}
	else if(lf) lf->nxt= leaf;
	leaf->id= ++leafnum;
	}

/* set up output of last leaf */
++ps->nwords;
leaf->output= output;

return leaf? leaf->output: ((void *) NULL);
}

/* ----------------------------------------------------------------------- */

#ifdef __PROTOTYPE__
static void (*outputfree2)(void *);
#else
static void (*outputfree2)();
#endif

/* ps_free: delete a PS and its tree */
void ps_free(
  PS    *ps,					/* free up this ParSrch table			*/
  void (*outputfree)(void *))	/* use this function to free up output	*/
{
int i;


for(i= 0, outputfree2= outputfree; i < ps->treesize; ++i) {
	if(ps->tree[i].left ) ps_free2(ps->tree[i].left );
	if(ps->tree[i].right) ps_free2(ps->tree[i].right);
	if(ps->tree[i].nxt  ) ps_free2(ps->tree[i].nxt  );
	if(outputfree && ps->tree[i].output) (*outputfree)(ps->tree[i].output);
	ps->tree[i].left= ps->tree[i].right= ps->tree[i].nxt= NULL;
	}

/* free data structures ps->tree and ps itself.
 *    Note that ps->tree can be allocated differently depending on whether
 *  chars are signed or not.  Normally, a tree is allocated with 128
 *  character leaves.  However, if ps_insert() is told to insert with a
 *  character having its high bit set for the first time, it will use
 *  ps_make2 to re-allocate the tree.
 *    Since chars can be unsigned or signed, this creates a bit of a problem.
 *  The solution taken was:
 *  If (char == unsigned char) : ps->tree becomes 256 leaves, and
 *                                (char)   0 => ps->tree[0]
 *                                (char) 127 => ps->tree[127]
 *                                (char) 128 => ps->tree[128]
 *                                (char) 255 => ps->tree[255]
 *  Else (char == signed char): ps->tree becomes 256 leaves, and
 *                                (char)   0 => ps->tree[0]
 *                                (char) 127 => ps->tree[127]
 *                                (char) 128 => ps->tree[-1]
 *                                (char) 255 => ps->tree[-127]
 *    Thus, high order bit-set characters under signed char arithmetic
 * are assumed to be negative.  To compensate, ps->tree is offset by
 * 128 leaves.  Freeing these also must take the optional offset into account.
 */
#ifdef SIGNEDCHAR
if(ps->treesize >= PS_BIGTREESIZE) free((char *) ps->tree - 128);
else                               free((char *) ps->tree);
ps->tree= NULL;
#else
free((char *) ps->tree); ps->tree= NULL;
#endif
free((char *) ps);

}

/* ----------------------------------------------------------------------- */

/* ps_free2: supports deletion of leaves */
static void ps_free2(PS_LEAF *leaf)
{

if(leaf->left ) ps_free2(leaf->left );
if(leaf->right) ps_free2(leaf->right);
if(leaf->nxt  ) ps_free2(leaf->nxt  );
leaf->left= leaf->right= leaf->nxt= NULL;

if(outputfree2 && leaf->output) (*outputfree2)(leaf->output);
free((char *) leaf);

}

/* ----------------------------------------------------------------------- */

/* ps_delete: delete a word from the parallel searcher
 *  Returns: 0 if success
 *	         1 if unsuccessful
 */
int ps_delete(
  PS    *ps,
  char  *word,
  void (*outputfree)(void *))
{
void *output  = NULL;
PS_LEAF *leaf = NULL;
PS_LEAF *lprv = NULL;


/* sanity check */
if(!ps) {
	error(XTDIO_WARNING,"ps_delete: null PS tree\n");
	return 0;
	}

/* find leaf and output function associated with word */
(void) ps_search(ps,word,&output);
if(!output) {
	return 0;
	}

/* use user-specified function to free up output */
if(outputfree) (*outputfree)(output);

/* delete word by going backwards! */
srchleaf->output= NULL;	/* leaf no longer has "output" */
outputfree2     = outputfree;
for(leaf= srchleaf; leaf; leaf= lprv) {
	lprv= leaf->prv;
	if(!leaf->prv) {	/* make root leaf null char if no left/right */
		if(!leaf->right && !leaf->left && !leaf->output) leaf->c= '\0';
		}
	else if(ps_delete2((PS_LEAF *) NULL,lprv->nxt)) break;
	}

return 0;
}

/* ----------------------------------------------------------------------- */

/* ps_delete2: this function is responsible for deleting a leaf
 */
static int ps_delete2(
  PS_LEAF *node,
  PS_LEAF *dleaf)
{
int lrtn;
int rrtn;


if(!dleaf) {		/* leaf already deleted							*/
	return 0;
	}

if(dleaf->output) {	/* cannot delete a leaf with output				*/
	return 1;
	}

if(dleaf->nxt) {	/* cannot delete a leaf with subsequent states	*/
	return 1;
	}

/* dleaf is now a candidate for deletion.  Attempt to delete its left & right
 * associated leafs
 */
lrtn= dleaf->left ? ps_delete2(dleaf,dleaf->left)  : 0;
rrtn= dleaf->right? ps_delete2(dleaf,dleaf->right) : 0;

if(lrtn == 1 && rrtn == 0) {	/* keep left, right already deleted */
	/* put left into dleaf's place */
	if(node) {
		if(node->left == dleaf) node->left = dleaf->left;
		else                    node->right= dleaf->left;
		}
	else {
		dleaf->prv->nxt= dleaf->left;
		}
	}
else if(lrtn == 0 && rrtn == 1) {	/* keep right, left already deleted */
	/* put right into dleaf's place */
	if(node) {
		if(node->left == dleaf) node->left = dleaf->right;
		else                    node->right= dleaf->right;
		}
	else {
		dleaf->prv->nxt= dleaf->right;
		}
	}
else if(lrtn == 0 && rrtn == 0) {	/* delete leaf (no left or right) */
	if(node) {
		if(node->left == dleaf) node->left = NULL;
		else                    node->right= NULL;
		}
	else if(dleaf->prv && dleaf->prv->nxt == dleaf) { /* prv now has no nxt */
		dleaf->prv->nxt= NULL;
		}
	}
else {
	return 1;
	}

/* delete the dleaf */
if(outputfree2 && dleaf->output) {
	(*outputfree2)(dleaf->output);
	dleaf->output= NULL;
	}
free((char *) dleaf);

return 0;
}

/* ----------------------------------------------------------------------- */

/* ps_search: is the string in the parsrch table
 *
 *  ps_search    checks if the "string" is in the ps table.
 *  ps_beginwith checks if the "string" begins w/ something in the ps table
 *
 *	Returns: A pointer just after the current word
 *           If output is null, no match found (word *not* in the tree!)
 */
char *ps_search(
  PS    *ps,
  char  *string,
  void **output)
{
char           *s;
static PS_LEAF *leaf;


/* sanity checks */
if(!output || !string) {
	error(XTDIO_WARNING,"ps_search: null %s\n",output? "string" : "output");
	return string;
	}

/* default: assume word not-in-tree */
*output= NULL;

if(!ps) { /* no tree present to be searched */
	error(XTDIO_WARNING,"ps_search: null PS tree\n");
	return string;
	}

/* skip past initial non-alphanumeric characters */
for(s= string; *s; ++s) if(ps->accept(*s)) break;

if(!*s) {	/* empty remaining string */
	return s;
	}

if( !(0 <= *s && *s <= ((char) 127)) ) {
	for(++s; *s; ++s) if(!ps->accept(*s)) break;
	return s;
	}

/* first character is special - they're roots of their own PS_LEAF trees */
leaf= &(ps->tree[*s]);
if(!leaf->c) { /* string not in tree */
	for(++s; *s; ++s) if(!ps->accept(*s)) break;
	return s;
	}

/* use FSA to perform match on string */
for(++s; *s && ps->accept(*s); ++s) {
	/* while *s is an alphanumeric character, goto next leaf (if possible) */
	leaf= ps_goto(leaf,*s);
	if(!leaf) { /* unable to ps_goto on *s, therefore word not in tree */
		for(; *s; ++s) if(!ps->accept(*s)) break;	/* skip rest of word */
		return s;
		}
	}

/* only if output is not 0 is a word assumed to have been found that was
 * in the tree
 */
*output = leaf->output;
srchleaf= leaf;	/* for ps_delete's benefit */

return s;
}

/* ----------------------------------------------------------------------- */

/* ps_beginwith: search string for appearance of one of the inserted words
 *
 *  ps_search    checks if the "string" is in the ps table.
 *  ps_beginwith checks if the "string" begins w/ something in the ps table
 *
 *	Returns: a pointer just after the current in-table word
 *           If output is null, no match found
 */
char *ps_beginwith(
  PS    *ps,
  char  *string,
  void **output)
{
char           *s    = NULL;
char           *sout = NULL;
static PS_LEAF *leaf = NULL;


/* default: assume word not-in-tree */
*output= NULL;

if(!ps) { /* no tree present to be searched */
	error(XTDIO_WARNING,"ps_beginwith: null PS tree\n");
	return s;
	}

/* skip past initial not-in-permissible-set characters */
for(s= string; *s; ++s) if(ps->accept(*s)) break;

if(!*s) {	/* empty remaining string */
	return s;
	}

/* first character is special - they're roots of their own PS_LEAF trees */
leaf= &(ps->tree[(unsigned char) *s]);

if(!leaf->c) { /* string not in tree */
	for(++s; *s; ++s) if(!ps->accept(*s)) break;
	return s;
	}

if(leaf->output) {
	sout    = s;
	*output = leaf->output;
	srchleaf= leaf;
	}

/* use FSA to perform match on string */
for(++s; *s && ps->accept(*s); ++s) {

	/* while *s is an alphanumeric character, goto next leaf (if possible) */
	leaf= ps_goto(leaf,*s);

	/* unable to ps_goto on *s, thus rest of word isn't in tree */
	if(!leaf) break;
	else if(leaf->output) {	/* record largest partial word in string */
		sout    = s;
		*output = leaf->output;
		srchleaf= leaf;
		}
	}

if(sout) { /* found partial word in tree */
	++sout;			/* points just past matched partial */


	return sout;
	}

/* not even a partial word was in the tree */
srchleaf= NULL;

return s;
}

/* ----------------------------------------------------------------------- */

/* ps_goto: this function operates on the current leaf, given a character,
 *  and "goes to" the next leaf (if any).  If it is unsuccessful (ie.
 *  there is no leaf following the input leaf corresponding to the 'c'
 *  character) then a NULL pointer is returned.
 */
PS_LEAF *ps_goto(
  PS_LEAF *leaf,
  char     c)
{
PS_LEAF *lf;


/* set lf to first possible leaf of tree following current leaf */
oldlf= lf= leaf->nxt;
while(lf) {
	oldlf= lf;

	if(c > lf->c)      lf= lf->right;
	else if(c < lf->c) lf= lf->left;
	else {
		return lf;		/* found the leaf */
		}
	}

return (PS_LEAF *) NULL;	/* just making the NULL return explicit */
}

/* ----------------------------------------------------------------------- */

/* ps_prtleaf: print out a leaf */
void ps_prtleaf(
  FILE    *fp,
  PS_LEAF *leaf)	/* the leaf to be printed		*/
{
char    *w;
char     word[BUFSIZE];
PS_LEAF *lf;

/* set up word */
w   = word + BUFSIZE;
*--w= '\0';
for(lf= leaf; lf; lf= lf->prv) *--w= lf->c;

fprintf(fp,"|leaf%4d%s: left%4d%s right%4d%s nxt%4d%s prv%4d%s <%s>%s\n",
  leaf->id,
  cprt(leaf->c),
  leaf->left?  leaf->left->id       : 0,
  leaf->left?  cprt(leaf->left->c)  : " ",
  leaf->right? leaf->right->id      : 0,
  leaf->right? cprt(leaf->right->c) : " ",
  leaf->nxt?   leaf->nxt->id        : 0,
  leaf->nxt?   cprt(leaf->nxt->c)   : " ",
  leaf->prv?   leaf->prv->id        : 0,
  leaf->prv?   cprt(leaf->prv->c)   : " ",
  sprt(w),
  leaf->output? "*" : "");
}

/* ----------------------------------------------------------------------- */

/* ps_functree: execute given function for each member of the tree */
void ps_functree(
  PS *ps,
  void (*funcleaf)(PS_LEAF *))
{
int  i;


for(i= 0; i < ps->treesize; ++i) {
	if(ps->tree[i].c && ps->tree[i].output) (*funcleaf)(&ps->tree[i]);
	if(ps->tree[i].nxt)                     ps_functree2(ps->tree[i].nxt,funcleaf);
	}

}

/* ----------------------------------------------------------------------- */

/* ps_functree2: apply a function to every leaf of the tree */
static void ps_functree2(
  PS_LEAF *leaf,
  void (*funcleaf)(PS_LEAF *))
{
/* print out current leaf */
if(leaf->output) (*funcleaf)(leaf);

if(leaf->left)  ps_functree2(leaf->left,funcleaf);
if(leaf->nxt)   ps_functree2(leaf->nxt,funcleaf);
if(leaf->right) ps_functree2(leaf->right,funcleaf);
}

/* ----------------------------------------------------------------------- */

/* ps_prttree: print out an entire tree */
void ps_prttree(FILE *fp,PS *ps)
{
int  i;

fprintf(fp,"ps%d tree:\n",ps->id);

for(i= 0; i < ps->treesize; ++i) {
	if(ps->tree[i].c)   ps_prtleaf(fp,&ps->tree[i]);
	if(ps->tree[i].nxt) ps_prttree2(fp,ps->tree[i].nxt);
	}
}

/* ----------------------------------------------------------------------- */

/* ps_prttree2: print out a tree given a leaf */
static void ps_prttree2(
  FILE    *fp,
  PS_LEAF *leaf)
{
/* print out current leaf */
ps_prtleaf(fp,leaf);

if(leaf->left)  ps_prttree2(fp,leaf->left);
if(leaf->nxt)   ps_prttree2(fp,leaf->nxt);
if(leaf->right) ps_prttree2(fp,leaf->right);
}

/* ---------------------------------------------------------------------
 * Local Tree Optimizer Static Variables:
 */
static int      psopt_num;
static PS_LEAF  psopt_base;
static PS_LEAF *psopt_tail;
static PS_LEAF *psopt_root;
static int      left;

/* --------------------------------------------------------------------- */

/* ps_optimize: optimize a ParSearch structure */
void ps_optimize(PS *ps)
{
int      ileaf;
PS_LEAF *leaf;


if(!ps) {
	error(XTDIO_WARNING,"ps_optimize: null PS tree\n");
	return;
	}

for(ileaf= 0; ileaf < ps->treesize; ++ileaf) {
	leaf= ps->tree + ileaf;
	if(leaf->c) {
		if(leaf->nxt) {
			leaf->nxt= ps_optree(leaf->nxt);
			ps_optleaf(leaf->nxt);
			}

		}
	}

}

/* --------------------------------------------------------------------- */

/* ps_optleaf: optimizes leaves of a ParSearch tree */
static void ps_optleaf(PS_LEAF *leaf)
{

/* recurse to all leaves */
if(leaf->left)  ps_optleaf(leaf->left);
if(leaf->right) ps_optleaf(leaf->right);

/* optimize next binary tree */
if(leaf->nxt) leaf->nxt= ps_optree(leaf->nxt);

}

/* --------------------------------------------------------------------- */

/* optree: optimize a tree using David Schwartz's code, slightly modified
 *  for parsrch's purposes, to optimize the parsrch binary tree
 */
static PS_LEAF *ps_optree(PS_LEAF *root)
{
PS_LEAF *ptr;


if(!root) return NULL;

psopt_tail= &psopt_base;
psopt_num = 0;

ps_optflatten(root);

/* form optimized tree */
psopt_root= psopt_base.right;
left      = 0;
ptr       = ps_formtree(psopt_num);

return (PS_LEAF *) ptr;
}

/* --------------------------------------------------------------------- */

/* ps_optflatten: flatten tree into a linked list */
static void ps_optflatten(PS_LEAF *node)
{

if(node->left) ps_optflatten(node->left);

psopt_tail->right= node;
psopt_tail       = node;
psopt_num++;

if(node->right) ps_optflatten(node->right);

}

/* --------------------------------------------------------------------- */

/* ps_formtree: form an optimized tree from list */
static PS_LEAF *ps_formtree(int num)
{
int      middle;
PS_LEAF *ptr;


middle= num >> 1;	/* num/2 */

/* special 5-node case */
if(num == 5) {
	++middle;
	}

/* lean branch to center of tree */
if(left) {
	middle= num - middle - 1;
	}

/* remove left subtree from list */
left            = 1;
ptr             = (middle > 0)? ps_formtree(middle) : NULL;
psopt_root->left= ptr;

/* remove this node from the list */
ptr             = psopt_root;
psopt_root      = psopt_root->right;

/* remove right subtree from list */
left            = 0;
middle          = num - middle - 1;


ptr->right      = (middle > 0)? ps_formtree(middle) : NULL;

return ptr;
}

/* -------------------------------------------------------------------------
 * Debugging Source Code:
 */

/* --------------------------------------------------------------------- */

