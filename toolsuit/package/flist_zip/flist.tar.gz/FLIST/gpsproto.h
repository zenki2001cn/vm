/* prototypes generated automatically by Dr. Chip's flist program
 * Tue Dec 5 15:55:49 EST 2006
 */
#ifdef __PROTOTYPE__
 
char *cprt(const char);                                                                                 /* cprt.c          */
void setup_dodir( void (*)(char *),  char **,  int);                                                    /* dodir.c         */
void dodir(char *);                                                                                     /* dodir.c         */
void dodir(char *);                                                                                     /* dodir.c         */
void error( int, char *, ...);                                                                          /* error.c         */
int main(int,char **);                                                                                  /* flist.c         */
int options(char **,char **);                                                                           /* flist.c         */
void CtreeLatexSizing( NameList *, int, int);                                                           /* flist.c         */
void CtreeLatex( NameList *, int, int);                                                                 /* flist.c         */
void fopensave(char *,...);                                                                             /* fopensave.c     */
FILE *fopenv( char *, char *, char *);                                                                  /* fopenv.c        */
void fopenvDflt(char *);                                                                                /* fopenv.c        */
FILE *fopenx( char *,  char *,  char *,  char *);                                                       /* fopenx.c        */
int ga_translate( void *, int, char *);                                                                 /* ga_translate.c  */
void getarg( int,  char **,  int,  PARMDEF *,  char **,  int (*)(char **,char **),  void (*)(int,       /* getarg.c        */
  PARMDEF *),  void (*)(char *),  int,  char *);
void ga_usage(char **,int);                                                                             /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
int ga_findfirst( char *, char **);                                                                     /* getarg.c        */
int ga_findnext(char **);                                                                               /* getarg.c        */
int spawn( int, char **);                                                                               /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
void ga_dofilewild( void (*)(char *), char *);                                                          /* getarg.c        */
int ga_haswild(char *);                                                                                 /* getarg.c        */
void outofmem(void *,char *,...);                                                                       /* outofmem.c      */
int ps_accept(int);                                                                                     /* parsrch.c       */
int isany(int);                                                                                         /* parsrch.c       */
PS *ps_make(void);                                                                                      /* parsrch.c       */
PS *ps_duplicate(PS *);                                                                                 /* parsrch.c       */
void *ps_insert( PS *, char *, void *);                                                                 /* parsrch.c       */
void ps_free( PS *,  void (*)(void *));                                                                 /* parsrch.c       */
int ps_delete( PS *, char *, void (*)(void *));                                                         /* parsrch.c       */
char *ps_search( PS *, char *, void **);                                                                /* parsrch.c       */
char *ps_beginwith( PS *, char *, void **);                                                             /* parsrch.c       */
PS_LEAF *ps_goto( PS_LEAF *, char);                                                                     /* parsrch.c       */
void ps_prtleaf( FILE *, PS_LEAF *);                                                                    /* parsrch.c       */
void ps_functree( PS *, void (*)(PS_LEAF *));                                                           /* parsrch.c       */
void ps_prttree(FILE *,PS *);                                                                           /* parsrch.c       */
void ps_optimize(PS *);                                                                                 /* parsrch.c       */
void ps_srtinit(ParSrch *);                                                                             /* ps_iterate.c    */
void *ps_srtnxt(ParSrch *);                                                                             /* ps_iterate.c    */
void *ps_srtprv(ParSrch *);                                                                             /* ps_iterate.c    */
void ps_srtclear(PS *);                                                                                 /* ps_iterate.c    */
void rdcolor(void);                                                                                     /* rdcolor.c       */
void rdcputs(char *,FILE *);                                                                            /* rdcolor.c       */
void setup_screendata(char *);                                                                          /* rdcolor.c       */
char *sprt(const void *);                                                                               /* sprt.c          */
char *srmtrblk(char *);                                                                                 /* srmtrblk.c      */
int stcmpma( char *,  char *,  int *);                                                                  /* stcmpma.c       */
int stcmpm( char *,  char *,  char **,  int *);                                                         /* stcmpma.c       */
int stcmpma2( char *,  PAT *,  int *);                                                                  /* stcmpma.c       */
int stcmpm2( char *,  PAT *,  char **,  int *);                                                         /* stcmpma.c       */
void freepat(PAT *);                                                                                    /* stcmpma.c       */
char *patprint(PAT *);                                                                                  /* stcmpma.c       */
PAT *setpat_nosetbrace(char *);                                                                         /* stcmpma.c       */
PAT *setpat(char *);                                                                                    /* stcmpma.c       */
char stcmpma_escape(char **);                                                                           /* stcmpma.c       */
void stcmsetcase(int);                                                                                  /* stcmpma.c       */
LPAT *setlpat(char *);                                                                                  /* stlpm.c         */
int stlpm( char *, char *);                                                                             /* stlpm.c         */
int stlpm2(char *,LPAT *);                                                                              /* stlpm.c         */
char *lpatprint(LPAT *);                                                                                /* stlpm.c         */
void freelpat(LPAT *);                                                                                  /* stlpm.c         */
int stlpm_haslogic(char *);                                                                             /* stlpm.c         */
char *stpblk(char *);                                                                                   /* stpblk.c        */
char *stpbrk(char *,char *);                                                                            /* stpbrk.c        */
char *stpnxt( char *,  char *);                                                                         /* stpnxt.c        */
char *strprintf(char *,...);                                                                            /* strprintf.c     */
 
#else	/* __PROTOTYPE__ */
 
extern char *cprt();                                                                                    /* cprt.c          */
extern void setup_dodir();                                                                              /* dodir.c         */
extern void dodir();                                                                                    /* dodir.c         */
extern void dodir();                                                                                    /* dodir.c         */
extern void error();                                                                                    /* error.c         */
extern int main();                                                                                      /* flist.c         */
extern int options();                                                                                   /* flist.c         */
extern void CtreeLatexSizing();                                                                         /* flist.c         */
extern void CtreeLatex();                                                                               /* flist.c         */
extern void fopensave();                                                                                /* fopensave.c     */
extern FILE *fopenv();                                                                                  /* fopenv.c        */
extern void fopenvDflt();                                                                               /* fopenv.c        */
extern FILE *fopenx();                                                                                  /* fopenx.c        */
extern int ga_translate();                                                                              /* ga_translate.c  */
extern void getarg();                                                                                   /* getarg.c        */
extern void ga_usage();                                                                                 /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern int ga_findfirst();                                                                              /* getarg.c        */
extern int ga_findnext();                                                                               /* getarg.c        */
extern int spawn();                                                                                     /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern void ga_dofilewild();                                                                            /* getarg.c        */
extern int ga_haswild();                                                                                /* getarg.c        */
extern void outofmem();                                                                                 /* outofmem.c      */
extern int ps_accept();                                                                                 /* parsrch.c       */
extern int isany();                                                                                     /* parsrch.c       */
extern PS *ps_make();                                                                                   /* parsrch.c       */
extern PS *ps_duplicate();                                                                              /* parsrch.c       */
extern void *ps_insert();                                                                               /* parsrch.c       */
extern void ps_free();                                                                                  /* parsrch.c       */
extern int ps_delete();                                                                                 /* parsrch.c       */
extern char *ps_search();                                                                               /* parsrch.c       */
extern char *ps_beginwith();                                                                            /* parsrch.c       */
extern PS_LEAF *ps_goto();                                                                              /* parsrch.c       */
extern void ps_prtleaf();                                                                               /* parsrch.c       */
extern void ps_functree();                                                                              /* parsrch.c       */
extern void ps_prttree();                                                                               /* parsrch.c       */
extern void ps_optimize();                                                                              /* parsrch.c       */
extern void ps_srtinit();                                                                               /* ps_iterate.c    */
extern void *ps_srtnxt();                                                                               /* ps_iterate.c    */
extern void *ps_srtprv();                                                                               /* ps_iterate.c    */
extern void ps_srtclear();                                                                              /* ps_iterate.c    */
extern void rdcolor();                                                                                  /* rdcolor.c       */
extern void rdcputs();                                                                                  /* rdcolor.c       */
extern void setup_screendata();                                                                         /* rdcolor.c       */
extern char *sprt();                                                                                    /* sprt.c          */
extern char *srmtrblk();                                                                                /* srmtrblk.c      */
extern int stcmpma();                                                                                   /* stcmpma.c       */
extern int stcmpm();                                                                                    /* stcmpma.c       */
extern int stcmpma2();                                                                                  /* stcmpma.c       */
extern int stcmpm2();                                                                                   /* stcmpma.c       */
extern void freepat();                                                                                  /* stcmpma.c       */
extern char *patprint();                                                                                /* stcmpma.c       */
extern PAT *setpat_nosetbrace();                                                                        /* stcmpma.c       */
extern PAT *setpat();                                                                                   /* stcmpma.c       */
extern char stcmpma_escape();                                                                           /* stcmpma.c       */
extern void stcmsetcase();                                                                              /* stcmpma.c       */
extern LPAT *setlpat();                                                                                 /* stlpm.c         */
extern int stlpm();                                                                                     /* stlpm.c         */
extern int stlpm2();                                                                                    /* stlpm.c         */
extern char *lpatprint();                                                                               /* stlpm.c         */
extern void freelpat();                                                                                 /* stlpm.c         */
extern int stlpm_haslogic();                                                                            /* stlpm.c         */
extern char *stpblk();                                                                                  /* stpblk.c        */
extern char *stpbrk();                                                                                  /* stpbrk.c        */
extern char *stpnxt();                                                                                  /* stpnxt.c        */
extern char *strprintf();                                                                               /* strprintf.c     */
 
#endif	/* __PROTOTYPE__ */
