/* dodir.c: this function is expected to be used by getarg for "dofile()"
 *          when the programmer wants to have directories processed
 *          as well as files.
 * Copyright  Dec 14, 1999: Charles E. Campbell, Jr. -- see <Copyright> file
 */
#include <stdio.h>
#include "xtdio.h"

/* ---------------------------------------------------------------------
 * Local Variables:
 */
static char **dodir_suffixlist      = NULL;
static int    dodir_rflag           = 0;
static void (*dodir_dofile)(char *) = NULL;

/* ---------------------------------------------------------------------
 * Source:
 */

/* setup_dodir: initializes directory recursion for getarg */
void setup_dodir(
  void   (*dofile)(char *),	/* dofile function, like getarg's			*/
  char  **suffixlist,		/* list of suffix (if null, all accepted)	*/
  int     rflag)			/* whether or not to allow recursion		*/
{

dodir_suffixlist= suffixlist;	/* note: last item in list MUST BE ""	*/
dodir_dofile    = dofile;
dodir_rflag     = rflag;

}

/* =====================================================================
 *                              U N I X
 */

#ifdef unix
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

# if defined(sun) || defined(_AIX) || defined(__DECC) || defined(__alpha) || defined(__osf__) || defined(unix)
# include <dirent.h>
# define direct dirent
#else
# include <sys/dir.h>
#endif

/* ---------------------------------------------------------------------
 * Definitions:
 */
#define DIRBUFLEN	256

/* dodir: process an entire directory  - UNIX */
void dodir(char *dirname)
{
DIR           *dir       = NULL;
char          *dirbuf    = NULL;
char          *dot;
char         **suffix;
int            dirbuflen = 0;
int            dlen;
int            flen;
static int     depth     = 0;
struct stat    statbuf;
struct direct *dpfile    = NULL;


/* sanity check */
if(!dodir_dofile) error(XTDIO_SEVERE,"dodir: dodir_dofile may *not* be null (and it is)\n");

/* determine if this "dirname" is really a file, and if so, use dofile() on it */
if(stat(dirname,&statbuf) == 0) {
	char *slash;

	slash= strrchr(dirname,'/');
	if(!slash) slash= dirname;
	else       ++slash;

	/* test if regular file */
	if((statbuf.st_mode & S_IFREG) && !(statbuf.st_mode & S_IFDIR)) {

		/* if no dodir_suffixlist, just dofile 'em all! */
		if(dodir_suffixlist) {
			/* test if "dirname" (actually just a file) has selected suffix */
			dot= strrchr(dirname,'.');
			if(dot) {
				++dot;
				for(suffix= dodir_suffixlist; **suffix; ++suffix) if(!strcmp(dot,*suffix)) {
					(*dodir_dofile)(dirname);
					return;
					}
				if(depth == 0) error(XTDIO_WARNING,"file<%s> doesn't have an acceptable suffix\n",sprt(dirname));
				}
			}
		else {
			(*dodir_dofile)(dirname);
			}
		return;
		}
	}

/* file in dirname doesn't exist, so check if a suffix'ed version does */
else if(errno == EFAULT || errno == ENOENT) {

	if(dodir_suffixlist) {
		for(suffix= dodir_suffixlist; **suffix; ++suffix) {
			if(stat(strprintf("%s.%s",dirname,*suffix),&statbuf) == 0) {
				char *tmpbuf;
				stralloc(tmpbuf,strprintf("%s.%s",dirname,*suffix),"trying to set up a filename\n");
				(*dodir_dofile)(tmpbuf);
				free(tmpbuf);
				return;
				}
			}
		}
	}


/* prevent continued recursion unless dodir_rflag is true */
++depth;
if(!dodir_rflag && depth > 1) {
	--depth;
	return;
	}

/* process entire directory */
dir= opendir(dirname);

if(!dir) {	/* unable to open directory */
	error(XTDIO_WARNING,"unable to open directory <%s%s%s>\n",YELLOW,sprt(dirname),GREEN);
	--depth;
	return;
	}

/* read contents of directory, but don't recurse on . or .. */
dlen= strlen(dirname);
while((dpfile= readdir(dir))) if(strcmp(dpfile->d_name,".") && strcmp(dpfile->d_name,"..")) {

	/* allocate a buffer big enough to hold dirname/dpfile->d_name */
	flen= strlen(dpfile->d_name) + dlen + 2;
	if(flen > dirbuflen) {
		dirbuflen= (flen/DIRBUFLEN + 1)*DIRBUFLEN;
		if(dirbuf) dirbuf= (char *) realloc(dirbuf,(size_t) dirbuflen);
		else       dirbuf= (char *) calloc((size_t) dirbuflen,sizeof(char));
		outofmem(dirbuf,"attempted to allocate a %d byte buffer for dirbuf\n",dirbuflen);
		}
	sprintf(dirbuf,"%s/%s",dirname,dpfile->d_name);

	/* do recursion */
	dodir(dirbuf);
	}

/* free up dirbuf memory */
if(dirbuf) {
	free(dirbuf);
	dirbuflen= 0;
	}

/* close the directory handle */
closedir(dir);

/* let dofile know that this directory has now been processed in
 * case it wants to do something
 */
(*dodir_dofile)(NULL);

--depth;
}
#endif	/* unix */

/* =====================================================================
 *                           A M I G A
 */

#ifdef MCH_AMIGA

#include <exec/types.h>
#include <exec/nodes.h>
#include <exec/lists.h>
#include <exec/libraries.h>
#include <exec/ports.h>
#include <exec/interrupts.h>
#include <exec/io.h>
#include <exec/memory.h>
#include <libraries/dos.h>
#include <libraries/dosextens.h>
#include <functions.h>

/* ---------------------------------------------------------------------
 * Definitions:
 */
#define BUFSIZE	256

/* --------------------------------------------------------------------- */

typedef struct fnamelist_str FnameList;

struct fnamelist_str {
	char      *fname;
	char      *dirname;
	FnameList *nxt;
	};

/* --------------------------------------------------------------------- */

/* dodir: process an entire directory  - AMIGA */
void dodir(char *dirname)
{
char                  dirbuf[BUFSIZE];
char                 *db     = dirbuf;
struct FileLock      *lock   = NULL;
struct FileInfoBlock *f_info;
FnameList            *fnl    = NULL;
FnameList            *fnlnxt = NULL;
FnameList            *fhd    = NULL;


lock= (struct FileLock *) AllocMem(sizeof(struct FileLock),MEMF_CHIP|MEMF_CLEAR);
if(!lock) {
	return;
	}

f_info= (struct FileInfoBlock *) AllocMem(sizeof(struct FileInfoBlock),MEMF_CHIP|MEMF_CLEAR);
if(!f_info) {
	error(XTDIO_WARNING,"unable to allocate a FileInfoBlock\n");
	FreeMem((APTR) lock,sizeof(struct FileLock));
	return;
	}

lock= (struct FileLock *) Lock((UBYTE *) dirname,ACCESS_READ);
if(!lock) {	/* try dofile on it -- maybe its just missing the extension */
	FreeMem((APTR) f_info,sizeof(struct FileInfoBlock));
	FreeMem((APTR) lock,sizeof(struct FileLock));
	(*dodir_dofile)(dirname);
	return;
	}

if(!Examine((BPTR) lock,f_info)) {
	UnLock((BPTR) lock);
	FreeMem((APTR) f_info,sizeof(struct FileInfoBlock));
	error(XTDIO_WARNING,"unable to examine FileInfoBlock\n");
	return;
	}

if(f_info->fib_DirEntryType < 0) {	/* dirname is really a filename */
	UnLock((BPTR) lock);
	FreeMem((APTR) f_info,sizeof(struct FileInfoBlock));
	(*dodir_dofile)(dirname);
	return;
	}

/* check out all files in the directory */
while(ExNext((BPTR) lock,f_info)) {

	/* allocate a new FnameList */
	head_link(FnameList,fhd,"dodir FnameList");
	
	/* f_info points to a
 	 *  fib_DirEntryType < 0: file
	 *                   > 0: directory
	 */
	if(f_info->fib_DirEntryType < 0) {
		stralloc(fhd->fname,f_info->fib_FileName,"dodir filename");
		fhd->dirname= NULL;
		}
	else if(f_info->fib_DirEntryType > 0) {
		fhd->fname= NULL;
		stralloc(fhd->dirname,f_info->fib_FileName,"dodir dirname");
		}

	}

/* free up resources */
UnLock((BPTR) lock);
FreeMem((APTR) f_info,sizeof(struct FileInfoBlock));
#ifdef DONTFREEIT	/* causes guru, dunno why */
FreeMem((APTR) lock,sizeof(FileLock));
#endif

/* set up dirbuf */
strcpy(dirbuf,dirname);
db= dirbuf + strlen(dirbuf);
if(db[-1] != ':') {
	*(db++)= '/';
	*db    = '\0';
	}

/* ok, dofile/dodir them (as appropriate) and free 'em */
for(fnl= fhd; fnl; fnl= fnlnxt) {
	fnlnxt= fnl->nxt;

	if(fnl->fname) {
		strcpy(db,fnl->fname);
		(*dodir_dofile)(dirbuf);
		free((char *) fnl->fname);
		}
	else if(fnl->dirname) {	/* is directory */
		if(dodir_rflag) {	/* allow recursing deeper into directories */
			strcpy(db,fnl->dirname);
			dodir(dirbuf);
			free((char *) fnl->dirname);
			}
		}
	else {
		error(XTDIO_WARNING,"dodir: fnl has no fname or dirname in <%s>\n",dirname);
		}

	/* free up FnameList */
	free((char *) fnl);
	}

/* let dofile know that this directory has now been processed in
 * case it wants to do something
 */
(*dodir_dofile)(NULL);

}
#endif	/* MCH_AMIGA */

/* --------------------------------------------------------------------- */
